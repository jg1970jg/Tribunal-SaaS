# -*- coding: utf-8 -*-
"""Módulo de utilidades."""

from .perguntas import parse_perguntas, validar_perguntas

__all__ = ["parse_perguntas", "validar_perguntas"]
