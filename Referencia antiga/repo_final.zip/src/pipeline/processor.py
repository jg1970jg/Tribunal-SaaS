# -*- coding: utf-8 -*-
"""
Processador Principal do Tribunal - Pipeline de 3 Fases com LLMs + Q&A.

Fase 1: 3 Extratores LLM -> Agregador (SEM perguntas)
Fase 2: 3 Auditores LLM -> Chefe (SEM perguntas)
Fase 3: 3 Juízes LLM -> Parecer + Q&A (COM perguntas)
Fase 4: Presidente -> Veredicto + Q&A Consolidado (COM perguntas)
"""

import sys
from pathlib import Path

# Adicionar diretório raiz ao path (necessário para imports absolutos)
_ROOT = Path(__file__).resolve().parent.parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import json
import logging
from datetime import datetime
from typing import Optional, Dict, Any, List, Callable
from dataclasses import dataclass, field
import uuid

from src.config import (
    EXTRATOR_MODELS,
    AUDITOR_MODELS,
    JUIZ_MODELS,
    PRESIDENTE_MODEL,
    AGREGADOR_MODEL,
    CHEFE_MODEL,
    OUTPUT_DIR,
    HISTORICO_DIR,
    LOG_LEVEL,
    SIMBOLOS_VERIFICACAO,
    AREAS_DIREITO,
    LLM_CONFIGS,
)
from src.llm_client import OpenRouterClient, LLMResponse, get_llm_client
from src.document_loader import DocumentContent, load_document
from src.legal_verifier import LegalVerifier, VerificacaoLegal, get_legal_verifier
from src.utils.perguntas import parse_perguntas, validar_perguntas
from src.utils.metadata_manager import guardar_metadata, gerar_titulo_automatico

# Configurar logging
logging.basicConfig(level=getattr(logging, LOG_LEVEL))
logger = logging.getLogger(__name__)


@dataclass
class FaseResult:
    """Resultado de uma fase do pipeline."""
    fase: str
    modelo: str
    role: str  # extrator_1, auditor_2, juiz_3, etc.
    conteudo: str
    tokens_usados: int = 0
    latencia_ms: float = 0.0
    timestamp: datetime = field(default_factory=datetime.now)
    sucesso: bool = True
    erro: Optional[str] = None

    def to_dict(self) -> Dict:
        return {
            "fase": self.fase,
            "modelo": self.modelo,
            "role": self.role,
            "conteudo": self.conteudo[:2000] + "..." if len(self.conteudo) > 2000 else self.conteudo,
            "conteudo_completo_length": len(self.conteudo),
            "tokens_usados": self.tokens_usados,
            "latencia_ms": self.latencia_ms,
            "timestamp": self.timestamp.isoformat(),
            "sucesso": self.sucesso,
            "erro": self.erro,
        }


@dataclass
class PipelineResult:
    """Resultado completo do pipeline."""
    run_id: str
    documento: Optional[DocumentContent]
    area_direito: str
    fase1_extracoes: List[FaseResult] = field(default_factory=list)
    fase1_agregado: str = ""  # Backwards compat - alias para consolidado
    fase1_agregado_bruto: str = ""  # Concatenação simples com marcadores
    fase1_agregado_consolidado: str = ""  # Processado pelo Agregador LLM (LOSSLESS)
    fase2_auditorias: List[FaseResult] = field(default_factory=list)
    fase2_chefe: str = ""  # Backwards compat - alias para consolidado
    fase2_auditorias_brutas: str = ""  # Concatenação simples com marcadores
    fase2_chefe_consolidado: str = ""  # Processado pelo Chefe LLM (LOSSLESS)
    fase3_pareceres: List[FaseResult] = field(default_factory=list)
    fase3_presidente: str = ""
    verificacoes_legais: List[VerificacaoLegal] = field(default_factory=list)
    veredicto_final: str = ""
    simbolo_final: str = ""
    status_final: str = ""
    # Q&A
    perguntas_utilizador: List[str] = field(default_factory=list)
    respostas_juizes_qa: List[Dict] = field(default_factory=list)
    respostas_finais_qa: str = ""
    # Timestamps e estatísticas
    timestamp_inicio: datetime = field(default_factory=datetime.now)
    timestamp_fim: Optional[datetime] = None
    total_tokens: int = 0
    total_latencia_ms: float = 0.0
    sucesso: bool = True
    erro: Optional[str] = None

    def to_dict(self) -> Dict:
        return {
            "run_id": self.run_id,
            "documento": self.documento.to_dict() if self.documento else None,
            "area_direito": self.area_direito,
            "fase1_extracoes": [f.to_dict() for f in self.fase1_extracoes],
            "fase1_agregado": self.fase1_agregado,
            "fase1_agregado_bruto": self.fase1_agregado_bruto,
            "fase1_agregado_consolidado": self.fase1_agregado_consolidado,
            "fase2_auditorias": [f.to_dict() for f in self.fase2_auditorias],
            "fase2_chefe": self.fase2_chefe,
            "fase2_auditorias_brutas": self.fase2_auditorias_brutas,
            "fase2_chefe_consolidado": self.fase2_chefe_consolidado,
            "fase3_pareceres": [f.to_dict() for f in self.fase3_pareceres],
            "fase3_presidente": self.fase3_presidente,
            "verificacoes_legais": [v.to_dict() for v in self.verificacoes_legais],
            "veredicto_final": self.veredicto_final,
            "simbolo_final": self.simbolo_final,
            "status_final": self.status_final,
            "perguntas_utilizador": self.perguntas_utilizador,
            "respostas_juizes_qa": self.respostas_juizes_qa,
            "respostas_finais_qa": self.respostas_finais_qa,
            "timestamp_inicio": self.timestamp_inicio.isoformat(),
            "timestamp_fim": self.timestamp_fim.isoformat() if self.timestamp_fim else None,
            "total_tokens": self.total_tokens,
            "total_latencia_ms": self.total_latencia_ms,
            "sucesso": self.sucesso,
            "erro": self.erro,
        }


class TribunalProcessor:
    """
    Processador principal do Tribunal com pipeline de 3 fases + Q&A.

    Fase 1 - EXTRAÇÃO (perguntas_count=0):
        3 LLMs extraem informação do documento
        Agregador concatena e marca origem

    Fase 2 - AUDITORIA (perguntas_count=0):
        3 LLMs auditam a extração
        Chefe concatena e consolida

    Fase 3 - JULGAMENTO (perguntas_count=N):
        3 LLMs emitem parecer jurídico + respondem Q&A

    Fase 4 - PRESIDENTE (perguntas_count=N):
        Presidente verifica e emite veredicto (✓/✗/⚠)
        Consolida respostas Q&A
    """

    # Prompts do sistema
    SYSTEM_EXTRATOR = """És um extrator de informação jurídica especializado em Direito Português.
A tua tarefa é extrair do documento fornecido:
1. Factos relevantes
2. Datas e prazos
3. Partes envolvidas
4. Valores monetários
5. Referências legais (leis, artigos, decretos)
6. Pedidos ou pretensões
7. Documentos mencionados

Sê objetivo, preciso e completo. Usa formato estruturado."""

    SYSTEM_AUDITOR = """És um auditor jurídico especializado em Direito Português.
A tua tarefa é auditar a extração de informação e:
1. Verificar se a extração está completa
2. Identificar inconsistências
3. Apontar informação em falta
4. Avaliar a relevância jurídica dos factos
5. Sugerir legislação portuguesa aplicável

Sê crítico e rigoroso. Fundamenta as tuas observações."""

    SYSTEM_JUIZ = """És um juiz especializado em Direito Português.
Com base na análise e auditoria fornecidas, emite um parecer jurídico que inclua:
1. Enquadramento legal (legislação portuguesa aplicável)
2. Análise dos factos à luz da lei
3. Jurisprudência relevante (se aplicável)
4. Conclusão fundamentada
5. Recomendação (procedente/improcedente/parcialmente procedente)

Cita sempre os artigos específicos da legislação portuguesa."""

    SYSTEM_JUIZ_QA = """És um juiz especializado em Direito Português.
Com base na análise e auditoria fornecidas, emite um parecer jurídico que inclua:
1. Enquadramento legal (legislação portuguesa aplicável)
2. Análise dos factos à luz da lei
3. Jurisprudência relevante (se aplicável)
4. Conclusão fundamentada
5. Recomendação (procedente/improcedente/parcialmente procedente)

Cita sempre os artigos específicos da legislação portuguesa.

IMPORTANTE: Após o parecer, responde às PERGUNTAS DO UTILIZADOR de forma clara e numerada."""

    SYSTEM_PRESIDENTE = """És o Presidente do Tribunal, responsável pela verificação final.
A tua tarefa é:
1. Analisar os pareceres dos juízes
2. Verificar a fundamentação legal
3. Identificar consensos e divergências
4. Emitir o veredicto final

Para cada citação legal, indica:
- ✓ se a citação está correta e aplicável
- ✗ se a citação está incorreta ou não aplicável
- ⚠ se requer atenção ou verificação adicional

Emite o VEREDICTO FINAL:
- PROCEDENTE (✓): se o pedido deve ser deferido
- IMPROCEDENTE (✗): se o pedido deve ser indeferido
- PARCIALMENTE PROCEDENTE (⚠): se apenas parte do pedido procede"""

    SYSTEM_PRESIDENTE_QA = """És o Presidente do Tribunal, responsável pela verificação final.
A tua tarefa é:
1. Analisar os pareceres dos juízes
2. Verificar a fundamentação legal
3. Identificar consensos e divergências
4. Emitir o veredicto final
5. CONSOLIDAR as respostas Q&A dos 3 juízes

Para cada citação legal, indica:
- ✓ se a citação está correta e aplicável
- ✗ se a citação está incorreta ou não aplicável
- ⚠ se requer atenção ou verificação adicional

Emite o VEREDICTO FINAL:
- PROCEDENTE (✓): se o pedido deve ser deferido
- IMPROCEDENTE (✗): se o pedido deve ser indeferido
- PARCIALMENTE PROCEDENTE (⚠): se apenas parte do pedido procede

IMPORTANTE: Após o veredicto, consolida as RESPOSTAS Q&A eliminando contradições e fornecendo respostas finais claras e numeradas."""

    SYSTEM_AGREGADOR = """És o AGREGADOR da Fase 1. Recebes 3 extrações do mesmo documento feitas por modelos diferentes.

TAREFA CRÍTICA - CONSOLIDAÇÃO LOSSLESS:
- NUNCA percas informação única
- Se um extrator encontrou um facto que outros não encontraram, MANTÉM esse facto
- Remove apenas duplicados EXATOS (mesmo facto, mesma data, mesmo valor)

FORMATO OBRIGATÓRIO:

## 1. RESUMO ESTRUTURADO
### Factos Relevantes
- [E1,E2,E3] Facto consensual X
- [E1,E2] Facto Y (parcial)
- [E1] Facto Z (único - OBRIGATÓRIO manter)

### Datas e Prazos
- [E1,E2,E3] DD/MM/AAAA - Descrição

### Partes Envolvidas
- [E1,E2,E3] Nome - Papel/Função

### Valores Monetários
- [E1,E2,E3] €X.XXX,XX - Descrição

### Referências Legais
- [E1,E2,E3] Artigo Xº do Diploma Y
- [E1] Artigo Zº (único - verificar)

### Pedidos/Pretensões
- [E1,E2,E3] Descrição do pedido

### Documentos Mencionados
- [E1,E2] Nome do documento

## 2. DIVERGÊNCIAS ENTRE EXTRATORES
(Se E1 diz X e E2 diz Y sobre o mesmo facto, listar aqui)
- Facto: [descrição]
  - E1: [versão do E1]
  - E2: [versão do E2]
  - E3: [versão do E3 ou "não mencionou"]

## 3. CONTROLO DE COBERTURA (OBRIGATÓRIO)

REGRAS NÃO-NEGOCIÁVEIS:
1) Tens de preencher as 3 subsecções abaixo: [E1], [E2] e [E3]
2) Se um extrator NÃO tiver factos exclusivos, escreve LITERALMENTE:
   "(nenhum — todos os factos foram partilhados)"
3) A "Confirmação" SÓ pode ser "SIM" se as 3 subsecções estiverem preenchidas (com factos ou com "(nenhum — ...)")
4) Se "Confirmação" for "NÃO", OBRIGATORIAMENTE lista cada facto omitido em "ITENS NÃO INCORPORADOS" com razão concreta
5) Quando Confirmação=SIM, para cada item exclusivo listado, indica onde foi incorporado:
   - [E1] facto X → incorporado em: ##1/Factos, linha 3
   - [E2] facto Y → incorporado em: ##1/Datas, linha 1

FORMATO OBRIGATÓRIO PARA FACTOS:
- facto curto e objetivo (máx 100 caracteres)
- NÃO usar "detalhes adicionais" ou textos vagos

**[E1] encontrou exclusivamente:**
- facto A → incorporado em: [secção/linha]
- facto B → incorporado em: [secção/linha]
(ou: "(nenhum — todos os factos foram partilhados)")

**[E2] encontrou exclusivamente:**
- facto C → incorporado em: [secção/linha]
(ou: "(nenhum — todos os factos foram partilhados)")

**[E3] encontrou exclusivamente:**
- facto D → incorporado em: [secção/linha]
(ou: "(nenhum — todos os factos foram partilhados)")

**Confirmação:** SIM
(ou: **Confirmação:** NÃO)
Escreve exatamente "Confirmação: SIM" ou "Confirmação: NÃO" - escolhe apenas um.

**ITENS NÃO INCORPORADOS** (obrigatório se Confirmação=NÃO):
- [EX] facto: motivo concreto da não incorporação
(ou: "(nenhum)" se Confirmação=SIM)

---
LEGENDA:
- [E1,E2,E3] = Consenso total (3 extratores)
- [E1,E2] / [E2,E3] / [E1,E3] = Consenso parcial (2 extratores)
- [E1] / [E2] / [E3] = Único (1 extrator - NUNCA ELIMINAR sem justificação)

REGRA NÃO-NEGOCIÁVEL: Na dúvida, MANTÉM. Melhor redundância que perda de dados."""

    SYSTEM_CHEFE = """És o CHEFE da Fase 2. Recebes 3 auditorias da mesma extração feitas por modelos diferentes.

TAREFA CRÍTICA - CONSOLIDAÇÃO LOSSLESS:
- NUNCA percas críticas únicas
- Se um auditor identificou um problema que outros não viram, MANTÉM essa crítica
- Remove apenas críticas EXATAS duplicadas

FORMATO OBRIGATÓRIO:

## 1. AVALIAÇÃO DA COMPLETUDE
- [A1,A2,A3] Observação consensual X
- [A1] Observação Y (único - OBRIGATÓRIO manter)

## 2. INCONSISTÊNCIAS IDENTIFICADAS
### Críticas (por gravidade)
- [A1,A2,A3] ⚠️ CRÍTICO: Descrição (consenso total)
- [A2,A3] ⚠️ IMPORTANTE: Descrição (parcial)
- [A1] ⚠️ ATENÇÃO: Descrição (único - verificar)

## 3. INFORMAÇÃO EM FALTA
- [A1,A2,A3] Falta: Descrição
- [A2] Falta: Descrição (único)

## 4. RELEVÂNCIA JURÍDICA
- [A1,A2,A3] Análise da relevância
- [A1,A3] Ponto adicional

## 5. LEGISLAÇÃO PORTUGUESA APLICÁVEL
- [A1,A2,A3] Artigo Xº do Diploma Y - Justificação
- [A1] Artigo Zº (sugestão única - verificar aplicabilidade)

## 6. RECOMENDAÇÕES PARA FASE 3
- [A1,A2,A3] Recomendação prioritária
- [A2] Recomendação adicional (único)

## 7. DIVERGÊNCIAS ENTRE AUDITORES
(Se A1 critica X e A2 discorda, listar aqui)
- Tema: [descrição]
  - A1: [posição do A1]
  - A2: [posição do A2]
  - A3: [posição do A3 ou "não mencionou"]

## 8. CONTROLO DE COBERTURA (OBRIGATÓRIO)

REGRAS NÃO-NEGOCIÁVEIS:
1) Tens de preencher as 3 subsecções abaixo: [A1], [A2] e [A3]
2) Se um auditor NÃO tiver críticas exclusivas, escreve LITERALMENTE:
   "(nenhuma — todas as críticas foram partilhadas)"
3) A "Confirmação" SÓ pode ser "SIM" se as 3 subsecções estiverem preenchidas (com críticas ou com "(nenhuma — ...)")
4) Se "Confirmação" for "NÃO", OBRIGATORIAMENTE lista cada crítica omitida em "ITENS NÃO INCORPORADOS" com razão concreta
5) Quando Confirmação=SIM, para cada item exclusivo listado, indica onde foi incorporado:
   - [A1] crítica X → incorporado em: ##2/Inconsistências, linha 3
   - [A2] observação Y → incorporado em: ##1/Completude, linha 1

FORMATO OBRIGATÓRIO PARA CRÍTICAS:
- crítica curta e objetiva (máx 100 caracteres)
- NÃO usar "detalhes adicionais" ou textos vagos

**[A1] encontrou exclusivamente:**
- crítica A → incorporado em: [secção/linha]
- observação B → incorporado em: [secção/linha]
(ou: "(nenhuma — todas as críticas foram partilhadas)")

**[A2] encontrou exclusivamente:**
- crítica C → incorporado em: [secção/linha]
(ou: "(nenhuma — todas as críticas foram partilhadas)")

**[A3] encontrou exclusivamente:**
- crítica D → incorporado em: [secção/linha]
(ou: "(nenhuma — todas as críticas foram partilhadas)")

**Confirmação:** SIM
(ou: **Confirmação:** NÃO)
Escreve exatamente "Confirmação: SIM" ou "Confirmação: NÃO" - escolhe apenas um.

**ITENS NÃO INCORPORADOS** (obrigatório se Confirmação=NÃO):
- [AX] crítica: motivo concreto da não incorporação
(ou: "(nenhum)" se Confirmação=SIM)

---
LEGENDA:
- [A1,A2,A3] = Consenso total (3 auditores)
- [A1,A2] / [A2,A3] / [A1,A3] = Consenso parcial (2 auditores)
- [A1] / [A2] / [A3] = Único (1 auditor - NUNCA ELIMINAR sem justificação)

PRIORIDADE: Validade legal > Inconsistências críticas > Completude > Sugestões

REGRA NÃO-NEGOCIÁVEL: Na dúvida, MANTÉM. Melhor redundância que perda de críticas."""

    def __init__(
        self,
        extrator_models: List[str] = None,
        auditor_models: List[str] = None,
        juiz_models: List[str] = None,
        presidente_model: str = None,
        agregador_model: str = None,
        chefe_model: str = None,
        callback_progresso: Optional[Callable] = None,
    ):
        self.extrator_models = extrator_models or EXTRATOR_MODELS
        self.auditor_models = auditor_models or AUDITOR_MODELS
        self.juiz_models = juiz_models or JUIZ_MODELS
        self.presidente_model = presidente_model or PRESIDENTE_MODEL
        self.agregador_model = agregador_model or AGREGADOR_MODEL
        self.chefe_model = chefe_model or CHEFE_MODEL
        self.callback_progresso = callback_progresso

        self.llm_client = get_llm_client()
        self.legal_verifier = get_legal_verifier()

        self._run_id: Optional[str] = None
        self._output_dir: Optional[Path] = None
        self._titulo: str = ""  # ← NOVO!

    def _reportar_progresso(self, fase: str, progresso: int, mensagem: str):
        """Reporta progresso ao callback."""
        logger.info(f"[{progresso}%] {fase}: {mensagem}")
        if self.callback_progresso:
            self.callback_progresso(fase, progresso, mensagem)

    def _setup_run(self) -> str:
        """Configura uma nova execução."""
        self._run_id = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
        self._output_dir = OUTPUT_DIR / self._run_id
        self._output_dir.mkdir(parents=True, exist_ok=True)
        logger.info(f"Run iniciado: {self._run_id}")
        return self._run_id

    def _log_to_file(self, filename: str, content: str):
        """Guarda conteúdo num ficheiro de log."""
        if self._output_dir:
            filepath = self._output_dir / filename
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(content)

    def _call_llm(
        self,
        model: str,
        prompt: str,
        system_prompt: str,
        role_name: str,
        temperature: float = 0.7,
    ) -> FaseResult:
        """Chama um LLM e retorna o resultado formatado."""
        response = self.llm_client.chat_simple(
            model=model,
            prompt=prompt,
            system_prompt=system_prompt,
            temperature=temperature,
        )

        return FaseResult(
            fase=role_name.split("_")[0],
            modelo=model,
            role=role_name,
            conteudo=response.content,
            tokens_usados=response.total_tokens,
            latencia_ms=response.latency_ms,
            sucesso=response.success,
            erro=response.error,
        )

    def _dividir_documento_chunks(self, texto: str, chunk_size: int = 50000, overlap: int = 2500) -> List[str]:
        """
        Divide documento grande em chunks com overlap para processamento.
        
        Args:
            texto: Texto completo do documento
            chunk_size: Tamanho máximo de cada chunk em caracteres (default 50k)
            overlap: Número de caracteres para sobrepor entre chunks (default 2.5k)
            
        Returns:
            Lista de chunks (strings)
        """
        from src.config import CHUNK_SIZE_CHARS, CHUNK_OVERLAP_CHARS
        
        # Usar valores do config
        chunk_size = CHUNK_SIZE_CHARS
        overlap = CHUNK_OVERLAP_CHARS
        
        # Se documento é pequeno, não dividir
        if len(texto) <= chunk_size:
            logger.info(f"Documento pequeno ({len(texto):,} chars), SEM chunking")
            return [texto]
        
        chunks = []
        inicio = 0
        chunk_num = 0
        
        while inicio < len(texto):
            fim = min(inicio + chunk_size, len(texto))
            chunk = texto[inicio:fim]
            chunks.append(chunk)
            chunk_num += 1
            
            logger.info(f"Chunk {chunk_num}: chars {inicio:,}-{fim:,} (tamanho: {len(chunk):,})")
            
            # Se chegámos ao fim, parar
            if fim >= len(texto):
                break
            
            # Próximo chunk começa com overlap para não perder contexto
            inicio = fim - overlap
        
        logger.info(f"✂️ Documento dividido em {len(chunks)} chunk(s)")
        logger.info(f"📏 Chunk size: {chunk_size:,} | Overlap: {overlap:,} chars")
        
        return chunks

    def _fase1_extracao(self, documento: DocumentContent, area: str) -> tuple:
        """
        Fase 1: 3 Extratores LLM -> Agregador LLM (LOSSLESS).
        NOTA: Extratores são CEGOS a perguntas do utilizador.

        CORREÇÃO #3: Para PDFs com pdf_safe_result, usa batches em vez de string única.

        Returns:
            tuple: (resultados, bruto, consolidado)
        """
        logger.info("Fase 1 - Extratores: perguntas_count=0 (extratores sao cegos a perguntas)")
        self._reportar_progresso("fase1", 10, "Iniciando extracao com 3 LLMs...")

        # CORREÇÃO #3: Verificar se é PDF com pdf_safe_result
        use_batches = (
            hasattr(documento, 'pdf_safe_enabled') and
            documento.pdf_safe_enabled and
            hasattr(documento, 'pdf_safe_result') and
            documento.pdf_safe_result is not None
        )

        if use_batches:
            # Modo BATCH: processar página-a-página
            return self._fase1_extracao_batch(documento, area)

        # Modo TRADICIONAL: string única (para não-PDFs ou PDFs sem pdf_safe)
        # NOVO: Dividir documento em chunks automático se necessário
        chunks = self._dividir_documento_chunks(documento.text)
        num_chunks = len(chunks)
        
        logger.info(f"=== FASE 1: {num_chunks} chunk(s) × 5 extratores = {num_chunks * 5} chamadas LLM ===")
        
        extractor_configs = [cfg for cfg in LLM_CONFIGS if cfg["id"] in ["E1", "E2", "E3", "E4", "E5"]]
        
        resultados = []
        for i, cfg in enumerate(extractor_configs):
            extractor_id = cfg["id"]
            model = cfg["model"]
            role = cfg["role"]
            instructions = cfg["instructions"]
            temperature = cfg.get("temperature", 0.1)
            
            # NOVO: Processar cada chunk deste extrator
            conteudos_chunks = []
            
            for chunk_idx, chunk in enumerate(chunks):
                chunk_info = f" (chunk {chunk_idx+1}/{num_chunks})" if num_chunks > 1 else ""
                
                self._reportar_progresso(
                    "fase1",
                    10 + (i * num_chunks + chunk_idx) * (20 // (len(extractor_configs) * num_chunks)),
                    f"Extrator {extractor_id}{chunk_info}: {model}"
                )
                
                logger.info(f"=== Extrator {extractor_id}{chunk_info} - {model} ===")
                
                # Prompt com info do chunk
                chunk_header = f"[CHUNK {chunk_idx+1}/{num_chunks}] " if num_chunks > 1 else ""
                prompt_especializado = f"""DOCUMENTO A ANALISAR {chunk_header}:
Ficheiro: {documento.filename}
Tipo: {documento.extension}
Área do Direito: {area}
Total documento completo: {len(documento.text):,} caracteres
{"Este chunk: " + str(len(chunk)) + " caracteres" if num_chunks > 1 else ""}

CONTEÚDO{chunk_header}:
{chunk}

{instructions}
"""
                
                resultado_chunk = self._call_llm(
                    model=model,
                    prompt=prompt_especializado,
                    system_prompt=f"Você é um extrator especializado. {instructions[:200]}",
                    role_name=f"extrator_{extractor_id}_chunk{chunk_idx}",
                    temperature=temperature,
                )
                
                conteudos_chunks.append(resultado_chunk.conteudo)
                logger.info(f"✓ Chunk {chunk_idx+1} processado: {len(resultado_chunk.conteudo):,} chars extraídos")
            
            # Consolidar chunks deste extrator
            if num_chunks > 1:
                conteudo_final = "\n\n═══[CHUNK SEGUINTE]═══\n\n".join(conteudos_chunks)
                logger.info(f"✓ Extrator {extractor_id}: {num_chunks} chunks consolidados → {len(conteudo_final):,} chars totais")
            else:
                conteudo_final = conteudos_chunks[0]
            
            # Criar FaseResult consolidado para este extrator
            resultado_consolidado = FaseResult(
                fase="extrator",
                modelo=model,
                role=f"extrator_{extractor_id}",
                conteudo=conteudo_final,
                tokens_usados=sum(len(c) for c in conteudos_chunks) // 4,  # Estimativa: 1 token ≈ 4 chars
                latencia_ms=0,
                sucesso=True,
                erro=None
            )
            
            resultados.append(resultado_consolidado)
            
            # Log do extrator completo (todos os chunks consolidados)
            self._log_to_file(
                f"fase1_extrator_{extractor_id}.md",
                f"# Extrator {extractor_id}: {role}\n## Modelo: {model}\n## Chunks processados: {num_chunks}\n\n{conteudo_final}"
            )

        # Criar agregado BRUTO (concatenação simples dos 5 extratores)
        self._reportar_progresso("fase1", 32, "Criando agregado bruto (5 extratores)...")

        bruto_parts = ["# EXTRAÇÃO AGREGADA (BRUTO) - 5 EXTRATORES\n"]
        for i, r in enumerate(resultados):
            cfg = extractor_configs[i] if i < len(extractor_configs) else {"id": f"E{i+1}", "role": "Extrator"}
            bruto_parts.append(f"\n## [EXTRATOR {cfg['id']}: {cfg['role']} - {r.modelo}]\n")
            bruto_parts.append(r.conteudo)
            bruto_parts.append("\n---\n")

        bruto = "\n".join(bruto_parts)
        self._log_to_file("fase1_agregado_bruto.md", bruto)

        # Chamar Agregador LLM para consolidação LOSSLESS
        self._reportar_progresso("fase1", 35, f"Agregador consolidando {len(extractor_configs)} extrações: {self.agregador_model}")

        prompt_agregador = f"""EXTRAÇÕES DOS {len(extractor_configs)} MODELOS ESPECIALIZADOS:

{bruto}

MISSÃO DO AGREGADOR:
Consolida estas {len(extractor_configs)} extrações numa única extração LOSSLESS.
- E1-E3: Generalistas (contexto jurídico geral)
- E4: Especialista em dados estruturados (datas, valores, referências)
- E5: Especialista em documentos administrativos (anexos, tabelas, formulários)

CRÍTICO: Preservar TODOS os dados numéricos, datas, valores e referências de TODOS os extratores.
Área do Direito: {area}"""

        agregador_result = self._call_llm(
            model=self.agregador_model,
            prompt=prompt_agregador,
            system_prompt=self.SYSTEM_AGREGADOR,
            role_name="agregador",
        )

        consolidado = f"# EXTRAÇÃO CONSOLIDADA (AGREGADOR: {self.agregador_model})\n\n{agregador_result.conteudo}"
        self._log_to_file("fase1_agregado_consolidado.md", consolidado)

        # Backwards compat: guardar também como fase1_agregado.md
        self._log_to_file("fase1_agregado.md", consolidado)

        # DETETOR INTRA-PÁGINA (modo tradicional): verificar sinais não extraídos
        # Funciona mesmo sem pdf_safe, criando PageRecords a partir do texto
        logger.info("=== DETETOR INTRA-PÁGINA: INICIANDO (modo tradicional) ===")
        logger.info(f"=== DETETOR: output_dir = {self._output_dir} ===")
        logger.info(f"=== DETETOR: documento.text tem {len(documento.text)} chars ===")
        try:
            from src.pipeline.pdf_safe import (
                PageRecord, PageMetrics, verificar_cobertura_sinais,
                REGEX_DATAS_PT, REGEX_VALORES_EURO, REGEX_ARTIGOS_PT
            )
            import json as json_module
            logger.info("=== DETETOR: imports OK ===")

            # Extrair páginas do texto usando marcadores [Página X]
            import re
            page_pattern = re.compile(r'\[Página\s*(\d+)\]\s*\n(.*?)(?=\[Página\s*\d+\]|\Z)', re.DOTALL | re.IGNORECASE)
            matches = page_pattern.findall(documento.text)
            logger.info(f"=== DETETOR: {len(matches)} páginas extraídas do texto ===")

            # DEBUG: mostrar primeiros 200 chars do texto para ver formato
            logger.info(f"=== DETETOR: Primeiros 200 chars do texto: {documento.text[:200]!r} ===")

            if matches:
                # Criar PageRecords simplificados para cada página
                pages = []
                for page_num_str, page_text in matches:
                    page_num = int(page_num_str)
                    text_clean = page_text.strip()

                    # Detetar sinais nesta página
                    dates = REGEX_DATAS_PT.findall(text_clean)
                    dates_detected = [d[0] or d[1] for d in dates if d[0] or d[1]]
                    values_detected = REGEX_VALORES_EURO.findall(text_clean)
                    legal_refs_detected = REGEX_ARTIGOS_PT.findall(text_clean)

                    metrics = PageMetrics(
                        chars_raw=len(text_clean),
                        chars_clean=len(text_clean),
                        dates_detected=dates_detected,
                        values_detected=values_detected,
                        legal_refs_detected=legal_refs_detected,
                    )

                    page_record = PageRecord(
                        page_num=page_num,
                        text_raw=text_clean,
                        text_clean=text_clean,
                        metrics=metrics,
                        status_inicial="OK",
                        status_final="OK",
                    )
                    pages.append(page_record)

                logger.info(f"=== DETETOR: {len(pages)} PageRecords criados ===")

                if pages:
                    # Verificar cobertura de sinais pelos extratores
                    extractor_outputs = {f"E{i+1}": r.conteudo for i, r in enumerate(resultados)}
                    signal_report = verificar_cobertura_sinais(pages, extractor_outputs)
                    logger.info(f"=== DETETOR: verificar_cobertura_sinais executado ===")

                    # Guardar relatório de sinais
                    signal_report_path = self._output_dir / "signals_coverage_report.json"
                    logger.info(f"=== DETETOR: A guardar em {signal_report_path} ===")
                    with open(signal_report_path, 'w', encoding='utf-8') as f:
                        json_module.dump(signal_report, f, ensure_ascii=False, indent=2)
                    logger.info(f"=== DETETOR: Relatório GUARDADO com sucesso em {signal_report_path} ===")

                    # Log de sinais não cobertos
                    if signal_report["uncovered_signals"]:
                        logger.warning(f"ALERTA: {len(signal_report['uncovered_signals'])} página(s) com sinais não extraídos")
                        for s in signal_report["uncovered_signals"][:5]:
                            logger.warning(f"  Página {s['page_num']}: {len(s['uncovered'])} sinal(ais) em falta")
                    else:
                        logger.info("Detetor intra-página: todos os sinais foram cobertos")
            else:
                logger.warning("=== DETETOR: NENHUMA página extraída! Texto não tem marcadores [Página X] ===")

        except Exception as e:
            logger.error(f"=== DETETOR FALHOU: {e} ===", exc_info=True)

        return resultados, bruto, consolidado

    def _fase1_extracao_batch(self, documento: DocumentContent, area: str) -> tuple:
        """
        Fase 1 em modo BATCH: processa páginas em lotes de 50k chars.

        CORREÇÃO #3: Não junta tudo numa string única - processa por batches.

        Returns:
            tuple: (resultados, bruto, consolidado)
        """
        from src.pipeline.pdf_safe import batch_pages, CoverageMatrix
        from src.pipeline.extractor_json import (
            SYSTEM_EXTRATOR_JSON,
            build_extractor_input,
            parse_extractor_output,
            extractions_to_markdown,
            merge_extractor_results,
        )

        pdf_result = documento.pdf_safe_result
        pages = pdf_result.pages

        logger.info(f"Fase 1 BATCH: {len(pages)} páginas, PDF Seguro ativado")

        # Dividir páginas em batches
        batches = batch_pages(pages, max_chars=50000)
        logger.info(f"Dividido em {len(batches)} batch(es)")

        # Processar cada extrator em todos os batches
        # USAR 5 EXTRATORES COM PROMPTS ESPECIALIZADOS
        extractor_configs = [cfg for cfg in LLM_CONFIGS if cfg["id"] in ["E1", "E2", "E3", "E4", "E5"]]
        logger.info(f"=== FASE 1 BATCH: Usando {len(extractor_configs)} extratores especializados ===")

        all_extractor_results = []  # Lista de resultados por extrator
        resultados = []  # FaseResult para compatibilidade

        for i, cfg in enumerate(extractor_configs):
            extractor_id = cfg["id"]
            model = cfg["model"]
            role = cfg["role"]
            instructions = cfg["instructions"]
            temperature = cfg.get("temperature", 0.1)

            self._reportar_progresso("fase1", 10 + i * 4, f"Extrator {extractor_id} ({role}): {model} ({len(batches)} batches)")
            logger.info(f"=== Extrator {extractor_id}: {role} - {model} ===")

            extractor_content_parts = []
            extractor_json_results = []

            for batch_idx, batch in enumerate(batches):
                # Construir input JSON para este batch
                json_input = build_extractor_input(batch)
                valid_page_nums = [p["page_num"] for p in batch]

                prompt = f"""DOCUMENTO A ANALISAR (Batch {batch_idx + 1}/{len(batches)}):
Ficheiro: {documento.filename}
Área do Direito: {area}
Total de páginas no documento: {len(pages)}

PÁGINAS NESTE BATCH (JSON):
{json_input}

INSTRUÇÕES ESPECÍFICAS DO EXTRATOR {extractor_id} ({role}):
{instructions}

Extrai informação de CADA página no formato JSON especificado.
IMPORTANTE: Só usa page_num que existam no batch acima."""

                # Chamar LLM com temperature específica
                response = self.llm_client.chat_simple(
                    model=model,
                    prompt=prompt,
                    system_prompt=SYSTEM_EXTRATOR_JSON,
                    temperature=temperature,
                )

                # Parsear e validar output
                parsed = parse_extractor_output(response.content, valid_page_nums, extractor_id)
                extractor_json_results.append(parsed)

                # Converter para markdown para compatibilidade
                md_content = extractions_to_markdown(parsed["extractions"], extractor_id)
                extractor_content_parts.append(f"## Batch {batch_idx + 1}\n{md_content}")

            # Combinar todos os batches deste extrator
            full_content = "\n\n".join(extractor_content_parts)

            # Criar FaseResult para compatibilidade
            resultado = FaseResult(
                fase="extrator",
                modelo=model,
                role=f"extrator_{extractor_id}",
                conteudo=full_content,
                tokens_usados=sum(r.get("tokens", 0) for r in extractor_json_results),
                latencia_ms=0,
                sucesso=True,
            )
            resultados.append(resultado)
            all_extractor_results.append((extractor_id, extractor_json_results))

            # Log individual
            self._log_to_file(f"fase1_extrator_{extractor_id}.md", f"# Extrator {extractor_id}: {role}\n## Modelo: {model}\n\n{full_content}")

            # Guardar JSON para auditoria
            import json as json_module
            json_path = self._output_dir / f"fase1_extractor_{extractor_id}.json"
            with open(json_path, 'w', encoding='utf-8') as f:
                json_module.dump(extractor_json_results, f, ensure_ascii=False, indent=2)

        # Criar matriz de cobertura
        coverage = CoverageMatrix()
        for ext_id, ext_results in all_extractor_results:
            for batch_result in ext_results:
                coverage.add_extraction(ext_id, batch_result.get("pages_covered", []))
                for ur in batch_result.get("pages_unreadable", []):
                    coverage.add_unreadable(ext_id, ur["page_num"], ur.get("reason", ""))

        coverage.finalize(len(pages))
        coverage.save(self._output_dir)

        # DETETOR INTRA-PÁGINA: verificar sinais não extraídos
        from src.pipeline.pdf_safe import verificar_cobertura_sinais
        # Usar IDs dos extratores (E1-E5)
        extractor_outputs = {extractor_configs[i]["id"]: r.conteudo for i, r in enumerate(resultados)}
        signal_report = verificar_cobertura_sinais(pages, extractor_outputs)

        # Guardar relatório de sinais
        import json as json_module
        signal_report_path = self._output_dir / "signals_coverage_report.json"
        with open(signal_report_path, 'w', encoding='utf-8') as f:
            json_module.dump(signal_report, f, ensure_ascii=False, indent=2)

        # Log de sinais não cobertos
        if signal_report["uncovered_signals"]:
            logger.warning(f"ALERTA: {len(signal_report['uncovered_signals'])} página(s) com sinais não extraídos")
            for s in signal_report["uncovered_signals"][:5]:  # Primeiras 5
                logger.warning(f"  Página {s['page_num']}: {len(s['uncovered'])} sinal(ais) em falta")

        # Criar agregado BRUTO (concatenação simples dos 5 extratores)
        self._reportar_progresso("fase1", 32, "Criando agregado bruto (5 extratores)...")

        bruto_parts = ["# EXTRAÇÃO AGREGADA (BRUTO) - MODO BATCH - 5 EXTRATORES\n"]
        for i, r in enumerate(resultados):
            cfg = extractor_configs[i] if i < len(extractor_configs) else {"id": f"E{i+1}", "role": "Extrator"}
            bruto_parts.append(f"\n## [EXTRATOR {cfg['id']}: {cfg['role']} - {r.modelo}]\n")
            bruto_parts.append(r.conteudo)
            bruto_parts.append("\n---\n")

        bruto = "\n".join(bruto_parts)
        self._log_to_file("fase1_agregado_bruto.md", bruto)

        # CORREÇÃO CRÍTICA #1: Agregação HIERÁRQUICA por batch
        # Em vez de truncar, agregar cada batch separadamente e depois consolidar
        self._reportar_progresso("fase1", 35, f"Agregador consolidando {len(extractor_configs)} extrações: {self.agregador_model}")

        if len(bruto) <= 60000:
            # Caso simples: cabe numa única chamada
            prompt_agregador = f"""EXTRAÇÕES DOS {len(extractor_configs)} MODELOS ESPECIALIZADOS (MODO BATCH - {len(pages)} páginas):

{bruto}

MISSÃO DO AGREGADOR:
Consolida estas {len(extractor_configs)} extrações numa única extração LOSSLESS.
- E1-E3: Generalistas (contexto jurídico geral)
- E4: Especialista em dados estruturados (datas, valores, referências)
- E5: Especialista em documentos administrativos (anexos, tabelas, formulários)

CRÍTICO: Preservar TODOS os dados numéricos, datas, valores e referências de TODOS os extratores.
Área do Direito: {area}

NOTA: As extrações foram feitas por página. Mantém referências de página quando relevante."""

            agregador_result = self._call_llm(
                model=self.agregador_model,
                prompt=prompt_agregador,
                system_prompt=self.SYSTEM_AGREGADOR,
                role_name="agregador",
            )
            consolidado = f"# EXTRAÇÃO CONSOLIDADA (AGREGADOR: {self.agregador_model})\n\n{agregador_result.conteudo}"

        else:
            # AGREGAÇÃO HIERÁRQUICA: processar batches separadamente
            logger.info(f"Agregação hierárquica necessária: {len(bruto)} chars > 60000")
            self._reportar_progresso("fase1", 31, "Agregação hierárquica por batches...")

            # Dividir os resultados dos extratores por batch
            batch_consolidados = []

            for batch_idx, batch in enumerate(batches):
                batch_pages = [p["page_num"] for p in batch]
                self._reportar_progresso(
                    "fase1",
                    32 + (batch_idx * 5 // len(batches)),
                    f"Agregando batch {batch_idx + 1}/{len(batches)} (pgs {batch_pages[0]}-{batch_pages[-1]})"
                )

                # Construir bruto deste batch
                batch_bruto_parts = [f"# BATCH {batch_idx + 1} (Páginas {batch_pages[0]}-{batch_pages[-1]})\n"]

                for i, r in enumerate(resultados):
                    # Filtrar conteúdo deste batch do extrator
                    batch_marker = f"## Batch {batch_idx + 1}"
                    content = r.conteudo

                    # Procurar secção deste batch
                    if batch_marker in content:
                        start = content.find(batch_marker)
                        end = content.find("## Batch ", start + len(batch_marker))
                        if end == -1:
                            batch_content = content[start:]
                        else:
                            batch_content = content[start:end]
                    else:
                        # Fallback: usar todo conteúdo (para batch único)
                        batch_content = content

                    batch_bruto_parts.append(f"\n### [EXTRATOR {i+1}: {r.modelo}]\n")
                    batch_bruto_parts.append(batch_content)
                    batch_bruto_parts.append("\n---\n")

                batch_bruto = "\n".join(batch_bruto_parts)

                # Agregar este batch
                prompt_batch = f"""EXTRAÇÕES DOS 3 MODELOS - BATCH {batch_idx + 1}/{len(batches)}
Páginas: {batch_pages[0]} a {batch_pages[-1]}

{batch_bruto}

Consolida estas extrações do BATCH {batch_idx + 1} numa extração LOSSLESS.
Área do Direito: {area}

IMPORTANTE: Mantém referências de página específicas."""

                batch_result = self._call_llm(
                    model=self.agregador_model,
                    prompt=prompt_batch,
                    system_prompt=self.SYSTEM_AGREGADOR,
                    role_name=f"agregador_batch_{batch_idx + 1}",
                )

                batch_consolidados.append({
                    "batch": batch_idx + 1,
                    "pages": f"{batch_pages[0]}-{batch_pages[-1]}",
                    "consolidado": batch_result.conteudo,
                })

                # Log do batch
                self._log_to_file(
                    f"fase1_agregado_batch_{batch_idx + 1}.md",
                    f"# BATCH {batch_idx + 1} (Páginas {batch_pages[0]}-{batch_pages[-1]})\n\n{batch_result.conteudo}"
                )

            # AGREGAÇÃO FINAL: consolidar todos os batches
            self._reportar_progresso("fase1", 38, "Consolidação final de todos os batches...")

            batches_concat = "\n\n".join([
                f"## BATCH {b['batch']} (Páginas {b['pages']})\n\n{b['consolidado']}\n---"
                for b in batch_consolidados
            ])

            prompt_final = f"""CONSOLIDAÇÃO FINAL DE TODOS OS BATCHES
Total de batches: {len(batch_consolidados)}
Total de páginas: {len(pages)}
Área do Direito: {area}

{batches_concat}

TAREFA: Consolida TODOS os batches numa extração FINAL LOSSLESS.
- Mantém TODA informação única de cada batch
- Remove apenas duplicados EXATOS
- Preserva referências de página"""

            final_result = self._call_llm(
                model=self.agregador_model,
                prompt=prompt_final,
                system_prompt=self.SYSTEM_AGREGADOR,
                role_name="agregador_final",
            )

            consolidado = f"# EXTRAÇÃO CONSOLIDADA (AGREGADOR HIERÁRQUICO: {self.agregador_model})\n"
            consolidado += f"## Processado em {len(batch_consolidados)} batches\n\n"
            consolidado += final_result.conteudo

        self._log_to_file("fase1_agregado_consolidado.md", consolidado)
        self._log_to_file("fase1_agregado.md", consolidado)

        return resultados, bruto, consolidado

    def _fase2_auditoria(self, agregado_fase1: str, area: str) -> tuple:
        """
        Fase 2: 3 Auditores LLM -> Chefe LLM (LOSSLESS).
        NOTA: Auditores são CEGOS a perguntas do utilizador.

        Returns:
            tuple: (resultados, bruto, consolidado)
        """
        logger.info("Fase 2 - Auditores: perguntas_count=0 (auditores sao cegos a perguntas)")
        self._reportar_progresso("fase2", 35, "Iniciando auditoria com 3 LLMs...")

        prompt_base = f"""EXTRAÇÃO A AUDITAR:
Área do Direito: {area}

{agregado_fase1}

Audita a extração acima, verificando completude, precisão e relevância jurídica."""

        resultados = []
        for i, model in enumerate(self.auditor_models):
            self._reportar_progresso("fase2", 40 + i * 5, f"Auditor {i+1}: {model}")

            resultado = self._call_llm(
                model=model,
                prompt=prompt_base,
                system_prompt=self.SYSTEM_AUDITOR,
                role_name=f"auditor_{i+1}",
            )
            resultados.append(resultado)

            self._log_to_file(f"fase2_auditor_{i+1}.md", f"# Auditor {i+1}: {model}\n\n{resultado.conteudo}")

        # Criar auditorias BRUTAS (concatenação simples)
        self._reportar_progresso("fase2", 53, "Criando auditorias brutas...")

        bruto_parts = ["# AUDITORIAS AGREGADAS (BRUTO)\n"]
        for i, r in enumerate(resultados):
            bruto_parts.append(f"\n## [AUDITOR {i+1}: {r.modelo}]\n")
            bruto_parts.append(r.conteudo)
            bruto_parts.append("\n---\n")

        bruto = "\n".join(bruto_parts)
        self._log_to_file("fase2_auditorias_brutas.md", bruto)

        # Chamar Chefe LLM para consolidação LOSSLESS
        self._reportar_progresso("fase2", 55, f"Chefe consolidando: {self.chefe_model}")

        prompt_chefe = f"""AUDITORIAS DOS 3 MODELOS:

{bruto}

Consolida estas 3 auditorias numa única auditoria LOSSLESS.
Área do Direito: {area}"""

        chefe_result = self._call_llm(
            model=self.chefe_model,
            prompt=prompt_chefe,
            system_prompt=self.SYSTEM_CHEFE,
            role_name="chefe",
        )

        consolidado = f"# AUDITORIA CONSOLIDADA (CHEFE: {self.chefe_model})\n\n{chefe_result.conteudo}"
        self._log_to_file("fase2_chefe_consolidado.md", consolidado)

        # Backwards compat: guardar também como fase2_chefe.md
        self._log_to_file("fase2_chefe.md", consolidado)

        return resultados, bruto, consolidado

    def _fase3_julgamento(self, chefe_fase2: str, area: str, perguntas: List[str]) -> tuple:
        """
        Fase 3: 3 Juízes LLM -> Parecer + Q&A.
        NOTA: Juízes RECEBEM as perguntas do utilizador.
        """
        n_perguntas = len(perguntas)
        logger.info(f"Fase 3 - Juizes: perguntas_count={n_perguntas}")
        self._reportar_progresso("fase3", 60, f"Iniciando julgamento com 3 LLMs... ({n_perguntas} perguntas)")

        # Construir bloco de perguntas se houver
        bloco_qa = ""
        if perguntas:
            perguntas_formatadas = "\n".join([f"{i+1}. {p}" for i, p in enumerate(perguntas)])
            bloco_qa = f"""

## PERGUNTAS DO UTILIZADOR

{perguntas_formatadas}

**Instruções para Q&A:**
- Responda a cada pergunta numerada
- Base-se nos documentos e legislação portuguesa
- Marque claramente cada resposta por número
- Se não tiver certeza, marque como "não confirmado"
"""

        prompt_base = f"""ANÁLISE AUDITADA DO CASO:
Área do Direito: {area}

{chefe_fase2}

Com base na análise acima, emite o teu parecer jurídico fundamentado.{bloco_qa}"""

        # Escolher system prompt apropriado
        system_prompt = self.SYSTEM_JUIZ_QA if perguntas else self.SYSTEM_JUIZ

        resultados = []
        respostas_qa = []

        for i, model in enumerate(self.juiz_models):
            self._reportar_progresso("fase3", 65 + i * 5, f"Juiz {i+1}: {model}")

            resultado = self._call_llm(
                model=model,
                prompt=prompt_base,
                system_prompt=system_prompt,
                role_name=f"juiz_{i+1}",
            )
            resultados.append(resultado)

            # Guardar resposta Q&A
            respostas_qa.append({
                "juiz": i + 1,
                "modelo": model,
                "resposta": resultado.conteudo
            })

            self._log_to_file(f"fase3_juiz_{i+1}.md", f"# Juiz {i+1}: {model}\n\n{resultado.conteudo}")

        # Guardar ficheiro Q&A dos juízes (se houver perguntas)
        if perguntas:
            qa_content = self._gerar_qa_juizes(perguntas, respostas_qa)
            self._log_to_file("fase3_qa_respostas.md", qa_content)

        return resultados, respostas_qa

    def _fase4_presidente(self, pareceres: List[FaseResult], perguntas: List[str], respostas_qa: List[Dict]) -> str:
        """
        Fase 4: Presidente verifica + consolida Q&A.
        NOTA: Presidente RECEBE as perguntas e respostas dos juízes.
        """
        n_perguntas = len(perguntas)
        logger.info(f"Fase 4 - Presidente: perguntas_count={n_perguntas}")
        self._reportar_progresso("fase4", 80, f"Presidente verificando: {self.presidente_model}")

        # Concatenar pareceres
        pareceres_concat = "\n\n".join([
            f"## [JUIZ {i+1}: {r.modelo}]\n{r.conteudo}\n---"
            for i, r in enumerate(pareceres)
        ])

        # Construir bloco Q&A para presidente
        bloco_qa = ""
        if perguntas:
            perguntas_formatadas = "\n".join([f"{i+1}. {p}" for i, p in enumerate(perguntas)])
            respostas_formatadas = "\n\n".join([
                f"### Juiz {r['juiz']} ({r['modelo']}):\n{r['resposta']}"
                for r in respostas_qa
            ])
            bloco_qa = f"""

## CONSOLIDAÇÃO DE RESPOSTAS Q&A

### PERGUNTAS ORIGINAIS:
{perguntas_formatadas}

### RESPOSTAS DOS 3 JUÍZES:
{respostas_formatadas}

**Instruções para consolidação Q&A:**
- Para cada pergunta, consolide as 3 respostas
- Elimine contradições
- Forneça resposta final clara e fundamentada
- Numere as respostas finais
"""

        prompt_presidente = f"""PARECERES DOS JUÍZES:

{pareceres_concat}

Analisa os pareceres, verifica as citações legais, e emite o VEREDICTO FINAL.{bloco_qa}"""

        # Escolher system prompt apropriado
        system_prompt = self.SYSTEM_PRESIDENTE_QA if perguntas else self.SYSTEM_PRESIDENTE

        presidente_result = self._call_llm(
            model=self.presidente_model,
            prompt=prompt_presidente,
            system_prompt=system_prompt,
            role_name="presidente",
        )

        self._log_to_file("fase4_presidente.md", f"# PRESIDENTE: {self.presidente_model}\n\n{presidente_result.conteudo}")

        # Guardar ficheiro Q&A final (se houver perguntas)
        if perguntas:
            qa_final = self._gerar_qa_final(perguntas, presidente_result.conteudo)
            self._log_to_file("fase4_qa_final.md", qa_final)

        return presidente_result.conteudo

    def _gerar_qa_juizes(self, perguntas: List[str], respostas_qa: List[Dict]) -> str:
        """Gera ficheiro markdown com respostas Q&A dos juízes."""
        linhas = [
            "# RESPOSTAS Q&A DOS JUÍZES",
            "",
            "## Perguntas do Utilizador",
            "",
        ]

        for i, p in enumerate(perguntas, 1):
            linhas.append(f"{i}. {p}")

        linhas.append("")
        linhas.append("---")
        linhas.append("")

        for r in respostas_qa:
            linhas.append(f"## Juiz {r['juiz']} ({r['modelo']})")
            linhas.append("")
            linhas.append(r['resposta'])
            linhas.append("")
            linhas.append("---")
            linhas.append("")

        return "\n".join(linhas)

    def _gerar_qa_final(self, perguntas: List[str], resposta_presidente: str) -> str:
        """Gera ficheiro markdown com Q&A consolidado pelo presidente."""
        linhas = [
            "# RESPOSTAS FINAIS (CONSOLIDADO PRESIDENTE)",
            "",
            "## Perguntas",
            "",
        ]

        for i, p in enumerate(perguntas, 1):
            linhas.append(f"{i}. {p}")

        linhas.append("")
        linhas.append("---")
        linhas.append("")
        linhas.append("## Respostas Consolidadas")
        linhas.append("")
        linhas.append(resposta_presidente)

        return "\n".join(linhas)

    def _verificar_legislacao(self, texto: str) -> List[VerificacaoLegal]:
        """Verifica todas as citações legais no texto."""
        self._reportar_progresso("verificacao", 90, "Verificando citacoes legais...")

        citacoes, verificacoes = self.legal_verifier.verificar_texto(texto)

        # Gerar relatório
        relatorio = self.legal_verifier.gerar_relatorio(verificacoes)
        self._log_to_file("verificacao_legal.md", relatorio)

        return verificacoes

    def _determinar_veredicto(self, texto_presidente: str) -> tuple:
        """Extrai o veredicto final do texto do presidente."""
        texto_upper = texto_presidente.upper()

        if "PROCEDENTE" in texto_upper and "IMPROCEDENTE" not in texto_upper:
            if "PARCIALMENTE" in texto_upper:
                return "PARCIALMENTE PROCEDENTE", SIMBOLOS_VERIFICACAO["atencao"], "atencao"
            return "PROCEDENTE", SIMBOLOS_VERIFICACAO["aprovado"], "aprovado"
        elif "IMPROCEDENTE" in texto_upper:
            return "IMPROCEDENTE", SIMBOLOS_VERIFICACAO["rejeitado"], "rejeitado"
        else:
            return "INCONCLUSIVO", SIMBOLOS_VERIFICACAO["atencao"], "atencao"

    def processar(
        self,
        documento: DocumentContent,
        area_direito: str,
        perguntas_raw: str = "",
        titulo: str = "",  # ← NOVO!
    ) -> PipelineResult:
        """
        Executa o pipeline completo.

        Args:
            documento: Documento carregado
            area_direito: Área do direito
            perguntas_raw: Texto bruto com perguntas (separadas por ---)
            titulo: Título do projeto (opcional)

        Returns:
            PipelineResult com todos os resultados
        """
        run_id = self._setup_run()
        timestamp_inicio = datetime.now()

        # Parse e validação de perguntas
        perguntas = parse_perguntas(perguntas_raw)
        if perguntas:
            pode_continuar, msg = validar_perguntas(perguntas)
            if not pode_continuar:
                raise ValueError(f"Perguntas invalidas: {msg}")
            logger.info(f"Processando {len(perguntas)} pergunta(s) do utilizador")
        else:
            logger.info("Sem perguntas do utilizador")
        
        # ← NOVO: Gerar título automático se não fornecido
        if not titulo:
            titulo = gerar_titulo_automatico(documento.filename, area_direito)
        
        self._titulo = titulo  # ← NOVO: Guardar para usar em _guardar_resultado

        result = PipelineResult(
            run_id=run_id,
            documento=documento,
            area_direito=area_direito,
            perguntas_utilizador=perguntas,
            timestamp_inicio=timestamp_inicio,
        )

        try:
            # Fase 1: Extração (SEM perguntas) + Agregador LOSSLESS
            extracoes, bruto_f1, consolidado_f1 = self._fase1_extracao(documento, area_direito)
            result.fase1_extracoes = extracoes
            result.fase1_agregado_bruto = bruto_f1
            result.fase1_agregado_consolidado = consolidado_f1
            result.fase1_agregado = consolidado_f1  # Backwards compat

            # Fase 2: Auditoria (SEM perguntas) + Chefe LOSSLESS
            auditorias, bruto_f2, consolidado_f2 = self._fase2_auditoria(consolidado_f1, area_direito)
            result.fase2_auditorias = auditorias
            result.fase2_auditorias_brutas = bruto_f2
            result.fase2_chefe_consolidado = consolidado_f2
            result.fase2_chefe = consolidado_f2  # Backwards compat

            # Fase 3: Julgamento (COM perguntas)
            pareceres, respostas_qa = self._fase3_julgamento(consolidado_f2, area_direito, perguntas)
            result.fase3_pareceres = pareceres
            result.respostas_juizes_qa = respostas_qa

            # Fase 4: Presidente (COM perguntas)
            presidente = self._fase4_presidente(pareceres, perguntas, respostas_qa)
            result.fase3_presidente = presidente
            result.respostas_finais_qa = presidente if perguntas else ""

            # Verificação Legal
            verificacoes = self._verificar_legislacao(presidente)
            result.verificacoes_legais = verificacoes

            # Determinar veredicto
            veredicto, simbolo, status = self._determinar_veredicto(presidente)
            result.veredicto_final = veredicto
            result.simbolo_final = simbolo
            result.status_final = status

            # Calcular totais
            todos_resultados = extracoes + auditorias + pareceres
            result.total_tokens = sum(r.tokens_usados for r in todos_resultados)
            result.total_latencia_ms = sum(r.latencia_ms for r in todos_resultados)

            result.sucesso = True
            self._reportar_progresso("concluido", 100, "Pipeline concluido!")

        except Exception as e:
            logger.error(f"Erro no pipeline: {e}")
            result.sucesso = False
            result.erro = str(e)

        result.timestamp_fim = datetime.now()

        # Guardar resultado completo
        self._guardar_resultado(result)

        return result

    def _guardar_resultado(self, result: PipelineResult):
        """Guarda o resultado completo em JSON."""
        if self._output_dir:
            # JSON completo
            json_path = self._output_dir / "resultado.json"
            with open(json_path, "w", encoding="utf-8") as f:
                json.dump(result.to_dict(), f, ensure_ascii=False, indent=2)

            # Markdown resumido
            md_path = self._output_dir / "RESUMO.md"
            md_content = self._gerar_resumo_md(result)
            with open(md_path, "w", encoding="utf-8") as f:
                f.write(md_content)

            # Copiar para histórico
            historico_path = HISTORICO_DIR / f"{result.run_id}.json"
            with open(historico_path, "w", encoding="utf-8") as f:
                json.dump(result.to_dict(), f, ensure_ascii=False, indent=2)
            
            # ← NOVO: Guardar metadata (título, descrição, etc.)
            guardar_metadata(
                run_id=result.run_id,
                output_dir=OUTPUT_DIR,
                titulo=self._titulo,
                descricao="",
                area_direito=result.area_direito,
                num_documentos=1 if result.documento else 0
            )

            logger.info(f"Resultados guardados em: {self._output_dir}")

    def _gerar_resumo_md(self, result: PipelineResult) -> str:
        """Gera um resumo em Markdown."""
        linhas = [
            f"# TRIBUNAL GOLDENMASTER - RESULTADO",
            f"",
            f"**Run ID:** {result.run_id}",
            f"**Data:** {result.timestamp_inicio.strftime('%d/%m/%Y %H:%M')}",
            f"**Documento:** {result.documento.filename if result.documento else 'N/A'}",
            f"**Area:** {result.area_direito}",
            f"**Perguntas Q&A:** {len(result.perguntas_utilizador)}",
            f"",
            f"---",
            f"",
            f"## {result.simbolo_final} VEREDICTO FINAL: {result.veredicto_final}",
            f"",
            f"---",
            f"",
            f"## Estatisticas",
            f"- Total de tokens: {result.total_tokens}",
            f"- Latencia total: {result.total_latencia_ms:.0f}ms",
            f"- Citacoes legais verificadas: {len(result.verificacoes_legais)}",
            f"",
            f"---",
            f"",
            f"## Ficheiros de Output",
            f"",
            f"### Fase 1: Extracao",
            f"- `fase1_extrator_1.md` - Extrator 1",
            f"- `fase1_extrator_2.md` - Extrator 2",
            f"- `fase1_extrator_3.md` - Extrator 3",
            f"- `fase1_agregado_bruto.md` - 3 extracoes concatenadas",
            f"- `fase1_agregado_consolidado.md` - **Extracao LOSSLESS (Agregador)**",
            f"",
            f"### Fase 2: Auditoria",
            f"- `fase2_auditor_1.md` - Auditor 1",
            f"- `fase2_auditor_2.md` - Auditor 2",
            f"- `fase2_auditor_3.md` - Auditor 3",
            f"- `fase2_auditorias_brutas.md` - 3 auditorias concatenadas",
            f"- `fase2_chefe_consolidado.md` - **Auditoria LOSSLESS (Chefe)**",
            f"",
            f"### Fase 3: Julgamento",
            f"- `fase3_juiz_1.md` - Juiz 1",
            f"- `fase3_juiz_2.md` - Juiz 2",
            f"- `fase3_juiz_3.md` - Juiz 3",
            f"",
            f"### Fase 4: Presidente",
            f"- `fase4_presidente.md` - Decisao final",
            f"- `verificacao_legal.md` - Relatorio de verificacao DRE",
            f"",
            f"---",
            f"",
            f"## Verificacoes Legais",
        ]

        for v in result.verificacoes_legais:
            linhas.append(f"- {v.simbolo} {v.citacao.texto_normalizado}")

        # Adicionar perguntas Q&A se houver
        if result.perguntas_utilizador:
            linhas.extend([
                f"",
                f"---",
                f"",
                f"## Perguntas do Utilizador",
                f"",
            ])
            for i, p in enumerate(result.perguntas_utilizador, 1):
                linhas.append(f"{i}. {p}")

        linhas.extend([
            f"",
            f"---",
            f"",
            f"## Decisao do Presidente",
            f"",
            result.fase3_presidente,
        ])

        return "\n".join(linhas)

    def processar_texto(self, texto: str, area_direito: str, perguntas_raw: str = "") -> PipelineResult:
        """Processa texto diretamente (sem ficheiro)."""
        documento = DocumentContent(
            filename="texto_direto.txt",
            extension=".txt",
            text=texto,
            num_chars=len(texto),
            num_words=len(texto.split()),
            success=True,
        )
        return self.processar(documento, area_direito, perguntas_raw)

    def listar_runs(self) -> List[Dict]:
        """Lista todas as execuções no histórico."""
        runs = []
        for filepath in HISTORICO_DIR.glob("*.json"):
            try:
                with open(filepath, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    runs.append({
                        "run_id": data.get("run_id"),
                        "timestamp": data.get("timestamp_inicio"),
                        "documento": data.get("documento", {}).get("filename"),
                        "veredicto": data.get("veredicto_final"),
                        "simbolo": data.get("simbolo_final"),
                        "perguntas": len(data.get("perguntas_utilizador", [])),
                    })
            except Exception as e:
                logger.warning(f"Erro ao ler {filepath}: {e}")

        return sorted(runs, key=lambda x: x.get("timestamp", ""), reverse=True)

    def carregar_run(self, run_id: str) -> Optional[Dict]:
        """Carrega os detalhes de uma execução."""
        filepath = HISTORICO_DIR / f"{run_id}.json"
        if filepath.exists():
            with open(filepath, "r", encoding="utf-8") as f:
                return json.load(f)
        return None
