# -*- coding: utf-8 -*-
"""
Tribunal GoldenMaster GUI - Sistema de Análise Jurídica
Pipeline de 3 Fases com LLMs | Direito Português
"""

__version__ = "2.0.0"
__author__ = "Tribunal GoldenMaster"
