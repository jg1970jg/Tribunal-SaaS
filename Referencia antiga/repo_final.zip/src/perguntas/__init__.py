# -*- coding: utf-8 -*-
"""
Módulo PERGUNTAS ADICIONAIS (isolado)

Este módulo é completamente independente do pipeline principal!
"""

__version__ = "1.0.0"
__author__ = "Tribunal GoldenMaster"
