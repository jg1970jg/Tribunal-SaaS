# -*- coding: utf-8 -*-
"""
Módulo UI - Componentes Streamlit.
"""
