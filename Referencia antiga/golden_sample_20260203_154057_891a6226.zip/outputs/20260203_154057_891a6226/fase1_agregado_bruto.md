# EXTRAÇÃO AGREGADA (BRUTO) - 5 EXTRATORES


## [EXTRATOR E1: Extrator Completo - anthropic/claude-opus-4.5]

# EXTRAÇÃO COMPLETA DO DOCUMENTO

## IDENTIFICAÇÃO DO DOCUMENTO

**Tipo:** Contrato de Arrendamento para Fins Habitacionais com Prazo Certo
**Ficheiro:** pdf pesquisavel contrato arrendamento goncalo santos.pdf
**Área do Direito:** Civil
**Total de páginas:** 5

---

## PARTES E IDENTIFICAÇÃO

### SENHORIO (PRIMEIRO OUTORGANTE)

| Campo | Informação |
|-------|------------|
| **Nome completo** | HENRIQUE MIGUEL MOURA DE SENA |
| **NIF** | 269805672 |
| **Estado civil** | Solteiro |
| **Cartão de Cidadão n°** | 13965402 0ZY9 |
| **Validade CC** | 03/08/2031 |
| **Entidade emissora** | República Portuguesa |
| **Morada** | Avenida 25 de Abril, N° 93 1o DTO A em Cascais |

### ARRENDATÁRIOS (SEGUNDOS OUTORGANTES)

#### Arrendatário 1:

| Campo | Informação |
|-------|------------|
| **Nome completo** | GONÇALO FILIPE CÔRTE JOAQUIM MARQUES DOS SANTOS |
| **NIF** | 221544470 |
| **Estado civil** | Casado em regime da comunhão de adquiridos |
| **Cartão de Cidadão n°** | 12958206 9 ZV0 |
| **Validade CC** | 13/08/2029 |
| **Entidade emissora** | República Portuguesa |

#### Arrendatário 2:

| Campo | Informação |
|-------|------------|
| **Nome completo** | FILIPA GOMES JOAQUIM MARQUES DOS SANTOS |
| **NIF** | 223841366 |
| **Estado civil** | Casada em regime da comunhão de adquiridos |
| **Cartão de Cidadão n°** | 12826409 8 ZW4 |
| **Validade CC** | 13/08/2029 |
| **Entidade emissora** | República Portuguesa |

---

## OBJETO DO CONTRATO - IMÓVEL

| Campo | Informação |
|-------|------------|
| **Descrição** | Fração Autónoma 2D |
| **Correspondente a** | 2o DTO, N° 137 |
| **Tipo de prédio** | Prédio urbano |
| **Localização** | Rua Tomas da Anunciação |
| **Freguesia** | Campo de Ourique |
| **Concelho** | Lisboa |
| **Código postal** | 1350-325 LISBOA |
| **Conservatória** | Conservatória do Registo Predial de Lisboa |
| **Artigo Matricial** | N° 661 |
| **Certificado Energético** | SCE235939031 |

---

## CRONOLOGIA E DATAS

| Data | Evento/Descrição |
|------|------------------|
| **15 de janeiro de 2023** | Início do contrato |
| **15 de janeiro de 2023** | Data de assinatura do contrato |
| **31 de dezembro de 2025** | Termo do prazo inicial do contrato |
| **01 de março de 2023** | Data de pagamento do mês de junho de 2023 |
| **03/08/2031** | Validade do CC do Senhorio |
| **13/08/2029** | Validade do CC dos Arrendatários |

---

## VALORES MONETÁRIOS

| Descrição | Valor |
|-----------|-------|
| **Renda mensal** | €: 1.100,00 (Mil e cem euros) |
| **Quantia entregue na assinatura** | €: 4.950,00 (Quatro mil novecentos e cinquenta euros) |
| **Caução** | €: 1.100,00 (Mil e cem euros) |
| **Indemnização por mora no pagamento** | 20 % das rendas em dívida |
| **Indemnização por não restituição (mora)** | Dobro do valor da renda |

### Decomposição da quantia de €4.950,00:
- 15 dias do mês de janeiro de 2023
- Mês de fevereiro de 2023
- Mês de março de 2023
- Mês de abril de 2023
- Mês de maio de 2023

---

## PRAZOS CONTRATUAIS E LEGAIS

| Prazo | Descrição |
|-------|-----------|
| **3 (três) anos** | Prazo certo do contrato |
| **3 (três) anos** | Período de renovação automática |
| **120 (cento e vinte) dias** | Antecedência mínima para o Senhorio impedir renovação automática |
| **90 (noventa) dias** | Antecedência mínima para os Arrendatários impedirem renovação automática |
| **90 (noventa) dias** | Antecedência mínima para denúncia pelos Arrendatários após 1/3 do prazo |
| **Um terço do prazo inicial** | Período após o qual os Arrendatários podem denunciar |
| **30 (trinta) dias** | Antecedência mínima para comunicação de atualização de renda |
| **60 (Sessenta) dias** | Prazo máximo para devolução da caução após termo do arrendamento |
| **Dois meses** | Período anterior ao término para mostrar o imóvel |

---

## REFERÊNCIAS LEGAIS

| Diploma/Artigo | Contexto |
|----------------|----------|
| **Artigo 1095°, n° 1, do Código Civil** | Celebração do contrato com prazo certo |
| **Alínea b) do número 1 do artigo 1097.° do Código Civil** | Impedimento de renovação automática pelo Senhorio |
| **Alínea a) do número 3 do artigo 1098.° do Código Civil** | Denúncia do contrato pelos Arrendatários |
| **Artigo 1077°, n°2, do Código Civil** | Atualizações legais anuais da renda |
| **Regulamento (UE) 2016/679 do Parlamento Europeu e do Conselho de 27 de abril de 2016** | Proteção de dados pessoais (RGPD) |
| **Lei n.° 58/2019 de 8 de agosto** | Lei de proteção de dados pessoais portuguesa |

---

## DADOS BANCÁRIOS

| Campo | Informação |
|-------|------------|
| **IBAN** | PT50 0036 0026 9910 0089 3877 1 |
| **Banco** | CAIXA ECONÓMICA MONTEPIO GERAL |
| **Forma de pagamento** | Transferência ou depósito bancário |
| **Data de pagamento** | Primeiro dia útil de cada mês |

---

## CLÁUSULAS CONTRATUAIS - CONTEÚDO VERBATIM

### CLÁUSULA PRIMEIRA (Objeto)

1- O Senhorio é proprietário e legítimo possuidor da Fração Autónoma 2D, correspondente ao 2o DTO, N° 137 do prédio urbano sito na Rua Tomas da Anunciação, freguesia de Campo de Ourique, concelho de Lisboa, código postal: 1350-325 LISBOA, descrito na Conservatória do Registo Predial de Lisboa, inscrito na Matriz sob o Artigo N° 661, Certificado de Desempenho Energético e da Qualidade do Ar Interior com o N° SCE235939031, sob os termos e cláusulas seguintes:

### CLÁUSULA SEGUNDA (Prazo e Renda)

1- O presente contrato é celebrado pelo prazo certo de 3 (três) anos, com início em 15 de janeiro de 2023 e termo em 31 de dezembro de 2025, renovando-se automaticamente por iguais períodos de 3 (três) anos, desde que não ocorra denúncia por qualquer das partes nos termos das cláusulas seguintes, sendo o mesmo celebrado nos termos e com efeitos previstos no artigo 1095°, n° 1, do Código Civil.

2- O Senhorio pode impedir a renovação automática do contrato mediante comunicação aos Arrendatários, com a antecedência mínima de 120 (cento e vinte) dias sem relação ao termo do prazo de duração inicial do contrato ou da sua renovação, conforme previsto na alínea b) do númerol do artigo 1097.° do Código Civil.

3- Os Arrendatários podem impedir a renovação automática do contrato mediante comunicação ao Senhorio, com a antecedência mínima de 90 (noventa) dias.

4- Decorrido um terço do prazo inicial do contrato ou da sua renovação, os Arrendatários podem denunciá-lo a todo o tempo, mediante comunicação ao Senhorio, expedida com a antecedência mínima de 90 (noventa) dias do termo pretendido do contrato, conforme previsto na alínea a) do número 3 do artigo 1098.° do Código Civil.

5- A renda mensal a pagar pelos Arrendatários ao Senhorio é de €: 1.100,00 (Mil e cem euros).

6- A renda dos anos subsequentes fica sujeita às atualizações legais anuais, nos termos do artigo 1077°, n°2, do Código Civil, mediante comunicação escrita do Senhorio aos Arrendatários, com a antecedência mínima de 30 (trinta) dias, onde conste o valor da nova renda de acordo com o coeficiente de atualização publicado anualmente.

### CLÁUSULA TERCEIRA (Pagamentos e Caução)

1- Os pagamentos seguintes serão feitos por transferência ou depósito bancário no primeiro dia útil ao Senhorio, através de depósito ou transferência para a conta bancária com o IBAN PT50 0036 0026 9910 0089 3877 1 CAIXA ECONÓMICA MONTEPIO GERAL, sendo que a 01 de março de 2023 pagará o mês de junho de 2023, e assim sucessivamente, após o que serão enviados os respetivos recibos.

2- Na falta, total e/ou parcial, do pagamento pontual da renda prevista na cláusula segunda, o Senhorio poderá exigir aos Arrendatários, além das rendas em atraso, uma indemnização igual a 20 % das rendas em dívida.

3- No ato da assinatura do presente contrato, os Arrendatários entregam ao Senhorio a quantia de €: 4.950,00 (Quatro mil novecentos e cinquenta euros), correspondentes a 15 dias do mês de janeiro de 2023 e aos meses de fevereiro, março, abril e maio de 2023, servindo o presente contrato de suficiente documento de quitação.

4- Os Arrendatários, já entregaram ao Senhorio a quantia de €: 1.100,00 (Mil e cem euros), a título de caução, para garantia do bom cumprimento do contrato, a qual se destina a provisionar a boa e pontual regularização das últimas despesas e eventuais prejuízos imputáveis aos Arrendatários, durante a vigência do presente contrato, importância que será devolvida por inteiro ou o seu remanescente, no prazo máximo de 60 (Sessenta) dias, após o termo do arrendamento.

### CLÁUSULA QUARTA (Uso e Obras)

1- O apartamento arrendado destina-se exclusivamente à habitação permanente dos Arrendatários, e constitui casa de morada de família, não sendo permitido o comodato, sublocação, hospedagem, alojamento local ou qualquer outra forma de cedência de uso, nem o exercício de qualquer atividade profissional ou indústria doméstica.

2- Os Arrendatários não podem sublocar ou ceder, no todo ou em parte, onerosa ou gratuitamente, o local arrendado, sem consentimento expresso e autorização escrita do Senhorio.

3- Os Arrendatários devem fazer um uso prudente do arrendado, sendo a seu cargo todas as obras de beneficiação e as de manutenção do bom estado de funcionamento das instalações de água, eletricidade, esgotos ou saneamento, pavimentos, equipamentos, sanitários, pinturas, vidros, estores do imóvel, que sirvam o arrendado, com exclusão das deteriorações resultantes de uma normal e prudente utilização.

4- Os Arrendatários só podem efetuar obras ou benfeitorias na habitação arrendada com autorização prévia e escrita do Senhorio, com exceção de reparações urgentes.

5- Todas e quaisquer obras e benfeitorias efetuadas pelos Arrendatários na habitação arrendada referente na Cláusula Primeira, mesmo que tenham sido autorizadas pelo Senhorio ficarão a fazer parte integrante da mesma, sem que os Arrendatários tenham qualquer direito indemnizatório ou de retenção.

6- As avarias, deteriorações, ou quebras verificadas no apartamento que sejam imputáveis aos Arrendatários, serão consertadas ou substituídas por estes, ficando desde já estabelecido que os Arrendatários não podem fazer furos, quer nos azulejos da cozinha, quer nos azulejos da casa de banho, bem como no teto e caixilhos das janelas.

### CLÁUSULA QUINTA (Encargos)

1- É da responsabilidade dos Arrendatários, liquidar as faturas/recibos e todos os encargos ao consumo de água, eletricidade, gás, telefone, televisão por cabo ou satélite e Internet, taxas ou licenças com tais serviços diretamente ligados, manutenção e limpeza da habitação arrendada, correspondentes ao período de vigência do presente contrato.

2- Os Arrendatários celebram, em seu próprio nome, os contratos de fornecimento referidos no número anterior, com os respetivos fornecedores, correndo por sua conta e risco todas as despesas com os respetivos contratos.

### CLÁUSULA SEXTA (Visitas e Indemnização por Não Restituição)

1- Os Arrendatários, reconhecem ao Senhorio, o direito de, por si ou por pessoa de sua confiança, com aviso prévio, mostrar o local arrendado, sem que os mesmos se possam opor, nos dois meses anteriores ao término do contrato.

2- Após o término do contrato, se o imóvel arrendado não for restituído, seja qual for o motivo, os Arrendatários ficam obrigados a pagar ao Senhorio, a título de indemnização, até ao momento da desocupação efetiva, a renda que for devida em cada mês em que se mantiver a ocupação, sendo essa indemnização elevada ao dobro do valor da renda, sempre que os Arrendatários se constituam em mora.

### CLÁUSULA SÉTIMA (Animais e Espaços Comuns)

1- Os Arrendatários, obrigam-se a indemnizar o Senhorio por quaisquer danos causados por algum animal doméstico que estes tenham no imóvel, incluindo uma possível desinfestação, quer durante a vigência do presente contrato, quer após a sua saída definitiva do imóvel.

2- Os Arrendatários, obrigam-se a manter os espaços comuns livres e desocupados de quaisquer objetos.

3- As despesas inerentes e necessárias à utilização das partes comuns do prédio, são por conta do Senhorio.

### CLÁUSULA OITAVA (Vistoria e Inventário)

1- O Senhorio ou seu representante, procedeu à vistoria do imóvel na presença dos Arrendatários, onde foi feita uma lista de todo o inventário da habitação, bem como foto reportagem do estado do imóvel (chão, paredes, janelas, portas, equipamentos e armários, sanitários e acessórios de casa de banho), assim como o seu estado de conservação, que se anexa ao presente contrato e fica a fazer parte integrante do mesmo.

### CLÁUSULA NONA (Proteção de Dados)

Para efeito de execução do presente contrato, o Senhorio atuará na qualidade de "Responsável pelo Tratamento" dos dados pessoais dos cocontratantes, Arrendatários - "Titular dos Dados", conforme definido no Regulamento (UE) 2016/679 do Parlamento Europeu e do Conselho de 27 de abril de 2016 e na Lei n.° 58/2019 de 8 de agosto.

O Senhorio obriga-se a cumprir o disposto na legislação aplicável em matéria de tratamento de dados pessoais, designadamente:

a) Tratar apenas os dados pessoais que se configurem adequados, pertinentes e limitados às finalidades determinadas, explícitas e legítimas inerentes à execução deste contrato de arrendamento, comprometendo-se a não os tratar posteriormente de forma distinta e incompatível com as finalidades definidas, salvo disposição legal ou consentimento expresso do titular dos dados;

b) Implementar todas as medidas técnicas e organizacionais adequadas à proteção dos dados pessoais contra qualquer forma de tratamento ilícito, nomeadamente destruição (acidental ou ilícita), perda ou dano acidental, alteração, uso indevido, difusão ou acesso não autorizado, bem como quaisquer outras formas de tratamento não autorizado;

c) Garantir que o acesso aos dados pessoais dos Arrendatários serão estritamente limitados aos colaboradores e subcontratantes, que necessitem de ter acesso aos mesmos para efeitos da execução do contrato de arrendamento;

d) Apagar ou destruir todos os dados pessoais que tenham sido conservados pelo Senhorio no termo do contrato de arrendamento, salvo quando disposições legais imponham a sua conservação;

e) Transferir os dados pessoais para fora do Espaço Económico Europeu, de acordo com as disposições aplicáveis em matéria de transferências internacionais de dados;

f) Implementar as medidas técnicas e organizativas adequadas ao fácil e célere exercício dos direitos previstos para os Arrendatários, nomeadamente os direitos à informação, acesso, retificação, oposição, limitação, portabilidade e esquecimento;

g) Prestar os esclarecimentos necessários sobre as disposições da presente cláusula, relativos ao tratamento de dados pessoais que efetue, designadamente quando apresentem um risco para os direitos e liberdades fundamentais dos titulares dos dados;

h) Adotar as medidas técnicas e organizativas adequadas e necessárias à proteção de dados, desde a conceção e por defeito, assegurando a conformidade com a legislação em vigor sobre esta matéria e minorando os riscos decorrentes deste tratamento;

i) Disponibilizar um ponto de contacto interno para auxiliar, em tempo útil, cada colaborador acerca das questões relacionadas com a proteção de dados pessoais.

O Senhorio compromete-se a assegurar que as entidades subcontratantes a que recorre, cumprem com o disposto na legislação aplicável em matéria de tratamento de dados pessoais sempre que procedam ao tratamento de dados pessoais dos seus colaboradores.

O Titular dos Dados obriga-se a comunicar ao Senhorio, qualquer situação que possa afetar o tratamento dos dados pessoais ou que, de algum modo, possa dar origem ao incumprimento das disposições legais em matéria de proteção de dados.

### CLÁUSULA DÉCIMA (Disposições Finais)

1- O presente Contrato é regulado pela Lei Portuguesa.

2- Todo e qualquer litígio, divergência, pedido ou reclamação que resulte da execução ou violação do presente contrato, ou com ele esteja relacionado, bem como as dúvidas que se suscitem relativamente à validade e eficácia de qualquer das suas cláusulas, serão resolvidos por recurso ao tribunal judicial da comarca de Cascais, com expressa renúncia a qualquer outro.

3- Os contratantes convencionam que se consideram domiciliados para efeitos de citação em caso de litígio nos locais indicados no cabeçalho do presente Contrato, para onde deverão ser também remetidas todas as comunicações postais relativas ao presente arrendamento, designadamente à sua cessação e atualização da renda.

4- Os contraentes obrigam-se a cumprir reciprocamente as obrigações assumidas no Contrato que é feito em quadruplicado, de igual valor, destinando-se um a cada um dos outorgantes e o último à Autoridade Tributária e que depois de lido e ratificado, por corresponder à real expressão das suas vontades, é abaixo-assinado.

---

## DOCUMENTOS REFERENCIADOS E ANEXOS

| Documento | Descrição |
|-----------|-----------|
| **Lista de inventário** | Lista de todo o inventário da habitação (anexo ao contrato) |
| **Foto reportagem** | Estado do imóvel (chão, paredes, janelas, portas, equipamentos e armários, sanitários e acessórios de casa de banho) e estado de conservação (anexo ao contrato) |
| **Certificado Energético** | Certificado de Desempenho Energético e da Qualidade do Ar Interior N° SCE235939031 |

---

## FORO COMPETENTE

| Campo | Informação |
|-------|------------|
| **Tribunal competente** | Tribunal judicial da comarca de Cascais |
| **Renúncia** | Expressa renúncia a qualquer outro tribunal |

---

## ASSINATURAS

**Local e Data:** Lisboa, 15 de janeiro de 2023

**Assinantes:**
1. O SENHORIO: HENRIQUE MIGUEL MOURA DE SENA
2. OS ARRENDATÁRIOS: 
   - GONÇALO FILIPE CÔRTE JOAQUIM MARQUES DOS SANTOS
   - FILIPA GOMES JOAQUIM MARQUES DOS SANTOS

**Número de exemplares:** Quadruplicado (um para cada outorgante e um para a Autoridade Tributária)

---

## OBRIGAÇÕES DOS ARRENDATÁRIOS (RESUMO)

1. Pagamento pontual da renda mensal de €1.100,00
2. Uso exclusivo para habitação permanente (casa de morada de família)
3. Proibição de sublocação, comodato, hospedagem, alojamento local
4. Proibição de atividade profissional ou indústria doméstica
5. Uso prudente do imóvel
6. Manutenção das instalações (água, eletricidade, esgotos, saneamento, pavimentos, equipamentos, sanitários, pinturas, vidros, estores)
7. Não fazer furos nos azulejos da cozinha e casa de banho, teto e caixilhos das janelas
8. Celebrar contratos de fornecimento em nome próprio
9. Liquidar faturas de água, eletricidade, gás, telefone, TV cabo/satélite, Internet
10. Permitir visitas ao imóvel nos dois meses anteriores ao término
11. Manter espaços comuns livres e desocupados
12. Indemnizar por danos causados por animais domésticos
13. Comunicar situações que afetem tratamento de dados pessoais

---

## OBRIGAÇÕES DO SENHORIO (RESUMO)

1. Ceder o gozo do imóvel para habitação
2. Enviar recibos de renda
3. Devolver caução no prazo de 60 dias após termo
4. Suportar despesas das partes comuns do prédio
5. Cumprir legislação de proteção de dados pessoais
6. Dar aviso prévio para mostrar o imóvel

---

## OUTROS ELEMENTOS

- **Regime de bens dos Arrendatários:** Comunhão de adquiridos
- **Finalidade do imóvel:** Habitação permanente / Casa de morada de família
- **Sistema de pagamento antecipado:** Pagamento em março de 2023 corresponde ao mês de junho de 2023 (3 meses de antecedência)
- **Direitos dos Arrendatários em matéria de dados:** Informação, acesso, retificação, oposição, limitação, portabilidade e esquecimento

---


## [EXTRATOR E2: Extrator Completo - google/gemini-3-flash-preview]

Com base no documento fornecido, segue a extração integral, exaustiva e **verbatim** de todos os elementos contidos no contrato de arrendamento:

## FACTOS RELEVANTES
1. Celebração de contrato de arrendamento para fins habitacionais com prazo certo.
2. O Senhorio é proprietário e legítimo possuidor da Fração Autónoma 2D (2º DTO, Nº 137) em Campo de Ourique.
3. O imóvel destina-se exclusivamente à habitação permanente dos Arrendatários e constitui casa de morada de família.
4. É proibido o comodato, sublocação, hospedagem, alojamento local ou qualquer outra forma de cedência de uso.
5. É proibido o exercício de qualquer atividade profissional ou indústria doméstica no imóvel.
6. Os Arrendatários não podem realizar obras ou benfeitorias sem autorização prévia e escrita (exceto reparações urgentes).
7. Obras autorizadas ficam a fazer parte do imóvel sem direito a indemnização ou retenção.
8. É proibido fazer furos em azulejos (cozinha/WC), tetos e caixilhos de janelas.
9. Os Arrendatários devem celebrar contratos de serviços (água, luz, gás, etc.) em seu próprio nome.
10. O Senhorio tem o direito de mostrar o imóvel nos dois meses anteriores ao término do contrato.
11. Foi realizada vistoria, inventário e foto reportagem do estado do imóvel.
12. O contrato foi feito em quadruplicado.

## CRONOLOGIA
*   **03/08/2031**: Data de validade do Cartão de Cidadão do Senhorio.
*   **13/08/2029**: Data de validade do Cartão de Cidadão de ambos os Arrendatários.
*   **15/01/2023**: Data de início do contrato e data da assinatura em Lisboa.
*   **31/12/2025**: Data de termo do prazo inicial do contrato.
*   **01/03/2023**: Data em que será pago o mês de junho de 2023 (e sucessivamente).
*   **Prazos de Comunicação**:
    *   **120 dias**: Antecedência mínima para o Senhorio impedir a renovação.
    *   **90 dias**: Antecedência mínima para os Arrendatários impedirem a renovação.
    *   **90 dias**: Antecedência para denúncia pelos Arrendatários (após decorrido 1/3 do prazo).
    *   **30 dias**: Antecedência mínima para comunicação de atualização de renda.
    *   **60 dias**: Prazo máximo para devolução da caução após o termo.
    *   **2 meses**: Período anterior ao término para visitas ao imóvel.

## PARTES E IDENTIFICAÇÃO
*   **Senhorio (Primeiro)**:
    *   Nome: Henrique Miguel Moura de Sena.
    *   NIF: 269805672.
    *   Estado Civil: Solteiro, maior.
    *   CC: 13965402 0ZY9.
    *   Morada: Avenida 25 de Abril, Nº 93 1º DTO A, Cascais.
*   **Arrendatários (Segundos)**:
    *   Nome: Gonçalo Filipe Côrte Joaquim Marques dos Santos.
    *   NIF: 221544470.
    *   Estado Civil: Casado em regime da comunhão de adquiridos, maior.
    *   CC: 12958206 9 ZV0.
    *   Nome: Filipa Gomes Joaquim Marques dos Santos.
    *   NIF: 223841366.
    *   Estado Civil: Casada em regime da comunhão de adquiridos, maior.
    *   CC: 12826409 8 ZW4.

## VALORES MONETÁRIOS
*   **€: 1.100,00 (Mil e cem euros)**: Valor da renda mensal.
*   **€: 4.950,00 (Quatro mil novecentos e cinquenta euros)**: Valor entregue no ato da assinatura (referente a 15 dias de janeiro + meses de fevereiro, março, abril e maio de 2023).
*   **€: 1.100,00 (Mil e cem euros)**: Valor da caução entregue.
*   **20 %**: Indemnização sobre rendas em dívida em caso de falta de pagamento pontual.
*   **Dobro do valor da renda**: Indemnização em caso de mora na restituição do imóvel após término.

## REFERÊNCIAS LEGAIS
*   **Artigo 1095°, n° 1, do Código Civil**: Celebração de contrato com prazo certo.
*   **Artigo 1097.°, número 1, alínea b) do Código Civil**: Oposição à renovação pelo senhorio.
*   **Artigo 1098.°, número 3, alínea a) do Código Civil**: Denúncia do contrato pelos arrendatários.
*   **Artigo 1077°, n° 2, do Código Civil**: Atualização anual da renda.
*   **Regulamento (UE) 2016/679 (RGPD)**: Proteção de dados pessoais.
*   **Lei n.° 58/2019 de 8 de agosto**: Proteção de dados pessoais.
*   **Lei Portuguesa**: Regulação do contrato.
*   **Comarca de Cascais**: Foro convencionado para litígios.

## PEDIDOS E PRETENSÕES
*   **Senhorio**: Pretende o pagamento pontual da renda, a conservação do imóvel e a desocupação findo o prazo.
*   **Arrendatários**: Pretendem o uso habitacional do imóvel e a devolução da caução no final, caso não haja danos.
*   **Cláusula de Domiciliação**: As partes convencionam os endereços do cabeçalho para efeitos de citação e notificações postais.

## DOCUMENTOS REFERENCIADOS
*   **Certificado de Desempenho Energético e da Qualidade do Ar Interior**: Nº SCE235939031.
*   **Caderneta Predial/Matriz**: Artigo Nº 661 (Freguesia de Campo de Ourique).
*   **IBAN para pagamento**: PT50 0036 0026 9910 0089 3877 1 (Caixa Económica Montepio Geral).
*   **Anexo**: Lista de inventário e foto reportagem do estado do imóvel.

## DADOS TÉCNICOS E PARECERES
*   **Identificação do Imóvel**: Fração Autónoma 2D, correspondente ao 2º DTO, Nº 137, Rua Tomas da Anunciação, Campo de Ourique, Lisboa (CP: 1350-325).
*   **Conservatória**: Descrito na Conservatória do Registo Predial de Lisboa.
*   **Prazo**: 3 anos, renovável por iguais períodos.

## OUTROS ELEMENTOS
*   **Responsabilidade por Danos**: Arrendatários respondem por danos causados por animais domésticos (incluindo desinfestação).
*   **Manutenção**: A cargo dos arrendatários (água, luz, esgotos, pavimentos, sanitários, pinturas, vidros, estores), exceto deterioração normal.
*   **Tratamento de Dados**: O Senhorio é o "Responsável pelo Tratamento" e os Arrendatários são os "Titulares dos Dados".
*   **Assinaturas**: O documento contém as assinaturas de Henrique Miguel Moura de Sena, Gonçalo Filipe Côrte Joaquim Marques dos Santos e Filipa Gomes Joaquim Marques dos Santos.

---


## [EXTRATOR E3: Extrator Completo - openai/gpt-4o]

## FACTOS RELEVANTES
1. Henrique Miguel Moura de Sena é o senhorio e proprietário da Fração Autónoma 2D, correspondente ao 2º DTO, Nº 137 do prédio urbano na Rua Tomas da Anunciação, Lisboa.
2. Gonçalo Filipe Côrte Joaquim Marques dos Santos e Filipa Gomes Joaquim Marques dos Santos são os arrendatários.
3. O contrato de arrendamento é para fins habitacionais com prazo certo de 3 anos, iniciando em 15 de janeiro de 2023 e terminando em 31 de dezembro de 2025.
4. A renda mensal é de €1.100,00.
5. Os arrendatários pagaram uma caução de €1.100,00.
6. Os arrendatários entregaram €4.950,00 no ato da assinatura do contrato.
7. O apartamento destina-se exclusivamente à habitação permanente dos arrendatários.
8. Os arrendatários são responsáveis por todas as despesas de consumo e manutenção do imóvel.
9. O senhorio tem o direito de mostrar o imóvel nos dois meses anteriores ao término do contrato.
10. O contrato é regulado pela Lei Portuguesa e qualquer litígio será resolvido no tribunal judicial da comarca de Cascais.

## CRONOLOGIA
1. Início do contrato: 15 de janeiro de 2023.
2. Término do contrato: 31 de dezembro de 2025.
3. Validade do cartão de cidadão de Henrique Miguel Moura de Sena: até 03/08/2031.
4. Validade do cartão de cidadão de Gonçalo Filipe Côrte Joaquim Marques dos Santos e Filipa Gomes Joaquim Marques dos Santos: até 13/08/2029.

## PARTES E IDENTIFICAÇÃO
- **Senhorio:** Henrique Miguel Moura de Sena
  - NIF: 269805672
  - Morada: Avenida 25 de Abril, Nº 93 1º DTO A, Cascais
  - Cartão de cidadão: 13965402 0ZY9
- **Arrendatários:** 
  - Gonçalo Filipe Côrte Joaquim Marques dos Santos
    - NIF: 221544470
    - Cartão de cidadão: 12958206 9 ZV0
  - Filipa Gomes Joaquim Marques dos Santos
    - NIF: 223841366
    - Cartão de cidadão: 12826409 8 ZW4

## VALORES MONETÁRIOS
1. Renda mensal: €1.100,00
2. Caução: €1.100,00
3. Pagamento inicial: €4.950,00
4. Indemnização por falta de pagamento: 20% das rendas em dívida

## REFERÊNCIAS LEGAIS
1. Artigo 1095°, n° 1, do Código Civil
2. Alínea b) do número 1 do artigo 1097.° do Código Civil
3. Alínea a) do número 3 do artigo 1098.° do Código Civil
4. Artigo 1077°, n°2, do Código Civil
5. Regulamento (UE) 2016/679 do Parlamento Europeu e do Conselho de 27 de abril de 2016
6. Lei n.° 58/2019 de 8 de agosto

## PEDIDOS E PRETENSÕES
1. Os arrendatários devem pagar a renda mensalmente e manter o imóvel em bom estado.
2. O senhorio pode impedir a renovação automática do contrato com aviso prévio de 120 dias.
3. Os arrendatários podem impedir a renovação automática com aviso prévio de 90 dias.

## DOCUMENTOS REFERENCIADOS
1. Certificado de Desempenho Energético e da Qualidade do Ar Interior com o N° SCE235939031.
2. Lista de inventário e foto reportagem do estado do imóvel anexada ao contrato.

## DADOS TÉCNICOS E PARECERES
1. O imóvel é descrito na Conservatória do Registo Predial de Lisboa, inscrito na Matriz sob o Artigo N° 661.

## OUTROS ELEMENTOS
1. O contrato é feito em quadruplicado, destinando-se um a cada parte e um à Autoridade Tributária.
2. O senhorio é responsável pelas despesas das partes comuns do prédio.

---


## [EXTRATOR E4: Extrator Completo - anthropic/claude-3-5-sonnet]

## FACTOS RELEVANTES

1. Trata-se de um contrato de arrendamento para fins habitacionais com prazo certo
2. O imóvel arrendado é a Fração Autónoma 2D, correspondente ao 2º DTO, Nº 137 do prédio na Rua Tomas da Anunciação, Lisboa
3. O contrato tem prazo inicial de 3 anos, com início em 15/01/2023 e término em 31/12/2025
4. Renova-se automaticamente por períodos iguais de 3 anos
5. A renda mensal estabelecida é de €1.100,00
6. Foi entregue caução de €1.100,00
7. No ato da assinatura foi pago €4.950,00 referente a 15 dias de janeiro/2023 e aos meses de fevereiro a maio/2023
8. O imóvel destina-se exclusivamente à habitação permanente dos arrendatários
9. Constitui casa de morada de família
10. É proibido sublocação, hospedagem, alojamento local ou cedência de uso

## CRONOLOGIA

- 15/01/2023: Início do contrato
- 01/03/2023: Data para pagamento do mês de junho/2023
- 31/12/2025: Término do contrato inicial

## PARTES E IDENTIFICAÇÃO

SENHORIO:
- Nome: Henrique Miguel Moura de Sena
- NIF: 269805672
- CC: 13965402 0ZY9 (válido até 03/08/2031)
- Morada: Avenida 25 de Abril, Nº 93 1º DTO A, Cascais

ARRENDATÁRIOS:
1. Nome: Gonçalo Filipe Côrte Joaquim Marques dos Santos
- NIF: 221544470
- CC: 12958206 9 ZV0 (válido até 13/08/2029)
- Estado civil: Casado em regime da comunhão de adquiridos

2. Nome: Filipa Gomes Joaquim Marques dos Santos
- NIF: 223841366
- CC: 12826409 8 ZW4 (válido até 13/08/2029)
- Estado civil: Casada em regime da comunhão de adquiridos

## VALORES MONETÁRIOS

1. Renda mensal: €1.100,00
2. Caução: €1.100,00
3. Pagamento inicial: €4.950,00
4. Indemnização por atraso: 20% das rendas em dívida

## REFERÊNCIAS LEGAIS

1. Artigo 1095º, nº 1, do Código Civil
2. Artigo 1097º, nº 1, alínea b) do Código Civil
3. Artigo 1098º, nº 3, alínea a) do Código Civil
4. Artigo 1077º, nº 2, do Código Civil
5. Regulamento (UE) 2016/679
6. Lei nº 58/2019 de 8 de agosto

## DADOS TÉCNICOS

- Fração: 2D, 2º DTO, Nº 137
- Matriz Predial: Artigo Nº 661
- Certificado Energético: SCE235939031
- IBAN: PT50 0036 0026 9910 0089 3877 1 (Montepio)

## OUTROS ELEMENTOS

1. Jurisdição: Tribunal judicial da comarca de Cascais
2. Proteção de dados: Cláusula Nona detalha obrigações RGPD
3. Inventário e foto reportagem do estado do imóvel anexos ao contrato

---


## [EXTRATOR E5: Extrator Completo - deepseek/deepseek-chat]

## FACTOS RELEVANTES
1. O Senhorio, Henrique Miguel Moura de Sena, é proprietário de uma fração autónoma em Lisboa.
2. O contrato de arrendamento é celebrado com os Arrendatários, Gonçalo Filipe Côrte Joaquim Marques dos Santos e Filipa Gomes Joaquim Marques dos Santos.
3. O contrato tem um prazo certo de 3 anos, com início em 15 de janeiro de 2023 e termo em 31 de dezembro de 2025.
4. O contrato renova-se automaticamente por períodos de 3 anos, salvo denúncia por qualquer das partes.
5. A renda mensal é de €1.100,00, sujeita a atualizações legais anuais.
6. Os Arrendatários pagaram uma caução de €1.100,00 e entregaram €4.950,00 correspondentes a 15 dias de janeiro e os meses de fevereiro, março, abril e maio de 2023.
7. O apartamento destina-se exclusivamente à habitação permanente dos Arrendatários.
8. Os Arrendatários são responsáveis pelas despesas de consumo e manutenção do imóvel.
9. O Senhorio tem o direito de mostrar o imóvel nos dois meses anteriores ao término do contrato.
10. O contrato é regulado pela Lei Portuguesa e qualquer litígio será resolvido no tribunal judicial da comarca de Cascais.

## CRONOLOGIA
1. Início do contrato: 15 de janeiro de 2023
2. Término do contrato: 31 de dezembro de 2025
3. Data de assinatura do contrato: 15 de janeiro de 2023
4. Validade do cartão de cidadão do Senhorio: até 03/08/2031
5. Validade do cartão de cidadão dos Arrendatários: até 13/08/2029

## PARTES E IDENTIFICAÇÃO
1. Senhorio: Henrique Miguel Moura de Sena, NIF 269805672, Cartão de Cidadão nº 13965402 0ZY9, residente na Avenida 25 de Abril, N° 93 1o DTO A em Cascais.
2. Arrendatários: Gonçalo Filipe Côrte Joaquim Marques dos Santos, NIF 221544470, Cartão de Cidadão nº 12958206 9 ZV0; Filipa Gomes Joaquim Marques dos Santos, NIF 223841366, Cartão de Cidadão nº 12826409 8 ZW4.

## VALORES MONETÁRIOS
1. Renda mensal: €1.100,00
2. Caução: €1.100,00
3. Pagamento inicial: €4.950,00

## REFERÊNCIAS LEGAIS
1. Artigo 1095°, n° 1, do Código Civil
2. Artigo 1097.°, alínea b), do Código Civil
3. Artigo 1098.°, alínea a), do Código Civil
4. Artigo 1077°, n°2, do Código Civil
5. Regulamento (UE) 2016/679 do Parlamento Europeu e do Conselho de 27 de abril de 2016
6. Lei n.° 58/2019 de 8 de agosto

## PEDIDOS E PRETENSÕES
1. O Senhorio pode impedir a renovação automática do contrato com 120 dias de antecedência.
2. Os Arrendatários podem impedir a renovação automática do contrato com 90 dias de antecedência.
3. Os Arrendatários podem denunciar o contrato após um terço do prazo inicial, com 90 dias de antecedência.

## DOCUMENTOS REFERENCIADOS
1. Certificado de Desempenho Energético e da Qualidade do Ar Interior com o N° SCE235939031
2. Lista de inventário e foto reportagem do estado do imóvel (anexo ao contrato)

## DADOS TÉCNICOS E PARECERES
1. Fração Autónoma 2D, 2o DTO, N° 137 do prédio urbano sito na Rua Tomas da Anunciação, freguesia de Campo de Ourique, concelho de Lisboa, código postal: 1350-325 LISBOA.
2. Inscrição na Matriz sob o Artigo N° 661, Conservatória do Registo Predial de Lisboa.

## OUTROS ELEMENTOS
1. O Senhorio é responsável pelo tratamento dos dados pessoais dos Arrendatários, conforme o Regulamento (UE) 2016/679 e a Lei n.° 58/2019.
2. Os Arrendatários devem manter os espaços comuns livres e desocupados de quaisquer objetos.
3. As despesas inerentes e necessárias à utilização das partes comuns do prédio são por conta do Senhorio.

---
