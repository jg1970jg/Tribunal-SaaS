# Extrator E5: Extrator Completo
## Modelo: deepseek/deepseek-chat
## Chunks processados: 1

## FACTOS RELEVANTES
1. O Senhorio, Henrique Miguel Moura de Sena, é proprietário de uma fração autónoma em Lisboa.
2. O contrato de arrendamento é celebrado com os Arrendatários, Gonçalo Filipe Côrte Joaquim Marques dos Santos e Filipa Gomes Joaquim Marques dos Santos.
3. O contrato tem um prazo certo de 3 anos, com início em 15 de janeiro de 2023 e termo em 31 de dezembro de 2025.
4. O contrato renova-se automaticamente por períodos de 3 anos, salvo denúncia por qualquer das partes.
5. A renda mensal é de €1.100,00, sujeita a atualizações legais anuais.
6. Os Arrendatários pagaram uma caução de €1.100,00 e entregaram €4.950,00 correspondentes a 15 dias de janeiro e os meses de fevereiro, março, abril e maio de 2023.
7. O apartamento destina-se exclusivamente à habitação permanente dos Arrendatários.
8. Os Arrendatários são responsáveis pelas despesas de consumo e manutenção do imóvel.
9. O Senhorio tem o direito de mostrar o imóvel nos dois meses anteriores ao término do contrato.
10. O contrato é regulado pela Lei Portuguesa e qualquer litígio será resolvido no tribunal judicial da comarca de Cascais.

## CRONOLOGIA
1. Início do contrato: 15 de janeiro de 2023
2. Término do contrato: 31 de dezembro de 2025
3. Data de assinatura do contrato: 15 de janeiro de 2023
4. Validade do cartão de cidadão do Senhorio: até 03/08/2031
5. Validade do cartão de cidadão dos Arrendatários: até 13/08/2029

## PARTES E IDENTIFICAÇÃO
1. Senhorio: Henrique Miguel Moura de Sena, NIF 269805672, Cartão de Cidadão nº 13965402 0ZY9, residente na Avenida 25 de Abril, N° 93 1o DTO A em Cascais.
2. Arrendatários: Gonçalo Filipe Côrte Joaquim Marques dos Santos, NIF 221544470, Cartão de Cidadão nº 12958206 9 ZV0; Filipa Gomes Joaquim Marques dos Santos, NIF 223841366, Cartão de Cidadão nº 12826409 8 ZW4.

## VALORES MONETÁRIOS
1. Renda mensal: €1.100,00
2. Caução: €1.100,00
3. Pagamento inicial: €4.950,00

## REFERÊNCIAS LEGAIS
1. Artigo 1095°, n° 1, do Código Civil
2. Artigo 1097.°, alínea b), do Código Civil
3. Artigo 1098.°, alínea a), do Código Civil
4. Artigo 1077°, n°2, do Código Civil
5. Regulamento (UE) 2016/679 do Parlamento Europeu e do Conselho de 27 de abril de 2016
6. Lei n.° 58/2019 de 8 de agosto

## PEDIDOS E PRETENSÕES
1. O Senhorio pode impedir a renovação automática do contrato com 120 dias de antecedência.
2. Os Arrendatários podem impedir a renovação automática do contrato com 90 dias de antecedência.
3. Os Arrendatários podem denunciar o contrato após um terço do prazo inicial, com 90 dias de antecedência.

## DOCUMENTOS REFERENCIADOS
1. Certificado de Desempenho Energético e da Qualidade do Ar Interior com o N° SCE235939031
2. Lista de inventário e foto reportagem do estado do imóvel (anexo ao contrato)

## DADOS TÉCNICOS E PARECERES
1. Fração Autónoma 2D, 2o DTO, N° 137 do prédio urbano sito na Rua Tomas da Anunciação, freguesia de Campo de Ourique, concelho de Lisboa, código postal: 1350-325 LISBOA.
2. Inscrição na Matriz sob o Artigo N° 661, Conservatória do Registo Predial de Lisboa.

## OUTROS ELEMENTOS
1. O Senhorio é responsável pelo tratamento dos dados pessoais dos Arrendatários, conforme o Regulamento (UE) 2016/679 e a Lei n.° 58/2019.
2. Os Arrendatários devem manter os espaços comuns livres e desocupados de quaisquer objetos.
3. As despesas inerentes e necessárias à utilização das partes comuns do prédio são por conta do Senhorio.