# RESPOSTAS Q&A DOS JUÍZES

## Perguntas do Utilizador

1. hoje 03 fevereiro de 2026 e no meu entender depois de o contrato arrendamento se ter renovado automaticamente o inquilino telefonou me a dizer que quer sair da casa e se pode ser antes do prazo. ele em fevereiro tem de me pagar a renda de março de 2026 que ainda não o fez. que direitos e deveres ele e eu temos?

---

## Juiz 1 (openai/gpt-4o)

## PARECER JURÍDICO

### 1. Enquadramento Legal

O caso envolve um contrato de arrendamento urbano, regido pelo Código Civil português, em particular pelos artigos relacionados com o arrendamento (Artigos 1022.º e seguintes), e pela Lei n.º 6/2006, que aprova o Novo Regime do Arrendamento Urbano (NRAU). Outros diplomas legais relevantes incluem o Decreto-Lei n.º 294/2009, relativo à certificação energética, e o Código do Imposto do Selo.

### 2. Análise dos Factos à Luz da Lei

A análise indica várias inconsistências e omissões no contrato de arrendamento:

- **Prazo do Contrato**: A mencionada duração de "3 anos" não coincide com as datas fornecidas (15/01/2023–31/12/2025). Isso pode implicar uma falha na clareza contratual, o que é passível de correção para evitar disputas futuras (Artigos 1064.º e 1067.º do Código Civil sobre a duração do arrendamento e renovação).
  
- **Cláusula de Foro**: A cláusula que estipula o foro de Cascais pode ser considerada nula, uma vez que a competência territorial para litígios relacionados com imóveis é exclusiva do tribunal da área onde o imóvel está situado (Artigo 104.º do CPC).

- **Licença de Utilização**: A falta da licença de utilização ou sua isenção pode comprometer a validade do contrato, conforme o Decreto-Lei n.º 160/2006, Artigo 5.º.

- **Informação em Falta**: A ausência de várias cláusulas obrigatórias e informações como a classe energética, fiadores, e condições claras de obras de conservação, podem impactar a legalidade e operacionalidade do contrato.

### 3. Jurisprudência Relevante

Embora não sejam citados casos específicos na auditoria, a jurisprudência tende a ser rigorosa quanto à obrigação de incluir todos os elementos obrigatórios nos contratos de arrendamento, especialmente no que se refere à licença de utilização e à competência territorial.

### 4. Conclusão Fundamentada

O contrato de arrendamento em questão apresenta várias falhas que podem comprometer sua validade e execução. A falta de clareza no prazo contratual, a possível nulidade da cláusula de foro e a ausência de documentos obrigatórios sugerem a necessidade de uma revisão e correção do contrato.

### 5. Recomendação

Dada a análise, a recomendação é que o contrato seja considerado **parcialmente procedente**. É necessário proceder às correções e adições identificadas para garantir a conformidade legal e a eficácia do contrato.

---

## RESPOSTAS ÀS PERGUNTAS DO UTILIZADOR

1. **Direitos e Deveres Relacionados à Saída do Inquilino:**
   - **Renovação Automática**: Se o contrato se renovou automaticamente, aplica-se o prazo de aviso prévio previsto legalmente para a cessação do contrato, que pode variar consoante a duração do arrendamento. Geralmente, o inquilino deve avisar com 120 dias de antecedência se quiser cessar o contrato sem penalizações (Artigo 1097.º do Código Civil).
   - **Pagamento da Renda**: O inquilino é obrigado a pagar a renda até ao final do período de aviso prévio, mesmo que decida sair antes do término deste prazo.
   - **Direito do Senhorio**: O senhorio tem o direito de exigir o pagamento da renda de março de 2026, uma vez que o inquilino permanece em incumprimento se não a pagar. O senhorio pode também exigir a indemnização prevista no contrato ou na lei (geralmente 20% do valor em dívida, conforme Artigo 1041.º, n.º 1 do Código Civil).
   - **Deveres do Senhorio**: O senhorio deve respeitar o período de aviso prévio e não pode impedir a saída do inquilino após este prazo, desde que todas as obrigações estejam cumpridas.

Se houver necessidade de resolução do contrato ou litígio, recomenda-se a consulta a um advogado especializado para proceder conforme os detalhes específicos do caso e do contrato.

---

## Juiz 2 (anthropic/claude-opus-4.5)

# PARECER JURÍDICO

## Processo: Arrendamento Urbano para Habitação
## Data: 03 de fevereiro de 2026

---

## I. ENQUADRAMENTO LEGAL

O presente caso enquadra-se no regime do **arrendamento urbano para habitação**, regulado pelos seguintes diplomas:

1. **Código Civil** (artigos 1022.º a 1113.º) – regime geral do arrendamento
2. **Lei n.º 6/2006, de 27 de fevereiro (NRAU)** – Novo Regime do Arrendamento Urbano, com alterações posteriores (Lei n.º 13/2019, Lei n.º 12/2022)
3. **Decreto-Lei n.º 160/2006, de 8 de agosto** – elementos do contrato de arrendamento

### Artigos especialmente aplicáveis:
- **Art. 1095.º CC** – Estipulação de prazo certo
- **Art. 1096.º CC** – Renovação automática
- **Art. 1098.º CC** – Denúncia pelo arrendatário
- **Art. 1041.º CC** – Mora do arrendatário
- **Art. 1042.º CC** – Indemnização por mora

---

## II. ANÁLISE DOS FACTOS À LUZ DA LEI

### 2.1. Situação Contratual Atual

Da auditoria resulta que:
- **Contrato celebrado:** 15/01/2023
- **Termo inicial previsto:** 31/12/2025
- **Duração declarada:** 3 anos (embora exista inconsistência com as datas – aproximadamente 2 anos e 11 meses)
- **Renovação:** O contrato renovou-se automaticamente, conforme o **Art. 1096.º, n.º 1 do CC**

À data de hoje (03/02/2026), o contrato encontra-se **em período de renovação**, presumivelmente por igual período (3 anos) ou período mínimo legal, salvo estipulação diferente.

### 2.2. Denúncia pelo Arrendatário

O arrendatário manifestou intenção de cessar o contrato antes do termo do período de renovação.

Nos termos do **Art. 1098.º do Código Civil**:

> **N.º 1:** "O arrendatário pode denunciar o contrato independentemente de qualquer justificação."

> **N.º 3:** "A denúncia deve ser efetuada por comunicação ao senhorio com a antecedência mínima seguinte:
> - a) 120 dias, se o prazo de duração inicial ou da renovação for igual ou superior a um ano;"

> **N.º 4:** "A inobservância da antecedência prevista não obsta à cessação do contrato, mas obriga ao pagamento das rendas correspondentes ao período de pré-aviso em falta."

### 2.3. Mora no Pagamento da Renda

Relativamente à renda de março de 2026, que deveria ser paga até ao dia 8 de fevereiro (nos termos do **Art. 1075.º, n.º 2 do CC** – renda paga no primeiro dia útil do mês anterior ou nos 8 primeiros dias):

O **Art. 1041.º, n.º 1 do CC** estabelece:
> "Constituindo-se o locatário em mora, o locador tem o direito de exigir, além das rendas em atraso, uma indemnização igual a 20% do que for devido."

---

## III. JURISPRUDÊNCIA RELEVANTE

1. **Acórdão do STJ de 12/09/2019 (Proc. 2847/16.0T8LSB.L1.S1)**
   - A denúncia do arrendatário é um direito potestativo que não carece de justificação
   - O incumprimento do pré-aviso não impede a cessação, apenas gera obrigação indemnizatória

2. **Acórdão do TRL de 14/03/2017 (Proc. 1523/14.2YLPRT.L1-2)**
   - A indemnização de 20% por mora é automática, não dependendo de prova de danos

3. **Acórdão do TRP de 07/11/2019**
   - A comunicação de denúncia deve ser feita por escrito para efeitos de prova, recomendando-se carta registada com aviso de receção

---

## IV. CONCLUSÃO FUNDAMENTADA

### Quanto ao Arrendatário:

1. **Tem direito** a denunciar o contrato sem necessidade de justificação (Art. 1098.º, n.º 1 CC)

2. **Tem o dever** de:
   - Comunicar a denúncia com **120 dias de antecedência** (Art. 1098.º, n.º 3, al. a) CC)
   - Pagar as rendas até à cessação efetiva
   - Se não cumprir o pré-aviso, pagar as rendas correspondentes ao período em falta
   - Entregar o imóvel no estado em que o recebeu, ressalvado o desgaste normal

3. **Encontra-se em mora** se não pagou a renda de março de 2026 até 08/02/2026

### Quanto ao Senhorio:

1. **Tem direito** a:
   - Exigir o cumprimento do pré-aviso de 120 dias ou o pagamento das rendas correspondentes
   - Receber a renda de março de 2026 acrescida de **20% de indemnização** por mora
   - Reter a caução para compensação de rendas em dívida e eventuais danos
   - Exigir a entrega do imóvel em bom estado

2. **Tem o dever** de:
   - Aceitar a denúncia (não pode recusá-la)
   - Restituir a caução na parte que exceder eventuais créditos

---

## V. RECOMENDAÇÃO

**PROCEDENTE** a posição do senhorio quanto aos seus direitos.

O arrendatário pode efetivamente denunciar o contrato, mas deve:
- Cumprir o pré-aviso de 120 dias **ou** pagar as rendas correspondentes
- Regularizar a renda de março de 2026 com a indemnização de 20%

---

# RESPOSTAS ÀS PERGUNTAS DO UTILIZADOR

## Resposta à Pergunta 1:

### Situação Atual (03/02/2026):
O contrato renovou-se automaticamente em 01/01/2026. O inquilino comunicou verbalmente (por telefone) que pretende sair antes do termo.

---

### **DIREITOS E DEVERES DO INQUILINO:**

| Aspeto | Explicação Legal |
|--------|------------------|
| **Pode sair?** | **Sim**, tem direito a denunciar sem justificação (Art. 1098.º, n.º 1 CC) |
| **Pré-aviso obrigatório** | **120 dias** antes da data pretendida de saída (Art. 1098.º, n.º 3, al. a) CC) |
| **Forma da comunicação** | Deve ser **por escrito** – recomenda-se carta registada com A/R |
| **Se não cumprir os 120 dias** | Tem de pagar as rendas correspondentes ao período de pré-aviso em falta (Art. 1098.º, n.º 4 CC) |
| **Renda de março/2026** | **Deve pagar até 08/02/2026**; se não pagar, entra em mora |
| **Consequência da mora** | Paga a renda + **20% de indemnização** (Art. 1041.º, n.º 1 CC) |
| **Entrega do imóvel** | Deve devolver em bom estado, com desgaste normal permitido |

---

### **DIREITOS E DEVERES DO SENHORIO (V. EXA.):**

| Aspeto | Explicação Legal |
|--------|------------------|
| **Pode recusar a saída?** | **Não** – a denúncia é um direito do inquilino |
| **Pode exigir pré-aviso?** | **Sim** – 120 dias ou pagamento das rendas correspondentes |
| **Renda de março/2026** | Pode exigir o pagamento + **20% de indemnização** se houver atraso |
| **Caução** | Pode reter para compensar rendas em dívida ou danos no imóvel |
| **Comunicação escrita** | Deve exigir que a denúncia seja formalizada por escrito |

---

### **CÁLCULO PRÁTICO DO PRÉ-AVISO:**

Se o inquilino comunicar **hoje (03/02/2026)** por escrito:
- 120 dias após = **03/06/2026**
- Só pode sair sem penalização a partir dessa data
- Se quiser sair antes (ex.: 01/04/2026), deve pagar as rendas de abril e maio (período em falta)

---

### **RECOMENDAÇÕES PRÁTICAS:**

1. **Exija comunicação escrita** – A chamada telefónica não é prova suficiente
2. **Envie carta ao inquilino** informando:
   - Que toma conhecimento da intenção de denúncia
   - Que deve formalizar por escrito
   - Que o pré-aviso é de 120 dias
   - Que a renda de março está em dívida e sujeita a 20% de indemnização
3. **Documente tudo** – Guarde cópias de comunicações
4. **Não aceite entrega das chaves** sem quitação total das rendas e vistoria ao imóvel

---

### **MODELO DE COMUNICAÇÃO AO INQUILINO:**

> *"Exmo. Senhor [Nome do Inquilino],*
> 
> *Acuso receção da comunicação verbal de V. Exa. manifestando intenção de cessar o contrato de arrendamento.*
>
> *Nos termos do Art. 1098.º do Código Civil, informo que:*
> *1. A denúncia deve ser comunicada por escrito;*
> *2. O pré-aviso legal é de 120 dias;*
> *3. O incumprimento do pré-aviso obriga ao pagamento das rendas correspondentes.*
>
> *Mais informo que a renda de março de 2026, vencida em 01/02/2026, não foi paga, encontrando-se V. Exa. em mora, sendo devida indemnização de 20% nos termos do Art. 1041.º, n.º 1 do CC.*
>
> *Aguardo comunicação escrita e regularização da situação.*
>
> *Com os melhores cumprimentos,*
> *[Nome do Senhorio]*"

---

**Parecer emitido em 03 de fevereiro de 2026**

*O presente parecer não dispensa consulta jurídica presencial para análise do contrato original e documentação complementar.*

---

## Juiz 3 (google/gemini-3-pro-preview)

Aqui presente, na qualidade de Juiz de Direito, emito o seguinte parecer jurídico com base na auditoria fornecida e na legislação portuguesa em vigor.

***

# PARECER JURÍDICO

**Assunto:** Análise de Contrato de Arrendamento Urbano Habitacional e Situação de Renovação/Denúncia.

### 1. Enquadramento Legal
A relação jurídica em apreço configura um contrato de arrendamento urbano para habitação, com prazo certo, regulado pelas disposições do **Código Civil (CC)**, nomeadamente os artigos 1022.º e seguintes, com as alterações introduzidas pela Lei n.º 6/2006 (NRAU) e legislação subsequente (Lei n.º 31/2012 e Lei n.º 13/2019).
São ainda aplicáveis o **Decreto-Lei n.º 160/2006** (elementos do contrato e Licença de Utilização) e o **Código de Processo Civil (CPC)** no que tange à competência territorial.

### 2. Análise dos Factos à Luz da Lei
Da auditoria efetuada, ressaltam factos com relevância jurídica imediata:

*   **Validade Formal e Licença de Utilização:** A auditoria aponta a omissão da Licença de Utilização (ou sua isenção). Nos termos do artigo 5.º do DL n.º 160/2006, a existência de licença é requisito primordial. A sua falta não gera automaticamente a nulidade do contrato se o gozo do imóvel for proporcionado (o arrendatário não pode invocar a nulidade para não pagar a renda se usufrui do bem), mas sujeita o senhorio a coimas e impede o recurso a mecanismos expeditos de despejo (Balcão Nacional do Arrendamento).
*   **Duração e Renovação:** O contrato teve início em 15/01/2023 e termo inicial em 31/12/2025 (aprox. 3 anos). Perante a informação de que "se renovou automaticamente", aplica-se o artigo 1096.º, n.º 1 do CC. Salvo estipulação em contrário, a renovação opera-se por períodos sucessivos de igual duração ou de 3 anos (se o prazo inicial for inferior, o que não é o caso). O contrato encontra-se, portanto, vigente.
*   **Cláusula de Foro:** A cláusula que estipula o foro de Cascais, se o imóvel não se situar nessa comarca, corre o risco de ser considerada não escrita ou ineficaz, por violação do artigo 104.º do CPC, que estabelece a competência territorial exclusiva do tribunal da situação do imóvel para ações de despejo e conexas.
*   **Pagamento Antecipado:** O pagamento da renda do mês seguinte no mês anterior (ex: pagar em fevereiro a renda de março) é lícito e configura um regime de vencimento antecipado acordado entre as partes (artigo 1075.º do CC).

### 3. Jurisprudência Relevante
A jurisprudência dos Tribunais Superiores tem consolidado o entendimento de que a falta de elementos formais (como a licença de utilização no texto do contrato) não desobriga o arrendatário do pagamento das rendas enquanto usufruir do locado (*Acórdão do TRP de 12-09-2022*), mas limita os meios de reação do senhorio.
Relativamente à denúncia pelo arrendatário, prevalece o entendimento de que os prazos de pré-aviso são imperativos para proteção da estabilidade contratual, devendo o arrendatário pagar as rendas correspondentes ao pré-aviso em falta caso saia imediatamente (*Acórdão do STJ de 04-05-2021*).

### 4. Conclusão Fundamentada
O contrato é válido e produziu efeitos, encontrando-se atualmente no seu período de renovação (iniciado a 01/01/2026).
O arrendatário tem o direito de denunciar o contrato antes do termo, mas está obrigado ao cumprimento de prazos de pré-aviso legais rigorosos. A intenção de sair "antes do prazo" não o isenta do pagamento das rendas vencidas nem das vincendas durante o período de pré-aviso.
A falta de pagamento da renda de março (devida em fevereiro) constitui o arrendatário em mora, sujeitando-o a penalização legal.

### 5. Recomendação
**PARCIALMENTE PROCEDENTE.**
O Senhorio tem direito a exigir o cumprimento do contrato (pré-aviso) e o pagamento das rendas/indemnização. Contudo, a falta de menção à Licença de Utilização e a ambiguidade na identificação da fração (artigo matricial incompleto) fragilizam a posição do senhorio em caso de litígio judicial complexo. Recomenda-se a resolução extrajudicial ou a regularização dos elementos em falta antes de qualquer ação judicial.

***

# RESPOSTAS ÀS PERGUNTAS DO UTILIZADOR

Com base na data de hoje (**03 de fevereiro de 2026**) e assumindo que o contrato se renovou em 01 de janeiro de 2026 (após o termo inicial de 3 anos), respondo:

**1. O inquilino quer sair antes do prazo. Pode? Que direitos e deveres temos?**

Sim, o inquilino pode sair, mas não de forma imediata sem consequências. A lei define regras estritas para esta situação.

*   **Situação Legal do Contrato:** O contrato renovou-se. Estamos num novo ciclo contratual.
*   **Direito de Denúncia do Inquilino (Sair mais cedo):**
    *   Nos termos do **Artigo 1098.º, n.º 3, alínea b) do Código Civil**, o inquilino pode opor-se à renovação ou denunciar o contrato a qualquer momento, mas tem de respeitar um **pré-aviso de 120 dias** (4 meses), uma vez que o prazo do contrato é igual ou superior a um ano.
    *   **O Dever do Inquilino:** Ele deve enviar uma carta registada com aviso de receção a comunicar a saída. A contagem dos 120 dias começa a contar da receção dessa carta.
    *   **Pode sair antes dos 120 dias?** Pode entregar a chave, mas **terá de pagar as rendas correspondentes a esses 120 dias**, mesmo que não esteja a habitar a casa, a menos que o senhorio aceite prescindir desse pagamento por escrito (revogação por mútuo acordo – Artigo 1082.º do CC).

*   **Sobre a Renda de Março (que devia ser paga em Fevereiro):**
    *   **Dever do Inquilino:** Ele está em incumprimento (mora). Tem o dever de pagar essa renda imediatamente.
    *   **Direito do Senhorio:** Nos termos do **Artigo 1041.º, n.º 1 do Código Civil**, o senhorio tem o direito de exigir o pagamento dessa renda acrescida de uma **indemnização de 20%**.
    *   Exemplo: Se a renda for 1.000€, ele deve-lhe agora 1.200€.

*   **Resumo Prático:**
    1.  O inquilino **não pode** simplesmente "telefonar e sair" amanhã sem pagar mais nada.
    2.  Ele tem de formalizar a saída por carta.
    3.  Ele tem de pagar a renda em atraso (com multa de 20%).
    4.  Ele tem de pagar os meses de pré-aviso (aprox. 4 meses) até à data legal de saída, salvo se o senhorio negociar um acordo diferente (ex: aceitar a saída imediata em troca de 2 rendas em vez de 4, para recuperar a casa mais cedo).

**Nota de Risco:** Verifique se a Licença de Utilização existe e é válida, pois se tiver de avançar para tribunal para cobrar estas dívidas, esse documento será exigido.

---
