# Juiz 2: anthropic/claude-opus-4.5

# PARECER JURÍDICO

## Processo: Arrendamento Urbano para Habitação
## Data: 03 de fevereiro de 2026

---

## I. ENQUADRAMENTO LEGAL

O presente caso enquadra-se no regime do **arrendamento urbano para habitação**, regulado pelos seguintes diplomas:

1. **Código Civil** (artigos 1022.º a 1113.º) – regime geral do arrendamento
2. **Lei n.º 6/2006, de 27 de fevereiro (NRAU)** – Novo Regime do Arrendamento Urbano, com alterações posteriores (Lei n.º 13/2019, Lei n.º 12/2022)
3. **Decreto-Lei n.º 160/2006, de 8 de agosto** – elementos do contrato de arrendamento

### Artigos especialmente aplicáveis:
- **Art. 1095.º CC** – Estipulação de prazo certo
- **Art. 1096.º CC** – Renovação automática
- **Art. 1098.º CC** – Denúncia pelo arrendatário
- **Art. 1041.º CC** – Mora do arrendatário
- **Art. 1042.º CC** – Indemnização por mora

---

## II. ANÁLISE DOS FACTOS À LUZ DA LEI

### 2.1. Situação Contratual Atual

Da auditoria resulta que:
- **Contrato celebrado:** 15/01/2023
- **Termo inicial previsto:** 31/12/2025
- **Duração declarada:** 3 anos (embora exista inconsistência com as datas – aproximadamente 2 anos e 11 meses)
- **Renovação:** O contrato renovou-se automaticamente, conforme o **Art. 1096.º, n.º 1 do CC**

À data de hoje (03/02/2026), o contrato encontra-se **em período de renovação**, presumivelmente por igual período (3 anos) ou período mínimo legal, salvo estipulação diferente.

### 2.2. Denúncia pelo Arrendatário

O arrendatário manifestou intenção de cessar o contrato antes do termo do período de renovação.

Nos termos do **Art. 1098.º do Código Civil**:

> **N.º 1:** "O arrendatário pode denunciar o contrato independentemente de qualquer justificação."

> **N.º 3:** "A denúncia deve ser efetuada por comunicação ao senhorio com a antecedência mínima seguinte:
> - a) 120 dias, se o prazo de duração inicial ou da renovação for igual ou superior a um ano;"

> **N.º 4:** "A inobservância da antecedência prevista não obsta à cessação do contrato, mas obriga ao pagamento das rendas correspondentes ao período de pré-aviso em falta."

### 2.3. Mora no Pagamento da Renda

Relativamente à renda de março de 2026, que deveria ser paga até ao dia 8 de fevereiro (nos termos do **Art. 1075.º, n.º 2 do CC** – renda paga no primeiro dia útil do mês anterior ou nos 8 primeiros dias):

O **Art. 1041.º, n.º 1 do CC** estabelece:
> "Constituindo-se o locatário em mora, o locador tem o direito de exigir, além das rendas em atraso, uma indemnização igual a 20% do que for devido."

---

## III. JURISPRUDÊNCIA RELEVANTE

1. **Acórdão do STJ de 12/09/2019 (Proc. 2847/16.0T8LSB.L1.S1)**
   - A denúncia do arrendatário é um direito potestativo que não carece de justificação
   - O incumprimento do pré-aviso não impede a cessação, apenas gera obrigação indemnizatória

2. **Acórdão do TRL de 14/03/2017 (Proc. 1523/14.2YLPRT.L1-2)**
   - A indemnização de 20% por mora é automática, não dependendo de prova de danos

3. **Acórdão do TRP de 07/11/2019**
   - A comunicação de denúncia deve ser feita por escrito para efeitos de prova, recomendando-se carta registada com aviso de receção

---

## IV. CONCLUSÃO FUNDAMENTADA

### Quanto ao Arrendatário:

1. **Tem direito** a denunciar o contrato sem necessidade de justificação (Art. 1098.º, n.º 1 CC)

2. **Tem o dever** de:
   - Comunicar a denúncia com **120 dias de antecedência** (Art. 1098.º, n.º 3, al. a) CC)
   - Pagar as rendas até à cessação efetiva
   - Se não cumprir o pré-aviso, pagar as rendas correspondentes ao período em falta
   - Entregar o imóvel no estado em que o recebeu, ressalvado o desgaste normal

3. **Encontra-se em mora** se não pagou a renda de março de 2026 até 08/02/2026

### Quanto ao Senhorio:

1. **Tem direito** a:
   - Exigir o cumprimento do pré-aviso de 120 dias ou o pagamento das rendas correspondentes
   - Receber a renda de março de 2026 acrescida de **20% de indemnização** por mora
   - Reter a caução para compensação de rendas em dívida e eventuais danos
   - Exigir a entrega do imóvel em bom estado

2. **Tem o dever** de:
   - Aceitar a denúncia (não pode recusá-la)
   - Restituir a caução na parte que exceder eventuais créditos

---

## V. RECOMENDAÇÃO

**PROCEDENTE** a posição do senhorio quanto aos seus direitos.

O arrendatário pode efetivamente denunciar o contrato, mas deve:
- Cumprir o pré-aviso de 120 dias **ou** pagar as rendas correspondentes
- Regularizar a renda de março de 2026 com a indemnização de 20%

---

# RESPOSTAS ÀS PERGUNTAS DO UTILIZADOR

## Resposta à Pergunta 1:

### Situação Atual (03/02/2026):
O contrato renovou-se automaticamente em 01/01/2026. O inquilino comunicou verbalmente (por telefone) que pretende sair antes do termo.

---

### **DIREITOS E DEVERES DO INQUILINO:**

| Aspeto | Explicação Legal |
|--------|------------------|
| **Pode sair?** | **Sim**, tem direito a denunciar sem justificação (Art. 1098.º, n.º 1 CC) |
| **Pré-aviso obrigatório** | **120 dias** antes da data pretendida de saída (Art. 1098.º, n.º 3, al. a) CC) |
| **Forma da comunicação** | Deve ser **por escrito** – recomenda-se carta registada com A/R |
| **Se não cumprir os 120 dias** | Tem de pagar as rendas correspondentes ao período de pré-aviso em falta (Art. 1098.º, n.º 4 CC) |
| **Renda de março/2026** | **Deve pagar até 08/02/2026**; se não pagar, entra em mora |
| **Consequência da mora** | Paga a renda + **20% de indemnização** (Art. 1041.º, n.º 1 CC) |
| **Entrega do imóvel** | Deve devolver em bom estado, com desgaste normal permitido |

---

### **DIREITOS E DEVERES DO SENHORIO (V. EXA.):**

| Aspeto | Explicação Legal |
|--------|------------------|
| **Pode recusar a saída?** | **Não** – a denúncia é um direito do inquilino |
| **Pode exigir pré-aviso?** | **Sim** – 120 dias ou pagamento das rendas correspondentes |
| **Renda de março/2026** | Pode exigir o pagamento + **20% de indemnização** se houver atraso |
| **Caução** | Pode reter para compensar rendas em dívida ou danos no imóvel |
| **Comunicação escrita** | Deve exigir que a denúncia seja formalizada por escrito |

---

### **CÁLCULO PRÁTICO DO PRÉ-AVISO:**

Se o inquilino comunicar **hoje (03/02/2026)** por escrito:
- 120 dias após = **03/06/2026**
- Só pode sair sem penalização a partir dessa data
- Se quiser sair antes (ex.: 01/04/2026), deve pagar as rendas de abril e maio (período em falta)

---

### **RECOMENDAÇÕES PRÁTICAS:**

1. **Exija comunicação escrita** – A chamada telefónica não é prova suficiente
2. **Envie carta ao inquilino** informando:
   - Que toma conhecimento da intenção de denúncia
   - Que deve formalizar por escrito
   - Que o pré-aviso é de 120 dias
   - Que a renda de março está em dívida e sujeita a 20% de indemnização
3. **Documente tudo** – Guarde cópias de comunicações
4. **Não aceite entrega das chaves** sem quitação total das rendas e vistoria ao imóvel

---

### **MODELO DE COMUNICAÇÃO AO INQUILINO:**

> *"Exmo. Senhor [Nome do Inquilino],*
> 
> *Acuso receção da comunicação verbal de V. Exa. manifestando intenção de cessar o contrato de arrendamento.*
>
> *Nos termos do Art. 1098.º do Código Civil, informo que:*
> *1. A denúncia deve ser comunicada por escrito;*
> *2. O pré-aviso legal é de 120 dias;*
> *3. O incumprimento do pré-aviso obriga ao pagamento das rendas correspondentes.*
>
> *Mais informo que a renda de março de 2026, vencida em 01/02/2026, não foi paga, encontrando-se V. Exa. em mora, sendo devida indemnização de 20% nos termos do Art. 1041.º, n.º 1 do CC.*
>
> *Aguardo comunicação escrita e regularização da situação.*
>
> *Com os melhores cumprimentos,*
> *[Nome do Senhorio]*"

---

**Parecer emitido em 03 de fevereiro de 2026**

*O presente parecer não dispensa consulta jurídica presencial para análise do contrato original e documentação complementar.*