============================================================
RELATÓRIO DE VERIFICAÇÃO LEGAL
============================================================
Data: 03/02/2026 15:50
Total de citações verificadas: 18

✓ Aprovadas: 0
✗ Rejeitadas: 7
⚠ Atenção: 11

------------------------------------------------------------

⚠ Diploma não especificado, artigo 1096º
   Status: ATENCAO
   Fonte: dre_online
   Aplicabilidade ao caso: ⚠
   Mensagem: Diploma pode existir mas artigo não confirmado no DRE

⚠ Diploma não especificado, artigo 1098º
   Status: ATENCAO
   Fonte: dre_online
   Aplicabilidade ao caso: ⚠
   Mensagem: Diploma pode existir mas artigo não confirmado no DRE

⚠ Diploma não especificado, artigo 1041º
   Status: ATENCAO
   Fonte: dre_online
   Aplicabilidade ao caso: ⚠
   Mensagem: Diploma pode existir mas artigo não confirmado no DRE

⚠ Diploma não especificado, artigo 1097º
   Status: ATENCAO
   Fonte: dre_online
   Aplicabilidade ao caso: ⚠
   Mensagem: Diploma pode existir mas artigo não confirmado no DRE

⚠ Diploma não especificado, artigo 1022º
   Status: ATENCAO
   Fonte: dre_online
   Aplicabilidade ao caso: ⚠
   Mensagem: Diploma pode existir mas artigo não confirmado no DRE

⚠ Diploma não especificado, artigo 1064º
   Status: ATENCAO
   Fonte: dre_online
   Aplicabilidade ao caso: ⚠
   Mensagem: Diploma pode existir mas artigo não confirmado no DRE

⚠ Diploma não especificado, artigo 1067º
   Status: ATENCAO
   Fonte: dre_online
   Aplicabilidade ao caso: ⚠
   Mensagem: Diploma pode existir mas artigo não confirmado no DRE

⚠ Diploma não especificado, artigo 1095º
   Status: ATENCAO
   Fonte: dre_online
   Aplicabilidade ao caso: ⚠
   Mensagem: Diploma pode existir mas artigo não confirmado no DRE

✗ Diploma não especificado, artigo 1095º
   Status: REJEITADO
   Fonte: cache_local
   Aplicabilidade ao caso: ⚠
   Mensagem: Legislação não encontrada (cache)

✗ Diploma não especificado, artigo 1096º
   Status: REJEITADO
   Fonte: cache_local
   Aplicabilidade ao caso: ⚠
   Mensagem: Legislação não encontrada (cache)

✗ Diploma não especificado, artigo 1097º
   Status: REJEITADO
   Fonte: cache_local
   Aplicabilidade ao caso: ⚠
   Mensagem: Legislação não encontrada (cache)

✗ Diploma não especificado, artigo 1098º
   Status: REJEITADO
   Fonte: cache_local
   Aplicabilidade ao caso: ⚠
   Mensagem: Legislação não encontrada (cache)

✗ Diploma não especificado, artigo 1041º
   Status: REJEITADO
   Fonte: cache_local
   Aplicabilidade ao caso: ⚠
   Mensagem: Legislação não encontrada (cache)

⚠ Diploma não especificado, artigo 1042º
   Status: ATENCAO
   Fonte: dre_online
   Aplicabilidade ao caso: ⚠
   Mensagem: Diploma pode existir mas artigo não confirmado no DRE

⚠ Diploma não especificado, artigo 1075º
   Status: ATENCAO
   Fonte: dre_online
   Aplicabilidade ao caso: ⚠
   Mensagem: Diploma pode existir mas artigo não confirmado no DRE

⚠ Diploma não especificado, artigo 1082º
   Status: ATENCAO
   Fonte: dre_online
   Aplicabilidade ao caso: ⚠
   Mensagem: Diploma pode existir mas artigo não confirmado no DRE

✗ Diploma não especificado, artigo 104º
   Status: REJEITADO
   Fonte: cache_local
   Aplicabilidade ao caso: ⚠
   Mensagem: Legislação não encontrada (cache)

✗ Diploma não especificado, artigo 5º
   Status: REJEITADO
   Fonte: cache_local
   Aplicabilidade ao caso: ⚠
   Mensagem: Legislação não encontrada (cache)

------------------------------------------------------------
NOTA: Aplicabilidade ao caso é sempre ⚠ (requer análise humana)
============================================================