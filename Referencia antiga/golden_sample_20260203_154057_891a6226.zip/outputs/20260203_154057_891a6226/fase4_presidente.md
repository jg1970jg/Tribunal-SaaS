# PRESIDENTE: openai/gpt-5.2

## 1) Consensos e divergências entre os pareceres

### Consensos (pontos comuns)
1. **Renovação automática**: assumindo que não houve oposição válida, o contrato **renovou-se** e está em vigor em 03/02/2026 (base: **art. 1096.º CC**).
2. **Saída antes do termo (“denúncia” pelo inquilino)**: o inquilino **pode denunciar**, mas tem de respeitar **pré‑aviso**; se não respeitar, **paga as rendas correspondentes ao pré‑aviso em falta** (base: **art. 1098.º CC**).
3. **Renda de março/2026**: se está contratualmente estipulado (ou praticado) pagamento em fevereiro, a renda é **exigível**; o não pagamento constitui **mora**, permitindo exigir **20%** adicionais (base: **art. 1041.º, n.º 1 CC**).

### Divergências (e como ficam resolvidas)
1. **Artigo aplicável ao pré‑aviso**:  
   - Juiz 1 apontou **art. 1097.º CC**; Juízes 2 e 3 apontaram **art. 1098.º CC**.  
   - **Decisão**: para “denúncia a todo o tempo” pelo arrendatário durante a vigência/renovação, a norma central é **art. 1098.º CC** (o 1097.º está mais associado à **oposição à renovação** no termo).
2. **Licença de utilização e “validade” do contrato**:  
   - Juiz 1 sugere possível comprometimento da validade; Juiz 3 indica sobretudo **risco sancionatório/probatório e de meios processuais**, não um “não pagamento” de renda.  
   - **Decisão**: a falta/omissão de licença (ou menção) é **muito relevante** e deve ser regularizada; **não transforma, por si só, a situação num “direito do inquilino a não pagar”** se ele continua a usufruir do locado. Pode, porém, **fragilizar** meios de reação do senhorio e gerar **contraordenações**.

---

## 2) Verificação das citações legais (correção e aplicabilidade)

### Código Civil (CC)
- **Art. 1022.º e segs. CC (arrendamento/locação)**: ✓ aplicável (enquadramento geral).
- **Art. 1064.º CC** (forma do contrato de arrendamento/locação): ⚠ pode ser relevante, mas **não é o artigo-chave** para “duração/renovação” como foi usado pelo Juiz 1.
- **Art. 1067.º CC** (duração/renovação — referência do Juiz 1): ⚠ **numeração/aplicação duvidosa** no contexto dado; a matéria do arrendamento habitacional a prazo certo está tipicamente tratada nos **art. 1095.º e segs.**
- **Art. 1095.º CC (prazo certo)**: ✓ correto e aplicável.
- **Art. 1096.º CC (renovação automática)**: ✓ correto e aplicável.
- **Art. 1097.º CC (invocado pelo Juiz 1 para pré‑aviso do inquilino)**: ✗ **não é a melhor norma** para “denúncia durante a vigência/renovação”; aqui aplica-se **art. 1098.º CC**.
- **Art. 1098.º CC (denúncia pelo arrendatário e pré‑aviso)**: ✓ correto e aplicável.  
  - Referência do Juiz 3 a “**n.º 3, al. b)**”: ⚠ o essencial (120 dias) está correto, mas a **alínea** indicada pode não corresponder; deve confirmar-se a redação consolidada.
- **Art. 1041.º, n.º 1 CC (mora e indemnização de 20%)**: ✓ correto e aplicável.
- **Art. 1042.º CC (indemnização por mora, citado pelo Juiz 2)**: ⚠ **requer verificação** (a regra prática dos 20% está no **1041.º**; a invocação autónoma do 1042.º não é necessária aqui e pode estar imprecisa).
- **Art. 1075.º, n.º 2 CC (prazo/modo de pagamento da renda, citado pelo Juiz 2)**: ⚠ plausível, mas **depende da redação aplicável e do que ficou contratualmente acordado**; o decisivo é: **se o contrato prevê pagamento em fevereiro da renda de março, então está vencida**.
- **Art. 1082.º CC (mútuo acordo/revogação, citado pelo Juiz 3)**: ⚠ ideia jurídica correta (cessação por acordo), mas **numeração/regime exato** deve ser confirmada; o ponto válido é: podem cessar por **acordo escrito**.

### Código de Processo Civil (CPC)
- **Art. 104.º CPC (competência territorial exclusiva, foro do imóvel)**: ⚠ o **princípio** está correto (ações sobre imóveis tendem a ser no tribunal da situação do imóvel), mas o **artigo/norma exata** pode não ser o 104.º para todas as ações de arrendamento/despejo; requer confirmação. Em todo o caso, cláusulas de foro contrárias a competência imperativa tendem a ser **ineficazes**.

### NRAU e diplomas conexos
- **Lei n.º 6/2006 (NRAU)**: ✓ aplicável (enquadramento).
- **DL n.º 160/2006, art. 5.º (elementos/menção de licença de utilização ou isenção)**: ✓ aplicável e muito relevante.
- **DL n.º 294/2009 (certificação energética, citado pelo Juiz 1)**: ✗ **provável desatualização/não central** (o regime foi sendo alterado por legislação posterior; pode não ser a referência correta hoje).
- **Código do Imposto do Selo (referência genérica do Juiz 1)**: ⚠ relevante em obrigações fiscais do contrato, mas **não é determinante** para a questão “pré‑aviso/renda em mora”.

### Jurisprudência citada
- Acórdãos indicados (STJ/TRL/TRP com datas e n.ºs de processo): ⚠ **exigem confirmação** (não foram verificados aqui). Não são necessários para decidir o essencial, que decorre diretamente da lei.

---

## 3) VEREDICTO FINAL

**PARCIALMENTE PROCEDENTE (⚠)**

- **Procede**: o senhorio tem direito a exigir **(i)** formalização escrita da denúncia, **(ii)** cumprimento do **pré‑aviso de 120 dias** ou pagamento das rendas correspondentes ao período em falta, e **(iii)** pagamento da renda de março/2026 e, havendo mora, **indemnização legal de 20%** (art. 1098.º e 1041.º CC).
- **Procede com ressalvas**: existem **riscos formais** (licença de utilização/menções contratuais e eventual cláusula de foro) que **não eliminam** o dever de pagar rendas, mas podem **condicionar** a estratégia e alguns meios processuais; recomenda-se regularização documental.

---

## 4) CONSOLIDAÇÃO — RESPOSTAS Q&A (final, sem contradições)

### 1) O inquilino pode sair “antes do prazo” depois da renovação automática?
1. **Sim, pode denunciar o contrato**, mesmo durante a renovação, **sem ter de justificar**, mas **não pode fazê-lo de forma imediata “sem custos”**.  
2. Para sair sem ficar a dever rendas por falta de pré‑aviso, deve cumprir **pré‑aviso de 120 dias** (regra geral para contratos com duração igual/superior a 1 ano): **art. 1098.º CC**.  
3. **Se não respeitar os 120 dias**, a denúncia produz efeito, mas ele fica obrigado a **pagar as rendas correspondentes ao período de pré‑aviso em falta** (art. 1098.º CC).

### 2) A chamada telefónica chega? Como deve ser feita a denúncia?
1. A lei exige **comunicação ao senhorio**; para efeitos de **prova e segurança**, deve ser **por escrito** (ideal: **carta registada com aviso de receção** ou outro meio escrito comprovável).  
2. Até existir comunicação escrita (ou acordo escrito), fica tudo **mais discutível** em caso de conflito.

### 3) Ele tem de pagar em fevereiro a renda de março de 2026? E o que acontece se não pagar?
1. **Tem de pagar**, se o contrato (ou a prática contratual aceite por ambos) prevê que a renda do mês seguinte vence/paga no mês anterior — isto é comum e é válido por acordo.  
2. Se não pagar dentro do prazo devido, entra em **mora** e o senhorio pode exigir:  
   - **renda em falta**, e  
   - **indemnização de 20%** sobre o montante devido (**art. 1041.º, n.º 1 CC**).  
3. Na prática: se a renda for €X, pode ser exigido €X + 0,2X (salvo acordo diferente/dispensa pelo senhorio).

### 4) Quais são os direitos e deveres de cada um (resumo operativo)?
1. **Inquilino (arrendatário) — deveres principais**:  
   1) Formalizar a denúncia **por escrito**;  
   2) Respeitar **120 dias** de pré‑aviso ou pagar as rendas do período em falta;  
   3) Pagar rendas vencidas (incluindo março/2026, se vencida em fevereiro) e devolver o imóvel no estado devido (desgaste normal excluído).
2. **Senhorio — direitos principais**:  
   1) Exigir a denúncia **formal e comprovável**;  
   2) Exigir **rendas até ao termo do pré‑aviso** (ou as rendas do pré‑aviso em falta);  
   3) Exigir a renda em atraso e a **indemnização de 20%** por mora (art. 1041.º CC);  
   4) Acertar valores com a **caução**, se existir, para cobrir rendas/danos, restituindo o remanescente.
3. **Senhorio — deveres principais**:  
   1) **Não pode impedir** a cessação se a denúncia for válida (apenas pode exigir consequências legais do incumprimento do pré‑aviso);  
   2) Restituir a caução no que exceder os créditos apurados;  
   3) Manter a documentação do arrendamento regular (nota: **licença de utilização/isenção** deve estar disponível e corretamente indicada—DL 160/2006, art. 5.º).

### 5) Nota preventiva (importante para si, senhorio)
1. Confirme e regularize a **licença de utilização (ou isenção)** e os elementos obrigatórios do contrato (DL 160/2006, art. 5.º). Isto **não “apaga” a dívida**, mas pode ser relevante se tiver de avançar para cobrança/despejo.  
2. Se quiser, pode propor um **acordo escrito de saída antecipada** (por exemplo, aceitar uma saída antes dos 120 dias mediante pagamento de X rendas), para reduzir risco e acelerar a libertação do imóvel.

Se indicar: (i) qual a data em que ele quer sair, (ii) qual a data exata de vencimento prevista no contrato e (iii) se existe caução/fiador, consigo fechar um cálculo objetivo do que é devido (pré‑aviso em falta + renda de março + 20%).