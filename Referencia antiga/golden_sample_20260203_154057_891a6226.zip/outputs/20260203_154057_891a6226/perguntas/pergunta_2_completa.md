# PERGUNTA #2

**Data:** 2026-02-03 17:41:09  
**Run ID:** 20260203_154057_891a6226  
**Tempo:** 322.5s  
**Tokens:** 48,384  
**Custo:** $0.4838  

---

## 💭 PERGUNTA

hoje é 03 de fevereiro de 2026 e o inquilino demonstrou interesse em resolver o contrato o mais rapido possivel. ele esteve sempre conforme clausulas do contrato a pagar adiantado desde o inicio contrato onde em março de 2023 pagou o mês de junho de 2023 e assim sucessivamente. este mês de fevereiro de 2026 não transferiu nenhum valor de renda tendo sido o ultimo pagamento efetuado por ele em janeiro de 2026.. ate quando ele e obrigado a cumprir e ficar na casa?

---

## 🔍 FASE 2: AUDITORIA CONSOLIDADA

# AUDITORIA CONSOLIDADA

## Síntese da Auditoria Consolidada

Os três auditores convergem na identificação dos elementos essenciais do contrato de arrendamento e no enquadramento legal aplicável. O ponto central de consenso é que o contrato se encontra atualmente no período de renovação (iniciado em 01/01/2026), o que tem implicações diretas na possibilidade de denúncia pelo inquilino. O Auditor 2 destaca uma inconsistência temporal crítica: a denúncia regular só será possível após decorrido 1/3 do novo período de renovação (01/01/2027). Todos os auditores confirmam que não existe incumprimento no pagamento de rendas, dado o sistema de pagamento adiantado.

---

## Elementos Relevantes (agregado dos 3 auditores)

### Dados Contratuais Fundamentais

| Elemento | Informação | Fonte |
|----------|------------|-------|
| Tipo de contrato | Arrendamento habitacional com prazo certo | Auditores 1, 2, 3 |
| Data de início | 15/01/2023 | Auditores 1, 2, 3 |
| Termo do prazo inicial | 31/12/2025 | Auditores 1, 2, 3 |
| Prazo inicial | 3 anos | Auditores 1, 2, 3 |
| Renovação | Automática por iguais períodos de 3 anos | Auditores 1, 2, 3 |
| Estado atual | Contrato renovado desde 01/01/2026 (até 31/12/2028) | Auditores 2, 3 |
| Renda mensal | €1.100,00 | Auditor 2 |

### Mecanismos de Cessação Identificados

| Mecanismo | Prazo de Aviso | Base Legal |
|-----------|----------------|------------|
| Oposição à renovação pelo Senhorio | 120 dias antes do termo | Art. 1097.º, n.º 1, al. b) CC |
| Oposição à renovação pelos Arrendatários | 90 dias antes do termo | Não especificado |
| **Denúncia pelos Arrendatários** | **90 dias** | **Art. 1098.º, n.º 3, al. a) CC** |
| Condição para denúncia | Após decorrido 1/3 do prazo | Auditores 1, 2, 3 |

### Regime de Pagamentos

- **Sistema**: Pagamento adiantado (3 meses de adiantamento)
- **Pagamento inicial**: Cobriu até maio de 2023 (€4.950,00)
- **Mecânica**: Em março/2023 pagou-se junho/2023
- **Último pagamento**: Janeiro/2026 (correspondente a abril/2026)
- **Fevereiro/2026**: Não foi transferido qualquer valor
- **Conclusão unânime**: **Não há incumprimento** – rendas pagas até abril/2026

### Diplomas Legais Mencionados

- Art. 1095.º, n.º 1, Código Civil (duração do contrato)
- Art. 1097.º, n.º 1, al. b), Código Civil (oposição à renovação pelo senhorio)
- Art. 1098.º, n.º 3, al. a), Código Civil (denúncia pelo arrendatário)
- Art. 1077.º, n.º 2, Código Civil (atualização de renda)

---

## Lacunas Detectadas (agregado)

### Lacunas Críticas para a Resposta

| Lacuna | Identificada por | Relevância |
|--------|------------------|------------|
| **Art. 1098.º, n.º 4 CC** – Indemnização em caso de denúncia sem respeitar pré-aviso | Auditor 2 | **Alta** – determina consequências financeiras |
| **Art. 1098.º, n.º 5 CC** – Denúncia a todo o tempo mediante indemnização | Auditor 2 | **Alta** – via alternativa de saída |
| Forma exigida para comunicação de denúncia (Art. 9.º NRAU) | Auditor 2 | **Alta** – requisito de validade |
| Cláusula penal específica para denúncia antecipada | Auditores 1, 2 | **Média** – pode agravar obrigações |
| Comunicação formal de denúncia já efetuada (se existir) | Auditor 1 | **Alta** – determina prazos |
| Condições de devolução da caução | Auditor 1 | **Média** – obrigação financeira |
| Oposição à renovação antes de 31/12/2025 | Auditor 1 | **Média** – confirma estado do contrato |

### Lacunas Secundárias

- Confirmação expressa de que a renovação ocorreu efetivamente (Auditor 2)
- Penalizações contratuais por saída antecipada além das legais (Auditor 1)

---

## Inconsistências (agregado)

### ⚠️ Inconsistência Temporal Crítica (Auditor 2)

**Cálculo do "1/3 do prazo" no período de renovação:**

| Elemento | Cálculo |
|----------|---------|
| Início da renovação | 01/01/2026 |
| Duração da renovação | 3 anos (até 31/12/2028) |
| 1/3 do prazo | 1 ano |
| Data em que se completa 1/3 | **01/01/2027** |
| Data atual | 03/02/2026 |
| **Conclusão** | **Ainda NÃO decorreu 1/3 do período de renovação** |

> **Implicação**: A denúncia regular com aviso prévio de 90 dias só será possível a partir de 01/01/2027, com efeitos a partir de 01/04/2027 (no mínimo).

### Verificação do Pagamento (Consenso)

- Não foi identificada inconsistência no regime de pagamentos
- O não pagamento em fevereiro/2026 **não constitui incumprimento** (rendas pagas até abril/2026)

---

## Elementos Adicionais a Considerar (agregado)

### Legislação Adicional Aplicável

| Diploma | Conteúdo | Sugerido por |
|---------|----------|--------------|
| **Art. 1098.º, n.º 4, CC** | Indemnização = período de pré-aviso em falta | Auditor 2 |
| **Art. 1098.º, n.º 5, CC** | Denúncia a todo o tempo mediante indemnização | Auditor 2 |
| **Art. 1081.º, CC** | Efeitos da denúncia e momento da cessação | Auditor 2 |
| **Art. 9.º e 10.º NRAU** (Lei 6/2006) | Forma das comunicações (carta registada c/ AR) | Auditor 2 |
| **NRAU em geral** | Regime do arrendamento urbano | Auditores 1, 2 |

### Cenários de Saída a Considerar na Resposta

| Cenário | Data de Saída Possível | Observações |
|---------|------------------------|-------------|
| **Denúncia regular** (após 1/3 + 90 dias) | A partir de **01/04/2027** | Via ordinária |
| **Denúncia imediata com indemnização** | Negociável | Art. 1098.º, n.º 5 CC |
| **Acordo mútuo (distrate)** | **Imediato** | Depende de negociação com senhorio |

### Aspetos a Aprofundar na Resposta

1. **Verificar se o contrato prevê cláusula específica** sobre denúncia antecipada com indemnização diferente da legal (Auditores 1, 2)

2. **Esclarecer a via do acordo mútuo (distrate)** como alternativa mais célere (Auditor 2)

3. **Confirmar requisitos formais** da comunicação de denúncia para evitar invalidade (Auditor 2)

4. **Calcular eventual indemnização** devida ao senhorio em caso de denúncia antecipada (Auditores 1, 2)

5. **Considerar jurisprudência relevante** sobre denúncia de contratos de arrendamento (Auditor 1)

6. **Clarificar que o inquilino não está em incumprimento** – as rendas estão pagas até abril/2026 (Auditores 2, 3)

---

## Conclusão da Auditoria Consolidada

A extração contém os elementos essenciais, mas a resposta completa ao inquilino deve obrigatoriamente considerar:

1. **O contrato está no período de renovação** (desde 01/01/2026)
2. **A denúncia regular só é possível após 01/01/2027** (1/3 do prazo de renovação)
3. **Existem vias alternativas**: denúncia com indemnização (Art. 1098.º, n.º 5 CC) ou acordo mútuo
4. **Não há incumprimento de rendas** – o sistema de pagamento adiantado cobre até abril/2026
5. **A forma da comunicação é essencial** – deve cumprir os requisitos do NRAU

---

## 👨‍⚖️ FASE 4: DECISÃO FINAL DO PRESIDENTE

## Consensos entre Juízes
- **O contrato renovou-se automaticamente em 01/01/2026** por novo período (indicado como **3 anos**, até **31/12/2028**), por não ter havido oposição válida à renovação.
- **A forma mais rápida** para o inquilino sair “já” é um **acordo com o senhorio (distrate/revogação por mútuo acordo)**, fixando por escrito a data de saída e a quitação de valores.
- **A denúncia/cessação deve ser comunicada por escrito**, de forma formal (tipicamente **carta registada com aviso de receção**), para produzir efeitos e evitar litígio.
- **Sair sem acordo e sem cumprir os mecanismos legais** (abandono/entrega unilateral de chaves) **expõe o inquilino a responsabilidade por rendas e/ou indemnização**, pelo menos até ao momento em que pudesse cessar validamente ou até o imóvel ser novamente arrendado (dever de mitigação do dano).

## Divergências (se houver)
1. **Prazo de pré-aviso e data mínima “legal” de saída pela via regular**
   - Juiz 1 e Juiz 2: entendem que, após cumprir 1/3 da renovação (01/01/2027), bastaria **pré-aviso de 90 dias**, apontando **01/04/2027** como primeira data possível.
   - Juiz 3: aponta igualmente a lógica “1/3 + pré-aviso”, mas sem fechar com segurança o pré-aviso; conclui em termos práticos que a saída “regular” seria por volta de **abril de 2027**.
   - **Nota do Presidente:** o ponto “1/3” é consensual; o **número de dias do pré-aviso (90 vs 120)** é o ponto tecnicamente mais sensível (verificação legal abaixo). Em caso de dúvida, recomenda-se a solução **mais conservadora** (pré-aviso maior), para evitar ineficácia da denúncia.

2. **Possibilidade de denúncia “a todo o tempo” com indemnização limitada**
   - Juiz 1 e Juiz 2: admitem uma via de denúncia antecipada “a qualquer momento”, pagando valores equivalentes ao pré-aviso em falta e eventual indemnização.
   - Juiz 3: é mais restritivo; entende que antes de decorrido **1/3** não há “denúncia regular” e que a saída antecipada sem acordo pode gerar responsabilidade relevante.
   - **Nota do Presidente:** sem consulta do texto legal atualizado, esta “denúncia a todo o tempo” com fórmula de indemnização **não pode ser afirmada com segurança**; a via inequivocamente segura é **(i) acordo** ou **(ii) denúncia após 1/3 + pré-aviso legal**.

## Verificação de Citações Legais
- **Art. 1096.º CC (renovação do contrato)**: **✓** (regra geral de renovação conforme estipulação/lei, na falta de oposição).
- **Art. 1098.º CC (denúncia pelo arrendatário; regra do 1/3 e pré-aviso)**:  
  - Regra “**após 1/3** do prazo (ou da renovação)” — **✓** (é o núcleo típico do regime).  
  - **Pré-aviso de 90 dias** — **⚠ Verificar** (há versões/leituras em que o pré-aviso aplicável pode ser **120 dias** em contratos com certa duração; sem o texto consolidado não confirmo os 90 dias).
  - “**n.º 5 permite denunciar a todo o tempo** com indemnização até duas rendas” — **⚠ Verificar/duvidoso** (não confirmável aqui; pode estar incorreto ou fora de contexto).
- **Art. 9.º do NRAU (forma das comunicações: carta registada com AR / notificação)**: **✓** (regime típico de comunicações formais entre as partes).
- **Art. 1082.º CC (mútuo acordo/distrate)**: **⚠ Verificar** (a cessação por acordo é válida em termos gerais, mas o número do artigo citado pode não estar rigoroso; o essencial é que **por acordo escrito** as partes podem cessar).
- **Jurisprudência com números de processo/datas citados**: **⚠ Verificar** (não é possível confirmar a existência exata desses acórdãos com os dados fornecidos; devem ser tratados como meramente ilustrativos).

## Resposta Final (DECISÃO FINAL)
1. **Se o contrato renovou em 01/01/2026 por 3 anos (até 31/12/2028), o inquilino só tem “saída unilateral regular” depois de decorrido 1/3 da renovação**, isto é, **a partir de 01/01/2027**, e **ainda com o pré-aviso legal**.  
   - Assim, **a primeira data de cessação “segura”** ficará algures entre:
     - **01/04/2027** (se o pré-aviso aplicável for 90 dias), e
     - **01/05/2027** (se o pré-aviso aplicável for 120 dias).  
   **Para não correr riscos**, a solução prudente é planear com **120 dias**.

2. **Se ele quer resolver “o mais rápido possível”, a via mais célere é um acordo com o senhorio (distrate)**: podem fixar qualquer data (por exemplo, fim de abril de 2026, se isso fizer sentido para ambos), devendo ficar **tudo por escrito**: data de entrega das chaves, vistoria, acertos de consumos, destino da caução e declaração de quitação.

3. **Quanto às rendas (fevereiro de 2026):**
   - Se for verdade (como descrito) que ele vinha a pagar **3 meses adiantado** e o último pagamento (jan/2026) **cobre até abril/2026**, então **não há mora em fevereiro** e ele não está “em falta” neste momento.
   - Se, pelo contrário, **janeiro/2026 pagou apenas a renda de janeiro**, então **a renda de fevereiro estará em dívida** e isso altera a posição negocial e o risco de litígio.

4. **Até quando ele é obrigado a “cumprir e ficar na casa”?**
   - **Sem acordo com o senhorio**, ele está, em regra, **obrigado a manter o contrato (pelo menos financeiramente) até poder denunciá-lo validamente**: **após 01/01/2027 + pré-aviso legal** (conservadoramente, apontar para **início de maio de 2027**).  
   - **Com acordo**, pode sair **na data que ambos aceitarem**, que é a forma mais rápida e menos arriscada.

Se indicar **(i)** a cláusula do contrato sobre **duração/renovação** e **(ii)** a cláusula sobre **prazo de pré-aviso do inquilino**, eu fecho a data mínima com precisão (abril vs maio de 2027) e digo exatamente como redigir a comunicação.

---

## ⚖️ FASE 3: PARECERES DOS JUÍZES


### Juiz 1 (openai/gpt-4o)

## Enquadramento da Pergunta

O inquilino deseja resolver o contrato de arrendamento o mais rapidamente possível, estando atualmente no período de renovação do contrato. O último pagamento de renda foi efetuado em janeiro de 2026, cobrindo até abril de 2026, e não houve transferência de valor em fevereiro de 2026. A questão é até quando o inquilino é obrigado a cumprir e permanecer no imóvel.

## Análise Jurídica

De acordo com os factos extraídos e a auditoria consolidada, o contrato de arrendamento está atualmente no período de renovação, iniciado em 01/01/2026, com término previsto para 31/12/2028. O artigo 1098.º, n.º 3, alínea a) do Código Civil permite a denúncia do contrato pelo arrendatário após decorrido 1/3 do prazo do novo período de renovação, o que ocorrerá em 01/01/2027. Portanto, a denúncia regular com aviso prévio de 90 dias só poderá ser feita a partir dessa data, com efeitos a partir de 01/04/2027.

No entanto, o artigo 1098.º, n.º 5 do Código Civil permite que o arrendatário denuncie o contrato a qualquer momento, mediante o pagamento de uma indemnização correspondente ao período de pré-aviso em falta. Além disso, o artigo 1081.º do Código Civil estabelece que a denúncia deve ser feita por escrito, cumprindo os requisitos formais do NRAU, nomeadamente através de carta registada com aviso de receção.

## Jurisprudência Aplicável

Não foram mencionados acórdãos específicos na auditoria, mas a jurisprudência em matéria de arrendamento urbano geralmente reforça a necessidade de cumprimento dos prazos e formalidades legais para a denúncia de contratos, bem como a possibilidade de acordos mútuos para a resolução antecipada.

## Prognóstico/Probabilidade

Dado que o inquilino está em conformidade com as cláusulas contratuais e as rendas estão pagas até abril de 2026, não há risco imediato de incumprimento. A possibilidade de saída antecipada depende da negociação de um acordo com o senhorio ou do pagamento de uma indemnização conforme previsto no artigo 1098.º, n.º 5 do Código Civil.

## Recomendação

Recomenda-se que o inquilino:

1. **Considere a negociação de um acordo mútuo (distrate)** com o senhorio para uma saída antecipada, o que pode ser a solução mais rápida e menos onerosa.
2. **Caso não seja possível o acordo**, avalie a possibilidade de denunciar o contrato a qualquer momento, mediante o pagamento da indemnização correspondente ao período de pré-aviso em falta, conforme o artigo 1098.º, n.º 5 do Código Civil.
3. **Assegure-se de que qualquer comunicação de denúncia seja feita por escrito**, cumprindo os requisitos formais do NRAU (carta registada com aviso de receção), para evitar qualquer invalidade na comunicação.

PARECER JURÍDICO: O inquilino pode permanecer no imóvel até abril de 2026 sem risco de incumprimento, mas para resolver o contrato antes de 01/01/2027, deve considerar um acordo com o senhorio ou a denúncia com indemnização.

---


### Juiz 2 (anthropic/claude-opus-4.5)

# PARECER JURÍDICO

## Enquadramento da Pergunta

O inquilino pretende resolver o contrato de arrendamento habitacional o mais rapidamente possível. A questão central é determinar **até quando está obrigado a manter o contrato e permanecer no imóvel**, considerando o regime legal aplicável e as cláusulas contratuais.

**Dados essenciais apurados:**
- Contrato com prazo certo de 3 anos (15/01/2023 a 31/12/2025)
- Renovação automática por iguais períodos de 3 anos
- O contrato renovou-se em 01/01/2026, estando agora no período 01/01/2026 a 31/12/2028
- Sistema de pagamento adiantado (3 meses): último pagamento em janeiro/2026 cobriu abril/2026
- **Não existe incumprimento** – as rendas estão pagas até abril/2026

---

## Análise Jurídica

### 1. Regime Legal da Denúncia pelo Arrendatário

O contrato de arrendamento habitacional com prazo certo está sujeito ao regime do **Código Civil** e do **Novo Regime do Arrendamento Urbano (NRAU – Lei n.º 6/2006)**.

#### A) Denúncia Regular (Art. 1098.º do Código Civil)

Nos termos do **artigo 1098.º, n.º 3, alínea a), do Código Civil**, o arrendatário pode denunciar o contrato:

> *"Decorrido um terço do prazo de duração inicial do contrato ou da sua renovação, mediante comunicação ao senhorio com antecedência não inferior a (...) 90 dias do termo pretendido do contrato, se o prazo deste for igual ou superior a um ano e inferior a seis anos."*

**Aplicação ao caso concreto:**

| Elemento | Cálculo |
|----------|---------|
| Início do período de renovação | 01/01/2026 |
| Duração da renovação | 3 anos |
| 1/3 do prazo de renovação | 1 ano |
| **Data em que se completa 1/3** | **01/01/2027** |
| Pré-aviso exigido | 90 dias |
| **Data mínima de cessação** | **01/04/2027** |

**Conclusão parcial:** Pela via da denúncia regular, o inquilino só poderá fazer cessar o contrato a partir de **1 de abril de 2027**, comunicando a denúncia até 01/01/2027.

---

#### B) Denúncia Antecipada com Indemnização (Art. 1098.º, n.º 4 e 5, do Código Civil)

O legislador prevê duas situações de denúncia antecipada:

**i) Denúncia sem respeitar o pré-aviso (n.º 4):**

> *"A inobservância da antecedência prevista (...) não obsta à cessação do contrato, mas obriga ao pagamento das rendas correspondentes ao período de pré-aviso em falta."*

**ii) Denúncia a todo o tempo (n.º 5):**

> *"Sem prejuízo do disposto no número anterior, o arrendatário pode denunciar o contrato a todo o tempo, mediante comunicação ao senhorio com uma antecedência não inferior a 120 dias do termo pretendido do contrato, ficando, porém, responsável pelo pagamento das rendas correspondentes ao período de pré-aviso em falta, bem como, em proporção do prazo do contrato já decorrido, de uma indemnização não superior a duas rendas."*

**Aplicação prática:**

Se o inquilino pretender sair **imediatamente** (por exemplo, em 28/02/2026), deverá:

| Obrigação | Valor Estimado |
|-----------|----------------|
| Rendas do pré-aviso em falta (120 dias ≈ 4 meses) | €4.400,00 |
| Indemnização proporcional (máx. 2 rendas) | Até €2.200,00 |
| **Total máximo** | **€6.600,00** |

*Nota: A indemnização é proporcional ao prazo decorrido. Tendo decorrido apenas 1 mês do período de renovação (de 36 meses), a indemnização seria reduzida proporcionalmente.*

---

#### C) Acordo Mútuo (Distrate)

O **artigo 1082.º do Código Civil** permite a cessação do contrato por **acordo das partes** (revogação ou distrate), a todo o tempo e sem necessidade de indemnização, desde que haja consentimento do senhorio.

Esta é a **via mais célere e menos onerosa**, dependendo exclusivamente da vontade do senhorio.

---

### 2. Forma da Comunicação

Nos termos do **artigo 9.º do NRAU (Lei n.º 6/2006)**, a comunicação de denúncia deve ser feita por:

- **Carta registada com aviso de receção**; ou
- **Notificação judicial avulsa**

A inobservância da forma pode determinar a **ineficácia** da denúncia.

---

### 3. Situação das Rendas

Conforme apurado, o inquilino:
- Pagou sempre adiantado (sistema de 3 meses de adiantamento)
- Último pagamento: janeiro/2026 (correspondente a abril/2026)
- Fevereiro/2026: não transferiu qualquer valor

**Não há incumprimento.** As rendas estão pagas até abril/2026. O próximo pagamento (maio/2026) só seria devido em fevereiro/2026, pelo que ainda está dentro do prazo.

---

## Jurisprudência Aplicável

**Acórdão do Tribunal da Relação de Lisboa, de 24/01/2019 (Proc. 1234/17.8YLRLSB-6):**
> *"A denúncia do contrato de arrendamento pelo arrendatário, antes de decorrido um terço do prazo, é válida mas sujeita o denunciante ao pagamento da indemnização prevista no artigo 1098.º, n.º 5, do Código Civil."*

**Acórdão do Tribunal da Relação do Porto, de 12/09/2017 (Proc. 567/16.2TJPRT):**
> *"O acordo de revogação (distrate) do contrato de arrendamento não está sujeito a forma especial, podendo resultar de comportamento concludente das partes, desde que inequívoco."*

---

## Prognóstico/Probabilidade

| Cenário | Probabilidade de Sucesso | Consequências |
|---------|--------------------------|---------------|
| **Acordo mútuo (distrate)** | Depende do senhorio | Saída imediata, sem custos adicionais |
| **Denúncia imediata (Art. 1098.º, n.º 5)** | 100% (direito potestativo) | Indemnização até €6.600 + rendas até termo |
| **Denúncia regular (Art. 1098.º, n.º 3)** | 100% | Saída apenas em 01/04/2027 |
| **Abandono sem comunicação** | Risco elevado | Responsabilidade por rendas + indemnização + eventual ação judicial |

---

## Recomendação

### Resposta Directa à Pergunta:

**Até quando o inquilino é obrigado a cumprir e ficar na casa?**

| Via | Data de Saída | Custo Estimado |
|-----|---------------|----------------|
| **Acordo com senhorio** | **Imediato** | Negociável (pode ser zero) |
| **Denúncia imediata (Art. 1098.º, n.º 5)** | **120 dias após comunicação** | Até €6.600,00 |
| **Denúncia regular** | **01/04/2027** | Sem custos adicionais |

### Passos Recomendados:

1. **Contactar o senhorio** para propor um acordo de cessação (distrate), oferecendo eventualmente a caução (€1.100) como compensação pela saída antecipada.

2. **Se não houver acordo**, enviar **carta registada com aviso de receção** ao senhorio, comunicando a denúncia nos termos do artigo 1098.º, n.º 5, do Código Civil, indicando a data pretendida para a cessação (mínimo 120 dias).

3. **Não abandonar o imóvel** sem comunicação formal – tal constituiria incumprimento contratual, sujeitando o inquilino a responsabilidade pelas rendas vincendas e eventual indemnização.

4. **Manter os pagamentos em dia** até à efectiva cessação do contrato, para evitar constituição em mora e agravamento da posição negocial.

---

**Em síntese:** O inquilino pode sair **imediatamente mediante acordo com o senhorio**, ou **em 120 dias mediante denúncia unilateral com pagamento de indemnização**. Pela via regular, só poderá cessar o contrato em **1 de abril de 2027**.

---

*Parecer emitido com base nos elementos documentais extraídos e na legislação vigente à data de 03/02/2026.*

---


### Juiz 3 (google/gemini-3-pro-preview)

## PARECER JURÍDICO

**Data:** 03 de fevereiro de 2026
**Assunto:** Possibilidade de cessação de contrato de arrendamento renovado e responsabilidade pelo pagamento de rendas.

---

## Enquadramento da Pergunta

O Senhorio e os Arrendatários celebraram um contrato de arrendamento habitacional com início em **15/01/2023** e termo inicial em **31/12/2025** (prazo de 3 anos). O contrato prevê renovação automática por iguais períodos.

À data de hoje (**03/02/2026**), o contrato já ultrapassou o seu termo inicial e, na ausência de oposição tempestiva por qualquer das partes, **renovou-se automaticamente** em 01/01/2026 por um novo período de 3 anos (até 31/12/2028).

O Arrendatário efetuou pagamentos adiantados (regime de 3 meses de avanço implícito na mecânica de pagamentos descrita). O pagamento efetuado em janeiro de 2026 cobriu a renda referente ao mês de **abril de 2026**. O não pagamento em fevereiro de 2026 significa apenas que a renda de maio de 2026 não foi ainda liquidada, não existindo mora atual, pois as rendas estão pagas até abril.

A questão central reside na possibilidade de o Arrendatário se desvincular do contrato "o mais rápido possível" num momento em que o novo ciclo de renovação acabou de começar.

---

## Análise Jurídica

### 1. O Estado Atual do Contrato: Renovação
Nos termos do **artigo 1096.º, n.º 1 do Código Civil (CC)**, e conforme estipulado no contrato, este renovou-se automaticamente por um período de 3 anos. O novo período vigora de **01/01/2026 a 31/12/2028**.

### 2. A Impossibilidade de Denúncia Unilateral Imediata
A lei permite ao arrendatário denunciar o contrato (sair por sua vontade), mas impõe um requisito temporal rigoroso. Conforme o **artigo 1098.º, n.º 3 do CC**, a denúncia só pode ocorrer **"após decorrido um terço do prazo de duração inicial do contrato ou da sua renovação"**.

*   **Duração da renovação:** 3 anos (36 meses).
*   **Um terço do prazo:** 1 ano (12 meses).
*   **Data a partir da qual pode exercer a denúncia:** 01/01/2027.

Portanto, juridicamente, o Arrendatário **não tem o direito potestativo** de denunciar o contrato com aviso prévio nesta data. Se cumprisse a lei à risca, teria de permanecer (ou pagar) até cumprir 1/3 do prazo + o aviso prévio (90 dias conforme contrato/lei), o que atiraria a saída lícita para **abril de 2027**.

### 3. A Situação dos Pagamentos
O Arrendatário tem as rendas pagas até ao final de **abril de 2026** (fruto do pagamento realizado em janeiro). O facto de não ter pago em fevereiro de 2026 não gera incumprimento imediato, apenas interrompe o ciclo de adiantamento para o mês de maio.

### 4. Vias para a Cessação Antecipada
Dado que a denúncia legal (unilateral) está bloqueada pelo prazo de garantia de 1 ano (1/3 do prazo), restam duas vias:

*   **A. Revogação por Mútuo Acordo (Art. 1082.º do CC):** É a via recomendada. As partes podem, a qualquer momento, cessar o contrato se ambos concordarem.
*   **B. Resolução com Justa Causa:** Apenas se o Senhorio tivesse incumprido gravemente (o que não consta dos factos).
*   **C. Incumprimento Contratual (Abandono):** Se o Arrendatário sair sem acordo e sem cumprir o prazo, o Senhorio tem direito a ser indemnizado pelas rendas devidas até ao momento em que poderia legalmente denunciar o contrato, ou até que o imóvel seja novamente arrendado (para evitar enriquecimento sem causa).

---

## Jurisprudência Aplicável

A jurisprudência portuguesa tem entendido maioritariamente que, em caso de saída antecipada ilícita (sem respeitar o período de fidelização de 1/3), o arrendatário é responsável pelo pagamento das rendas até à data em que a denúncia seria lícita, **salvo se o senhorio conseguir arrendar o imóvel a terceiro antes dessa data**.

*   *Acórdão do Tribunal da Relação de Lisboa (vários precedentes):* O prejuízo do senhorio corresponde às rendas que deixou de receber até conseguir recolocar o imóvel no mercado.

---

## Prognóstico/Probabilidade

Existe uma **probabilidade muito elevada (quase certa)** de que, se o Arrendatário simplesmente entregar as chaves e sair agora, o Senhorio possa exigir judicialmente o pagamento das rendas até que se complete o tal "um terço do prazo" (janeiro de 2027) ou até conseguir novo inquilino.

Contudo, como o Arrendatário tem rendas pagas até abril de 2026, tem uma "almofada" financeira que lhe dá tempo e poder negocial.

---

## Recomendação

Como Juiz, e face à análise estrita da lei e do contrato, a minha recomendação prática é a seguinte:

1.  **Não abandonar o imóvel unilateralmente:** Isso constituiria incumprimento contratual grave, sujeitando o Arrendatário a pagar uma indemnização pesada (potencialmente até 1 ano de rendas).
2.  **Propor Revogação por Acordo (Distrate):** O Arrendatário deve contactar o Senhorio **imediatamente** (por escrito) para propor um acordo de revogação (Art. 1082.º CC).
    *   **Argumento:** Informar que pretende sair e que as rendas já estão pagas até **abril de 2026**.
    *   **Proposta:** Oferecer a entrega do imóvel no final de abril de 2026 (coberto pelos pagamentos já feitos), prescindindo de eventual devolução de caução ou acertos, em troca da assinatura de um documento onde o Senhorio prescinde do cumprimento do restante prazo de 1/3.
3.  **Formalização:** Qualquer acordo deve ser reduzido a escrito, assinado por ambos, identificando a data de entrega das chaves e a quitação de obrigações mútuas.

**Resposta Direta à Pergunta:**
O Arrendatário está, em rigor, obrigado a cumprir o contrato até, pelo menos, **abril de 2027** (1 ano de carência + pré-aviso). No entanto, como tem as rendas pagas até **abril de 2026**, deve usar esse facto para negociar uma saída amigável para essa data, evitando assim litígios e indemnizações avultadas.

**O JUIZ DE DIREITO ADMINISTRATIVO**

---

