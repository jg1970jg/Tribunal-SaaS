# AUDITORIA - Pergunta #2

**Pergunta:** hoje é 03 de fevereiro de 2026 e o inquilino demonstrou interesse em resolver o contrato o mais rapido possivel. ele esteve sempre conforme clausulas do contrato a pagar adiantado desde o inicio contrato onde em março de 2023 pagou o mês de junho de 2023 e assim sucessivamente. este mês de fevereiro de 2026 não transferiu nenhum valor de renda tendo sido o ultimo pagamento efetuado por ele em janeiro de 2026.. ate quando ele e obrigado a cumprir e ficar na casa?

---

# AUDITORIA CONSOLIDADA

## Síntese da Auditoria Consolidada

Os três auditores convergem na identificação dos elementos essenciais do contrato de arrendamento e no enquadramento legal aplicável. O ponto central de consenso é que o contrato se encontra atualmente no período de renovação (iniciado em 01/01/2026), o que tem implicações diretas na possibilidade de denúncia pelo inquilino. O Auditor 2 destaca uma inconsistência temporal crítica: a denúncia regular só será possível após decorrido 1/3 do novo período de renovação (01/01/2027). Todos os auditores confirmam que não existe incumprimento no pagamento de rendas, dado o sistema de pagamento adiantado.

---

## Elementos Relevantes (agregado dos 3 auditores)

### Dados Contratuais Fundamentais

| Elemento | Informação | Fonte |
|----------|------------|-------|
| Tipo de contrato | Arrendamento habitacional com prazo certo | Auditores 1, 2, 3 |
| Data de início | 15/01/2023 | Auditores 1, 2, 3 |
| Termo do prazo inicial | 31/12/2025 | Auditores 1, 2, 3 |
| Prazo inicial | 3 anos | Auditores 1, 2, 3 |
| Renovação | Automática por iguais períodos de 3 anos | Auditores 1, 2, 3 |
| Estado atual | Contrato renovado desde 01/01/2026 (até 31/12/2028) | Auditores 2, 3 |
| Renda mensal | €1.100,00 | Auditor 2 |

### Mecanismos de Cessação Identificados

| Mecanismo | Prazo de Aviso | Base Legal |
|-----------|----------------|------------|
| Oposição à renovação pelo Senhorio | 120 dias antes do termo | Art. 1097.º, n.º 1, al. b) CC |
| Oposição à renovação pelos Arrendatários | 90 dias antes do termo | Não especificado |
| **Denúncia pelos Arrendatários** | **90 dias** | **Art. 1098.º, n.º 3, al. a) CC** |
| Condição para denúncia | Após decorrido 1/3 do prazo | Auditores 1, 2, 3 |

### Regime de Pagamentos

- **Sistema**: Pagamento adiantado (3 meses de adiantamento)
- **Pagamento inicial**: Cobriu até maio de 2023 (€4.950,00)
- **Mecânica**: Em março/2023 pagou-se junho/2023
- **Último pagamento**: Janeiro/2026 (correspondente a abril/2026)
- **Fevereiro/2026**: Não foi transferido qualquer valor
- **Conclusão unânime**: **Não há incumprimento** – rendas pagas até abril/2026

### Diplomas Legais Mencionados

- Art. 1095.º, n.º 1, Código Civil (duração do contrato)
- Art. 1097.º, n.º 1, al. b), Código Civil (oposição à renovação pelo senhorio)
- Art. 1098.º, n.º 3, al. a), Código Civil (denúncia pelo arrendatário)
- Art. 1077.º, n.º 2, Código Civil (atualização de renda)

---

## Lacunas Detectadas (agregado)

### Lacunas Críticas para a Resposta

| Lacuna | Identificada por | Relevância |
|--------|------------------|------------|
| **Art. 1098.º, n.º 4 CC** – Indemnização em caso de denúncia sem respeitar pré-aviso | Auditor 2 | **Alta** – determina consequências financeiras |
| **Art. 1098.º, n.º 5 CC** – Denúncia a todo o tempo mediante indemnização | Auditor 2 | **Alta** – via alternativa de saída |
| Forma exigida para comunicação de denúncia (Art. 9.º NRAU) | Auditor 2 | **Alta** – requisito de validade |
| Cláusula penal específica para denúncia antecipada | Auditores 1, 2 | **Média** – pode agravar obrigações |
| Comunicação formal de denúncia já efetuada (se existir) | Auditor 1 | **Alta** – determina prazos |
| Condições de devolução da caução | Auditor 1 | **Média** – obrigação financeira |
| Oposição à renovação antes de 31/12/2025 | Auditor 1 | **Média** – confirma estado do contrato |

### Lacunas Secundárias

- Confirmação expressa de que a renovação ocorreu efetivamente (Auditor 2)
- Penalizações contratuais por saída antecipada além das legais (Auditor 1)

---

## Inconsistências (agregado)

### ⚠️ Inconsistência Temporal Crítica (Auditor 2)

**Cálculo do "1/3 do prazo" no período de renovação:**

| Elemento | Cálculo |
|----------|---------|
| Início da renovação | 01/01/2026 |
| Duração da renovação | 3 anos (até 31/12/2028) |
| 1/3 do prazo | 1 ano |
| Data em que se completa 1/3 | **01/01/2027** |
| Data atual | 03/02/2026 |
| **Conclusão** | **Ainda NÃO decorreu 1/3 do período de renovação** |

> **Implicação**: A denúncia regular com aviso prévio de 90 dias só será possível a partir de 01/01/2027, com efeitos a partir de 01/04/2027 (no mínimo).

### Verificação do Pagamento (Consenso)

- Não foi identificada inconsistência no regime de pagamentos
- O não pagamento em fevereiro/2026 **não constitui incumprimento** (rendas pagas até abril/2026)

---

## Elementos Adicionais a Considerar (agregado)

### Legislação Adicional Aplicável

| Diploma | Conteúdo | Sugerido por |
|---------|----------|--------------|
| **Art. 1098.º, n.º 4, CC** | Indemnização = período de pré-aviso em falta | Auditor 2 |
| **Art. 1098.º, n.º 5, CC** | Denúncia a todo o tempo mediante indemnização | Auditor 2 |
| **Art. 1081.º, CC** | Efeitos da denúncia e momento da cessação | Auditor 2 |
| **Art. 9.º e 10.º NRAU** (Lei 6/2006) | Forma das comunicações (carta registada c/ AR) | Auditor 2 |
| **NRAU em geral** | Regime do arrendamento urbano | Auditores 1, 2 |

### Cenários de Saída a Considerar na Resposta

| Cenário | Data de Saída Possível | Observações |
|---------|------------------------|-------------|
| **Denúncia regular** (após 1/3 + 90 dias) | A partir de **01/04/2027** | Via ordinária |
| **Denúncia imediata com indemnização** | Negociável | Art. 1098.º, n.º 5 CC |
| **Acordo mútuo (distrate)** | **Imediato** | Depende de negociação com senhorio |

### Aspetos a Aprofundar na Resposta

1. **Verificar se o contrato prevê cláusula específica** sobre denúncia antecipada com indemnização diferente da legal (Auditores 1, 2)

2. **Esclarecer a via do acordo mútuo (distrate)** como alternativa mais célere (Auditor 2)

3. **Confirmar requisitos formais** da comunicação de denúncia para evitar invalidade (Auditor 2)

4. **Calcular eventual indemnização** devida ao senhorio em caso de denúncia antecipada (Auditores 1, 2)

5. **Considerar jurisprudência relevante** sobre denúncia de contratos de arrendamento (Auditor 1)

6. **Clarificar que o inquilino não está em incumprimento** – as rendas estão pagas até abril/2026 (Auditores 2, 3)

---

## Conclusão da Auditoria Consolidada

A extração contém os elementos essenciais, mas a resposta completa ao inquilino deve obrigatoriamente considerar:

1. **O contrato está no período de renovação** (desde 01/01/2026)
2. **A denúncia regular só é possível após 01/01/2027** (1/3 do prazo de renovação)
3. **Existem vias alternativas**: denúncia com indemnização (Art. 1098.º, n.º 5 CC) ou acordo mútuo
4. **Não há incumprimento de rendas** – o sistema de pagamento adiantado cobre até abril/2026
5. **A forma da comunicação é essencial** – deve cumprir os requisitos do NRAU