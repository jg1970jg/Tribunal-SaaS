## Elementos Relevantes (Consolidado)
- **Contrato original**: arrendamento habitacional com prazo certo, início em **15/01/2023** e termo em **31/12/2025**, com **renovação automática por 3 anos** (logo, em princípio, renovado em **01/01/2026 até 31/12/2028**).
- **Regras de denúncia no contrato/lei**: referência a possibilidade de denúncia após **1/3 do prazo** e **aviso prévio** (mencionado como **90 dias**, com dúvida se em certos cenários pode ser **120**).
- **Via usada para saída rápida**: **distrate/revogação por mútuo consentimento** (enquadrável no **art. 1082.º do CC**), como forma correta de terminar antes do que seria possível por denúncia regular.
- **Minuta de distrate**:
  - **Data de cessação proposta**: **28/02/2026**.
  - **Entrega do imóvel**: devolução **livre de pessoas e bens**, com **vistoria conjunta**, registo/relatório e entrega de chaves.
  - **Consumíveis/encargos**: obrigação de **regularização de consumos** (água/luz/gás/telecom, etc.) e apresentação de comprovativos.
  - **Compensação por vacância**: pagamento mensal de **€1.169,07** durante o período em que o imóvel fique vazio após a cessação, com **teto máximo de 3 meses** (e limite temporal “até junho/2026”, conforme descrito).
  - **Regra anti-duplicação**: a compensação **cessa quando houver novo arrendamento**, para evitar receber “duas vezes” (nova renda + compensação).
  - **Caução**: prevista para cobrir **danos/consumos/rendas em dívida**, com devolução do remanescente (referido prazo de **60 dias**, alinhado com o contrato original).
  - **Reserva para danos ocultos**: previsão de responsabilidade por **danos não detetáveis** na vistoria.
- **Histórico de pagamentos**: indicado que o último pagamento foi em **janeiro/2026** e existe referência a **pagamentos adiantados** (ex.: em 03/2023 pagou “meses à frente”), o que pode alterar totalmente o acerto final.
- **Outras cláusulas do contrato original relevantes para o fecho** (apontadas numa auditoria): inventário/fotos na entrada; proibições (obras/sublocação); indemnizações por mora e por não restituição; foro competente (Cascais).

---

## Lacunas (Consolidado)
- **Rendas pagas adiantadas / crédito do inquilino (CRÍTICO)**:
  - A minuta não trata explicitamente o cenário de existirem **rendas já pagas para meses posteriores** à data de cessação (ex.: março/abril de 2026), nem define **imputação/dedução/devolução** desses valores.
- **Justificação e base legal do valor €1.169,07**:
  - Não está demonstrado/documentado se este é o valor de renda **atualizado legalmente** (e se as atualizações foram **formalmente comunicadas**), o que pode gerar contestação no cálculo da compensação.
- **Auto de Entrega/Vistoria não anexado (ALTA)**:
  - É referido/necessário, mas não aparece como documento fechado/anexo essencial; sem ele, perde-se “prova” estruturada do estado do imóvel na entrega.
- **Quitação/fecho de contas insuficientemente explícito**:
  - Falta uma cláusula clara de **quitação recíproca** do que fica resolvido na data (ex.: estado visível do imóvel), articulada com a ressalva de danos ocultos, para reduzir litígios posteriores.
- **Prazo de aceitação/assinatura da proposta**:
  - A minuta/carta não fixa uma data-limite de validade/aceitação, criando risco de indefinição.
- **Prova de comunicações formais e intenção de saída**:
  - Não está documentado no pacote analisado se o inquilino comunicou formalmente a intenção de sair; isto não invalida um distrate assinado, mas enfraquece a “trilha” documental até haver acordo.
- **Consumíveis/regularizações sem mecanismo de execução**:
  - A minuta pede comprovativos, mas não detalha o que acontece se **não forem apresentados no ato** (ex.: método de estimativa/dedução/retensão e prazos).
- **Cruzamento incompleto com todas as cláusulas do contrato original**:
  - Não há validação expressa de que o distrate contempla/derroga/resolve todas as obrigações relevantes (ex.: inventário, obras, penalidades, etc.).

---

## Inconsistências (Consolidado)
- **Compensação por vacância vs. rendas já pagas**:
  - Se existir pagamento adiantado cobrindo meses após 28/02/2026, a minuta pode criar **duplicação** (inquilino alegar “já paguei”; senhorio pedir compensação adicional), porque a regra anti-duplicação só trata o caso de **novo arrendamento**, não o caso de **renda antecipada**.
- **Cessação em 28/02/2026 vs. situação do pagamento de fevereiro**:
  - Há ambiguidade: “não pagou fevereiro” mas “pagava adiantado” e “último pagamento em janeiro”; sem clarificação, pode haver inconsistência sobre **se fevereiro está em dívida** ou já está coberto.
- **Aviso prévio 90 vs. 120 dias (potencial divergência)**:
  - Surgiu dúvida se o prazo indicado é sempre aplicável; não afeta o distrate se houver acordo assinado, mas sinaliza possível inconsistência na leitura das regras de denúncia “alternativa”.
- **“Proteção a 100%” vs. teto de 3 meses**:
  - O teto de compensação é uma **opção negocial** que limita a recuperação do senhorio se o imóvel ficar vazio mais tempo; logo, por desenho, não é “100%” de cobertura económica (ainda que seja juridicamente válido se acordado).
- **Reserva de direitos (danos ocultos) vs. ausência de quitação do visível**:
  - Sem quitação explícita do estado verificado, pode abrir porta a discussões sobre o que estava ou não incluído no acerto final.

---

## Elementos Adicionais (Consolidado)
- **Inserir cláusula específica para rendas adiantadas** (ponto mais urgente):
  - Reconhecer o montante e meses cobertos; prever que esse valor é **imputado** à compensação e/ou **deduzido** a quaisquer quantias a pagar; e, se sobrar a favor do inquilino, **devolução em prazo curto** (ou compensação no acerto final).
- **Clarificar e documentar o valor mensal (€1.169,07)**:
  - Confirmar qual é a **renda em vigor** na data; anexar memória de cálculo/coeficiente e, idealmente, prova de comunicação de atualização (ou então usar €1.100,00 para evitar disputa).
- **Anexar e assinar o Auto de Entrega/Vistoria**:
  - Com check-list, leituras de contadores, inventário, fotos datadas, declaração de entrega de chaves e indicação de eventuais reservas.
- **Adicionar cláusula de quitação (com ressalva de danos ocultos)**:
  - Quitação do estado visível verificado e das quantias discriminadas no acerto, preservando apenas (i) danos ocultos e (ii) acertos de consumos faturados posteriormente dentro de um prazo definido.
- **Fixar prazo de aceitação/validade da proposta**:
  - Ex.: “proposta válida até DD/MM/AAAA; sem aceitação escrita considera-se caduca”.
- **Prever expressamente o cenário de não assinatura**:
  - Cláusula deixando claro que, sem distrate assinado, o contrato mantém-se em vigor, com rendas e demais obrigações.
- **Melhorar o mecanismo de consumos/encargos**:
  - Definir o que acontece se não houver comprovativos no dia: autorização para **reter caução**, estimativa, prazo para apresentação, e acerto posterior.
- **Assinaturas com reconhecimento presencial (recomendado para “blindagem”)**:
  - Reconhecimento por notário/advogado/solicitador, reduzindo risco de alegações de falsificação/coação.
- **Pré-vistoria antes da assinatura**:
  - Para avaliar danos relevantes; se existirem, prever **reconhecimento de dívida**/orçamento e forma de pagamento além da caução.
- **Rever conformidades formais de comunicações** (boa prática):
  - Usar **carta registada com AR** para comunicações críticas (referência ao NRAU/art. 15.º), embora o essencial seja o distrate final assinado.

SÍNTESE CONSOLIDADA: as auditorias convergem em que a minuta é, em geral, um bom esqueleto para um distrate, mas **não “protege a 100%”** enquanto não tratar de forma inequívoca (i) **rendas adiantadas**, (ii) **auto de entrega/vistoria**, (iii) **base do valor mensal**, e (iv) **quitação/acerto final** com prazos e regras operacionais.