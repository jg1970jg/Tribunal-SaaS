# DECISÃO FINAL - Pergunta #2

**Pergunta:** hoje é 03 de fevereiro de 2026 e o inquilino demonstrou interesse em resolver o contrato o mais rapido possivel. ele esteve sempre conforme clausulas do contrato a pagar adiantado desde o inicio contrato onde em março de 2023 pagou o mês de junho de 2023 e assim sucessivamente. este mês de fevereiro de 2026 não transferiu nenhum valor de renda tendo sido o ultimo pagamento efetuado por ele em janeiro de 2026.. ate quando ele e obrigado a cumprir e ficar na casa?

---

## Consensos entre Juízes
- **O contrato renovou-se automaticamente em 01/01/2026** por novo período (indicado como **3 anos**, até **31/12/2028**), por não ter havido oposição válida à renovação.
- **A forma mais rápida** para o inquilino sair “já” é um **acordo com o senhorio (distrate/revogação por mútuo acordo)**, fixando por escrito a data de saída e a quitação de valores.
- **A denúncia/cessação deve ser comunicada por escrito**, de forma formal (tipicamente **carta registada com aviso de receção**), para produzir efeitos e evitar litígio.
- **Sair sem acordo e sem cumprir os mecanismos legais** (abandono/entrega unilateral de chaves) **expõe o inquilino a responsabilidade por rendas e/ou indemnização**, pelo menos até ao momento em que pudesse cessar validamente ou até o imóvel ser novamente arrendado (dever de mitigação do dano).

## Divergências (se houver)
1. **Prazo de pré-aviso e data mínima “legal” de saída pela via regular**
   - Juiz 1 e Juiz 2: entendem que, após cumprir 1/3 da renovação (01/01/2027), bastaria **pré-aviso de 90 dias**, apontando **01/04/2027** como primeira data possível.
   - Juiz 3: aponta igualmente a lógica “1/3 + pré-aviso”, mas sem fechar com segurança o pré-aviso; conclui em termos práticos que a saída “regular” seria por volta de **abril de 2027**.
   - **Nota do Presidente:** o ponto “1/3” é consensual; o **número de dias do pré-aviso (90 vs 120)** é o ponto tecnicamente mais sensível (verificação legal abaixo). Em caso de dúvida, recomenda-se a solução **mais conservadora** (pré-aviso maior), para evitar ineficácia da denúncia.

2. **Possibilidade de denúncia “a todo o tempo” com indemnização limitada**
   - Juiz 1 e Juiz 2: admitem uma via de denúncia antecipada “a qualquer momento”, pagando valores equivalentes ao pré-aviso em falta e eventual indemnização.
   - Juiz 3: é mais restritivo; entende que antes de decorrido **1/3** não há “denúncia regular” e que a saída antecipada sem acordo pode gerar responsabilidade relevante.
   - **Nota do Presidente:** sem consulta do texto legal atualizado, esta “denúncia a todo o tempo” com fórmula de indemnização **não pode ser afirmada com segurança**; a via inequivocamente segura é **(i) acordo** ou **(ii) denúncia após 1/3 + pré-aviso legal**.

## Verificação de Citações Legais
- **Art. 1096.º CC (renovação do contrato)**: **✓** (regra geral de renovação conforme estipulação/lei, na falta de oposição).
- **Art. 1098.º CC (denúncia pelo arrendatário; regra do 1/3 e pré-aviso)**:  
  - Regra “**após 1/3** do prazo (ou da renovação)” — **✓** (é o núcleo típico do regime).  
  - **Pré-aviso de 90 dias** — **⚠ Verificar** (há versões/leituras em que o pré-aviso aplicável pode ser **120 dias** em contratos com certa duração; sem o texto consolidado não confirmo os 90 dias).
  - “**n.º 5 permite denunciar a todo o tempo** com indemnização até duas rendas” — **⚠ Verificar/duvidoso** (não confirmável aqui; pode estar incorreto ou fora de contexto).
- **Art. 9.º do NRAU (forma das comunicações: carta registada com AR / notificação)**: **✓** (regime típico de comunicações formais entre as partes).
- **Art. 1082.º CC (mútuo acordo/distrate)**: **⚠ Verificar** (a cessação por acordo é válida em termos gerais, mas o número do artigo citado pode não estar rigoroso; o essencial é que **por acordo escrito** as partes podem cessar).
- **Jurisprudência com números de processo/datas citados**: **⚠ Verificar** (não é possível confirmar a existência exata desses acórdãos com os dados fornecidos; devem ser tratados como meramente ilustrativos).

## Resposta Final (DECISÃO FINAL)
1. **Se o contrato renovou em 01/01/2026 por 3 anos (até 31/12/2028), o inquilino só tem “saída unilateral regular” depois de decorrido 1/3 da renovação**, isto é, **a partir de 01/01/2027**, e **ainda com o pré-aviso legal**.  
   - Assim, **a primeira data de cessação “segura”** ficará algures entre:
     - **01/04/2027** (se o pré-aviso aplicável for 90 dias), e
     - **01/05/2027** (se o pré-aviso aplicável for 120 dias).  
   **Para não correr riscos**, a solução prudente é planear com **120 dias**.

2. **Se ele quer resolver “o mais rápido possível”, a via mais célere é um acordo com o senhorio (distrate)**: podem fixar qualquer data (por exemplo, fim de abril de 2026, se isso fizer sentido para ambos), devendo ficar **tudo por escrito**: data de entrega das chaves, vistoria, acertos de consumos, destino da caução e declaração de quitação.

3. **Quanto às rendas (fevereiro de 2026):**
   - Se for verdade (como descrito) que ele vinha a pagar **3 meses adiantado** e o último pagamento (jan/2026) **cobre até abril/2026**, então **não há mora em fevereiro** e ele não está “em falta” neste momento.
   - Se, pelo contrário, **janeiro/2026 pagou apenas a renda de janeiro**, então **a renda de fevereiro estará em dívida** e isso altera a posição negocial e o risco de litígio.

4. **Até quando ele é obrigado a “cumprir e ficar na casa”?**
   - **Sem acordo com o senhorio**, ele está, em regra, **obrigado a manter o contrato (pelo menos financeiramente) até poder denunciá-lo validamente**: **após 01/01/2027 + pré-aviso legal** (conservadoramente, apontar para **início de maio de 2027**).  
   - **Com acordo**, pode sair **na data que ambos aceitarem**, que é a forma mais rápida e menos arriscada.

Se indicar **(i)** a cláusula do contrato sobre **duração/renovação** e **(ii)** a cláusula sobre **prazo de pré-aviso do inquilino**, eu fecho a data mínima com precisão (abril vs maio de 2027) e digo exatamente como redigir a comunicação.