# DECISÃO FINAL - Pergunta #1

**Pergunta:** mas as cláusulas do contrato de arrendamento (aqui veio anexado) nomeadamente clausula segunda ponto 4 fala sobre o ter de decorrer um terço do prazo inicial do contrato ou da sua renovaçao! o contrato iniciou em 15 janeiro de 2023  e termo em 31 dezembro 2025 logo renovou, certo? direitos do senhorio ? deveres e direitos inquilino pelo contrato arrendamento

---

## Consensos entre Juízes
1. **“Regra do 1/3” não é renovação.**  
   Todos concordam que a cláusula (e a lei) sobre ter de decorrer **1/3 do prazo** diz respeito ao **direito do arrendatário denunciar (sair) antes do fim**, e **não** significa que o contrato “já renovou”.

2. **O contrato só renova no termo (31/12/2025), se ninguém se opuser.**  
   Com início em **15/01/2023** e termo em **31/12/2025**, o contrato está ainda no **prazo inicial** e **só renovará** (automaticamente) a partir de **01/01/2026**, se não houver oposição válida e atempada.

3. **Prazos de oposição à renovação (ideia geral coincidente):**  
   - **Senhorio:** tem de comunicar a oposição com antecedência maior (apontam **120 dias**).  
   - **Inquilino:** antecedência menor (apontam **90 dias** para oposição à renovação).

4. **Direitos/deveres essenciais (contrato + regras gerais):**  
   Há acordo quanto ao núcleo:  
   - **Senhorio**: direito a receber a renda; possibilidade de se opor à renovação; exigir restituição do imóvel; reagir a mora/incumprimento.  
   - **Inquilino**: direito ao gozo do imóvel; possibilidade de denunciar após 1/3 do prazo; dever de pagar rendas e conservar o locado; limites a obras/sublocação (conforme cláusulas).

---

## Divergências (se houver)
1. **Prazo de aviso prévio na denúncia pelo inquilino após 1/3: 90 vs 120 dias**
   - **Perspetiva A (Juiz 1 e Juiz 2):** assumem **90 dias** (muito alinhado com a cláusula contratual referida e com a prática contratual).  
   - **Perspetiva B (Juiz 3):** alerta que **a lei pode exigir 120 dias** em certos casos e que a redução para 90, embora conste do contrato, pode ser discutível; por prudência recomenda cumprir **120 dias** se houver risco de litígio.
   
   **Mérito de cada:**  
   - Se o contrato efetivamente prevê 90 dias e foi aceite pelo senhorio, pode ser defensável que se aplique (sobretudo se for entendido como regime convencional).  
   - Porém, se o prazo legal aplicável for imperativo (mínimo) a favor do senhorio, um tribunal pode não aceitar a redução; **para segurança jurídica, 120 dias é a opção mais prudente** sem ver o clausulado integral e o enquadramento (duração exata, tipo de contrato, etc.).

2. **Afirmações acessórias sobre “caução” e obrigações legais específicas**  
   - Surge num parecer a sugestão de obrigação legal específica de “depositar caução” ao abrigo de lei especial; isto **não é consensual** e é juridicamente duvidoso (verificação abaixo).

---

## Verificação de Citações Legais
(Portugal – Código Civil, arrendamento urbano)

- **Art. 1096.º CC (renovação automática do contrato com prazo certo, salvo oposição):** ✓ citação correta (no essencial).  
- **Art. 1097.º, n.º 1 (oposição do senhorio à renovação, com prazos consoante duração):** ✓ correto no essencial quanto à lógica e ao prazo típico de **120 dias** para vários contratos habitacionais de duração comum (1 a 6 anos).  
- **Art. 1098.º CC (oposição à renovação/denúncia pelo arrendatário; inclui a regra do 1/3 e prazos de pré-aviso):** ⚠ verificar (incerteza nos pareceres quanto ao **prazo exato** aplicável — 90 vs 120 — e ao número/alínea concretos). A “regra do 1/3” está correta, mas o **pré-aviso legal** pode não coincidir com os 90 dias indicados por alguns.  
- **Art. 1038.º CC (obrigações do arrendatário, incluindo pagar renda e usar prudentemente):** ✓ correto.  
- **Art. 1041.º CC (indemnização por mora no pagamento da renda – frequentemente 20%):** ✓ correto no essencial.  
- **Art. 1043.º CC (restituição do locado no fim, em regra no estado em que foi entregue, salvo deteriorações inerentes ao uso normal):** ✓ correto.  
- **Art. 1045.º CC (não restituição do locado e indemnização – frequentemente associada a “dobro da renda” em certos contextos):** ⚠ verificar (a solução de indemnização existe; o modo exato de cálculo/“dobro” depende da redação aplicável e do enquadramento factual, e pode também estar reforçado por cláusula contratual).  
- **Referência à “Lei 6/2006, art. 7.º-A” como impondo deveres sobre caução em conta específica:** ✗ duvidosa/incorreta (não é uma obrigação geral pacífica nesses termos; exige confirmação).

---

## Resposta Final (clara, direta e fundamentada)

1. **O contrato “já renovou”?**  
   **Não.** O facto de ter decorrido **1/3 do prazo** **não significa renovação**.  
   Com início em **15/01/2023** e termo em **31/12/2025**, o contrato está no **prazo inicial** e **só renovará** a partir de **01/01/2026**, **se** nenhuma das partes enviar oposição à renovação dentro do prazo legal.

2. **O que significa a cláusula do “1/3 do prazo” (Cláusula 2.ª, n.º 4)?**  
   Significa que o **inquilino pode denunciar (terminar) o contrato antes do termo**, **depois de decorrido 1/3 do prazo inicial** (ou 1/3 do prazo da renovação, quando já estiver renovado).  
   - 1/3 de ~3 anos ≈ **1 ano** → a partir de **15/01/2024**, em regra, o inquilino passa a poder denunciar, **cumprindo o aviso prévio**.

3. **Prazos práticos (tomando 31/12/2025 como termo):**
   - **Se o senhorio não quiser renovar:** tem de comunicar a oposição com antecedência legal (tipicamente **120 dias**) → aproximadamente até **início de setembro de 2025**.  
   - **Se o inquilino não quiser renovar e quer sair no fim (31/12/2025):** tem de comunicar com a antecedência legal (frequentemente **90 dias** para oposição à renovação) → aproximadamente até **início de outubro de 2025**.  
   - **Se o inquilino quer sair antes de 31/12/2025 (denúncia após 1/3):** pode fazê-lo desde que já tenha passado 1/3 e respeite o **pré-aviso**. Aqui há o ponto sensível: **o contrato pode indicar 90 dias, mas a lei pode apontar 120 dias em certos casos**. **Para evitar risco**, se puder, dê **120 dias** de pré-aviso (ou peça confirmação escrita ao senhorio aceitando 90 dias).

4. **Direitos e deveres (síntese)**
   - **Senhorio (direitos):** receber a renda; exigir cumprimento contratual; opor-se à renovação nos prazos; exigir restituição do imóvel no fim; exigir indemnizações por mora/incumprimento nos termos legais e/ou contratuais.  
   - **Senhorio (deveres):** assegurar o gozo do locado para habitação e atuar nos termos legais quanto a reparações/condições do imóvel; emitir recibos (quando aplicável) e cumprir o contrato.  
   - **Inquilino (deveres):** pagar renda pontualmente; usar o imóvel conforme o fim habitacional; conservar e devolver o locado; não sublocar/ceder/alterar sem autorização quando o contrato o proíba; suportar consumos e demais encargos contratualizados.  
   - **Inquilino (direitos):** gozo do imóvel; denunciar após 1/3 com pré-aviso; opor-se à renovação; devolução de caução nos termos contratados (deduzida de danos/dívidas, se existirem).

**DECISÃO FINAL:**  
A cláusula do “1/3” **não implica renovação**; apenas abre ao inquilino a possibilidade de **denunciar antecipadamente** após 15/01/2024 (com pré-aviso). A **renovação** só ocorrerá em **01/01/2026** se não houver oposição atempada. Para qualquer saída, recomendo comunicação **por escrito** (idealmente carta registada com AR) e, por prudência, considerar **120 dias** de pré-aviso se houver dúvida entre contrato e lei.

Se me disser **a data de hoje** e **se pretende sair quando**, eu faço as contas exatas do prazo de aviso (com calendário) e indico o texto-base da carta.