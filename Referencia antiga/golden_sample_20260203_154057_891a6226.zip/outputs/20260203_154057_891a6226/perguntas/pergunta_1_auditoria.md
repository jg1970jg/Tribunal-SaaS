# AUDITORIA - Pergunta #1

**Pergunta:** mas as cláusulas do contrato de arrendamento (aqui veio anexado) nomeadamente clausula segunda ponto 4 fala sobre o ter de decorrer um terço do prazo inicial do contrato ou da sua renovaçao! o contrato iniciou em 15 janeiro de 2023  e termo em 31 dezembro 2025 logo renovou, certo? direitos do senhorio ? deveres e direitos inquilino pelo contrato arrendamento

---

# AUDITORIA CONSOLIDADA

## Síntese da Auditoria Consolidada

Os três auditores convergem na identificação dos elementos essenciais do contrato de arrendamento, com particular ênfase na distinção entre **denúncia antecipada** (regra do 1/3) e **renovação automática** — conceitos que o utilizador aparenta confundir. Todos os auditores alertam para a inconsistência temporal na premissa do utilizador e para a necessidade de clarificar o contexto temporal atual.

---

## Elementos Relevantes (agregado dos 3 auditores)

### Factos Contratuais Específicos

| Elemento | Dados Extraídos | Fonte/Confirmação |
|----------|-----------------|-------------------|
| **Prazo inicial** | 3 anos | Todos os auditores |
| **Data de início** | 15/01/2023 | Todos os auditores |
| **Termo do prazo inicial** | 31/12/2025 | Todos os auditores |
| **Renovação** | Automática por períodos iguais de 3 anos | Todos os auditores |
| **Renda mensal** | €1.100,00 | Auditores 1 e 2 |
| **Pagamento** | 1.º dia útil de cada mês | Auditor 2 |

### Regras de Denúncia e Oposição à Renovação

| Mecanismo | Prazo/Condição | Base Legal |
|-----------|----------------|------------|
| **Denúncia pelo arrendatário (após 1/3)** | 90 dias de aviso prévio | Art. 1098.º, n.º 3, al. a) CC |
| **Oposição à renovação - Senhorio** | 120 dias de antecedência | Art. 1097.º, n.º 1, al. b) CC |
| **Oposição à renovação - Arrendatários** | 90 dias de antecedência | Art. 1098.º, n.º 3, al. a) CC |

### Cálculo do 1/3 do Prazo (consenso dos 3 auditores)

- Duração inicial: ~36 meses (3 anos)
- **1/3 = 12 meses**
- **Data a partir da qual o arrendatário pode denunciar: 15/01/2024**
- Desde essa data, os arrendatários podem sair com 90 dias de aviso prévio

### Direitos e Deveres Identificados

**SENHORIO - Direitos:**
- Receber renda mensal de €1.100,00 pontualmente
- Indemnização de 20% sobre rendas em dívida (mora)
- Mostrar imóvel nos 2 meses anteriores ao termo (com aviso prévio)
- Opor-se à renovação com 120 dias de antecedência
- Receber indemnização (dobro da renda) por não restituição do imóvel
- Atualização anual da renda (coeficiente legal)

**ARRENDATÁRIOS - Deveres:**
- Pagar renda no 1.º dia útil de cada mês
- Suportar consumos (água, luz, gás, telecomunicações)
- Celebrar contratos de fornecimento em nome próprio
- Não sublocar/ceder uso/alojamento local
- Não exercer atividade profissional no imóvel
- Não fazer obras sem autorização escrita
- Não fazer furos em azulejos, tetos, caixilhos
- Manter espaços comuns livres
- Indemnizar danos causados por animais
- Restituir imóvel no termo do contrato

**ARRENDATÁRIOS - Direitos:**
- Denunciar contrato após 1/3 do prazo (com 90 dias aviso)
- Opor-se à renovação com 90 dias de antecedência
- Devolução da caução até 60 dias após termo
- Fazer reparações urgentes sem autorização

### Diplomas Legais Mencionados
- Art. 1095.º, n.º 1 CC (prazo certo)
- Art. 1097.º, n.º 1, al. b) CC (oposição senhorio)
- Art. 1098.º, n.º 3, al. a) CC (oposição/denúncia arrendatário)
- Art. 1077.º, n.º 2 CC (atualização renda)
- RGPD (Regulamento UE 2016/679) e Lei n.º 58/2019

---

## Lacunas Detectadas (agregado)

### Lacunas Críticas (afetam resposta direta)

| Lacuna | Impacto | Identificada por |
|--------|---------|------------------|
| **Data atual/contexto temporal** | Impossível confirmar se o contrato "já renovou" sem saber a data da consulta | Auditor 3 |
| **Texto integral da Cláusula 2.ª, ponto 4** | Não foi transcrita literalmente; apenas resumida | Auditores 2 e 3 |
| **Estado atual do contrato** | Não há confirmação se o contrato já foi renovado ou se ainda está no prazo inicial | Auditor 1 |
| **Comunicações de oposição** | Não consta se houve comunicação de oposição à renovação por qualquer parte | Auditores 1 e 2 |

### Lacunas Secundárias

| Lacuna | Identificada por |
|--------|------------------|
| Direitos de fiscalização/vistoria do senhorio não detalhados | Auditor 2 |
| Consequências do incumprimento (além da mora de 20%) | Auditor 2 |
| Ausência de referência ao Art. 1083.º CC (resolução pelo senhorio) | Auditor 2 |
| Eventual direito de preferência não extraído | Auditor 2 |
| Regime de obras (Art. 1074.º CC) não mencionado | Auditor 2 |
| Verificação se a caução foi depositada em conta específica | Auditor 2 |
| Confirmação do registo do contrato nas Finanças | Auditor 2 |

---

## Inconsistências (agregado)

### ⚠️ Inconsistência Principal: Premissa do Utilizador

| Problema | Análise | Identificada por |
|----------|---------|------------------|
| **"termo em 31/12/2025 logo renovou, certo?"** | Se o termo é 31/12/2025, o contrato **ainda não renovou** (salvo se estivermos em 2026). A renovação só ocorrerá a **01/01/2026**, se nenhuma das partes se opuser | Auditores 2 e 3 |

### ⚠️ Inconsistência de Datas Contratuais

| Problema | Análise | Identificada por |
|----------|---------|------------------|
| **Prazo inicial ≠ 3 anos completos** | Início: 15/01/2023 → Termo: 31/12/2025 = **2 anos, 11 meses e 16 dias** (não são 3 anos exatos) | Auditor 2 |

> **ALERTA**: Se o contrato estipula "prazo de 3 anos" mas as datas indicam menos, há potencial inconsistência contratual ou erro de extração. Recomenda-se verificação do documento original.

### Confusão Conceptual do Utilizador

| Problema | Esclarecimento | Identificada por |
|----------|----------------|------------------|
| Confusão entre "denúncia após 1/3" e "renovação" | São mecanismos **distintos**: (1) 1/3 do prazo = momento a partir do qual o inquilino pode sair antes do fim; (2) Renovação = acontece apenas no final do contrato | Auditor 3 |

### Divergência Menor entre Extratores
- E5 omite "n.º 1" na citação do Art. 1097.º — menor relevância prática, mas denota imprecisão (Auditor 2)

---

## Elementos Adicionais a Considerar (agregado)

### Legislação Complementar Aplicável

| Diploma | Relevância | Sugerido por |
|---------|------------|--------------|
| **Art. 1083.º CC** | Fundamentos de resolução pelo senhorio | Auditor 2 |
| **Art. 1084.º CC** | Modo de resolução | Auditor 2 |
| **Art. 1041.º CC** | Mora do arrendatário | Auditor 2 |
| **Art. 1081.º CC** | Modos de cessação do arrendamento | Auditor 2 |
| **Art. 1096.º CC** | Renovação automática | Auditor 2 |
| **Art. 1074.º CC** | Regime de obras | Auditor 2 |
| **Lei 6/2006 (NRAU)** | Regime geral do arrendamento urbano | Auditor 2 |
| **Legislação local específica** | Verificar se afeta o contrato | Auditor 1 |

### Jurisprudência a Analisar
- Interpretação de cláusulas de renovação automática e denúncia de contratos de arrendamento (Auditor 1)

### Cálculos e Datas-Chave para Resposta

| Marco | Data | Observação |
|-------|------|------------|
| **1/3 do prazo completo** | 15/01/2024 | Desde esta data, arrendatários podem denunciar |
| **Termo do prazo inicial** | 31/12/2025 | — |
| **Renovação automática** | 01/01/2026 | Se não houver oposição válida |
| **Novo termo (após renovação)** | 31/12/2028 | Mais 3 anos |

### Aspetos a Aprofundar/Verificar

1. **Confirmar data atual** para determinar se o contrato já renovou (Auditor 3)
2. **Verificar se houve comunicação de oposição** à renovação por qualquer parte (Auditores 1, 2 e 3)
3. **Confirmar se as datas contratuais** (15/01/2023 a 31/12/2025) correspondem efetivamente a "3 anos" (Auditor 2)
4. **Verificar se a caução foi depositada** em conta específica (obrigação legal) (Auditor 2)
5. **Analisar proporcionalidade** das cláusulas de proibição de obras/furos (Auditor 2)
6. **Alertar para penalizações** se o utilizador pretender sair sem aviso prévio (Auditor 3)
7. **Revisão do contrato original** para confirmar condições específicas (Auditor 1)

---

## Síntese Final para Resposta ao Utilizador

| Ponto | Conclusão |
|-------|-----------|
| ✅ **Renovação** | O contrato renova automaticamente em **01/01/2026** (salvo oposição válida nos prazos legais) |
| ✅ **Regra do 1/3** | Os arrendatários podem denunciar desde **15/01/2024** (com 90 dias de aviso prévio) |
| ⚠️ **Atenção** | O utilizador parece confundir "denúncia após 1/3" com "renovação" — são mecanismos distintos |
| ⚠️ **Verificar** | Confirmar se as datas contratuais correspondem efetivamente a 3 anos e se houve alguma comunicação de oposição |