## Elementos Relevantes (Consolidado)
- **Contrato de arrendamento (original)**
  - Início: **15/01/2023**
  - Termo: **31/12/2025**, com **renovação automática** por períodos iguais (histórico indica renovação em **01/01/2026**, se não houve oposição válida).
  - **Renda inicial:** **€1.100,00/mês**
  - **Caução:** **€1.100,00**
  - **Prazo de devolução da caução no contrato:** **até 60 dias** após o termo (conforme indicado na Auditoria 2).
  - **Consumos** (água/luz/gás/telecom, etc.): responsabilidade dos arrendatários.
  - Existência de **inventário/fotorreportagem** como anexo (relevante para confronto na entrega).
  - **Foro/competência:** Comarca de **Cascais** (mencionado).
- **Distrate (revogação por mútuo acordo) / cessação**
  - Data de cessação proposta: **28/02/2026**.
  - Inclui **condição de validade/aceitação** ligada à **entrega do imóvel** e **vistoria/auto de entrega** assinado.
  - Prevê **encontro de contas** (rendas pagas adiantadas vs. compensações, danos e consumos).
  - Prevê **compensação por vacância** (modelo “tempo efetivo de vazio” até novo arrendamento), com **teto máximo** (referido: **até 3 meses** e data-limite **30/06/2026** em pelo menos uma minuta).
  - Inclui **regra anti-duplicação** (evitar receber duas vezes pelo mesmo período: novo inquilino vs compensação).
  - Define um regime de **quitação** (com reservas por consumos/danos detetados a posteriori) e um **prazo** para fechar contas (p.ex., referência a **60 dias** para certos acertos em Auditoria 2).
- **Documentos operacionais anexos**
  - **Auto de Entrega e Vistoria (Anexo I)**: chaves, leituras de contadores, inventário e referência a fotos—importante para prova do estado do locado.
  - **Carta de aceitação/condições do distrate**: formaliza requisitos (vistoria, regularização de consumos, etc.).
  - Há referência a **Anexo II / Mapa de Acerto Final** (documento crítico para operacionalizar o encontro de contas).
- **Valores/atualizações**
  - O distrate “fixa” valores de renda atualizada (referidos: **€1.143,45** e **€1.169,07**, conforme minutas), e assume rendas pagas até **abril/2026** (crédito potencial do inquilino se sair em fevereiro).
- **Comunicações e forma**
  - Relevância de **comunicação formal** (ex.: carta registada c/ AR) e enquadramento legal do distrate/cessação (referências ao Código Civil / NRAU nas auditorias).

---

## Lacunas (Consolidado)
- **Falta do “Anexo II – Mapa de Acerto Final”** apesar de ser referido repetidamente em cláusulas do distrate (lacuna **alta**: sem ele, o mecanismo de contas fica menos executável e mais discutível).
- **Comprovativos/documentação das atualizações de renda** (de €1.100 para €1.143,45 e €1.169,07):
  - Ausência de prova clara (cartas de atualização, recibos, extratos, aceitação do inquilino) pode abrir espaço a contestação.
- **Apuramento e prova de consumos finais** insuficientemente detalhados:
  - Falta clarificar **como** se apuram (leituras, faturas, prazos, quem envia o quê) e **como** se comprovam valores cobrados após a entrega.
- **Prazos operacionais incompletos/ambíguos**:
  - Necessidade de um prazo claro para **apresentação de faturas** que cheguem depois da entrega e para **pagamento/devolução de saldos**.
  - Sugestão adicional de **prazo de validade da proposta** (a carta/proposta caducar se não for aceite até data X).
- **Reconhecimento de assinaturas não previsto**:
  - Sem reconhecimento, aumenta o risco de litígio sobre autoria/validade de assinatura e reduz força prática na cobrança.
- **Cláusulas de reforço em falta** (para reduzir risco):
  - **Solidariedade expressa** entre arrendatários (ainda que possa estar implícita).
  - **Mora/juros/cláusula penal** para incumprimento do pagamento do saldo final.
  - **Declaração de capacidade e vontade livre** (mitiga alegações de vício de consentimento).
- **Dados para devolução/pagamento (operacional)**:
  - Falta indicação de **IBAN do inquilino** (ou forma inequívoca) para eventual devolução de saldo (se aplicável).

---

## Inconsistências (Consolidado)
- **Prazo de devolução da caução: 60 dias vs 90 dias**
  - Contrato original: **60 dias** (Auditoria 2).
  - Uma minuta de distrate: **90 dias** (Auditoria 2).
  - Risco: pode ser contestado se parecer alteração não claramente aceite/negociada.
- **Duplicação e coexistência de versões de documentos**
  - Existem ficheiros com nomes semelhantes e **uma versão “mais simples”** (“contrato distrate” sem .docx) **menos protetora** (sem certas cláusulas/anexos).
  - Risco: assinar a versão errada ou gerar conflito de interpretação.
- **Erro tipográfico na carta**
  - Expressão “**hookupada**” (deveria ser “convencionada” ou similar) — fragiliza formalmente o documento.
- **Compensação por vacância vs. renda / base de cálculo**
  - Sinalização de risco quando a compensação (ou o valor de referência) pode parecer **superior**/desalinhada face à renda contratual inicial, **se** não houver aceitação expressa e prova do valor atualizado e da lógica de cálculo.
- **Aplicação prática da regra anti-duplicação**
  - Embora prevista, pode ficar **complexa** sem um mecanismo claro no Mapa de Acerto Final (Anexo II) que mostre a fórmula/contabilização.

---

## Elementos Adicionais (Consolidado)
- **Criar e anexar o Anexo II (Mapa de Acerto Final)** (prioridade máxima):
  - Tabela com: créditos do senhorio (vacância, consumos, danos), créditos do inquilino (rendas pagas a mais, caução), saldo final, forma/prazo de pagamento, assinaturas.
- **Anexar prova das atualizações de renda**:
  - Comunicações de atualização, recibos, ou extratos que mostrem pagamentos pelos valores (€1.143,45 / €1.169,07), idealmente com referência ao período.
- **Uniformizar o prazo de devolução da caução**
  - Ou manter **60 dias** (coerente com o contrato), ou justificar e obter aceitação expressa e inequívoca do novo prazo (se se mantiver 90).
- **Reforçar a execução e segurança probatória**
  - **Reconhecimento presencial de assinaturas** (notário/advogado/solicitador) e rubrica em todas as páginas/anexos.
- **Aprimorar o regime de consumos e prazos**
  - Definir: data de leitura, quem recolhe, prazo máximo para apresentação de faturas pós-entrega, e prazo para pagamento/compensação.
- **Adicionar cláusulas de mitigação de litígio**
  - **Solidariedade expressa** dos arrendatários.
  - **Mora e juros** (taxa legal + spread) e/ou cláusula penal para atraso no pagamento do saldo.
  - Declaração de **capacidade e ausência de vícios de consentimento**.
- **Operacionalizar pagamentos/devoluções**
  - Incluir **IBAN do inquilino** (para devoluções) e do senhorio (para pagamentos), e regras de “considera-se pago na data de boa cobrança”.
- **Higiene documental**
  - Eliminar versões redundantes; **usar apenas a minuta mais completa**.
  - Corrigir o erro “hookupada” antes de enviar/assinar.
- **Validade da proposta**
  - Na carta: introduzir cláusula “válida até DD/MM/AAAA; caduca se não for aceite por escrito até essa data”.
- **Revisão jurídica final**
  - Recomendada validação por advogado especializado (sobretudo por causa de valores, prazos, anexos e exequibilidade).

SÍNTESE CONSOLIDADA: os anexos **melhoram substancialmente** a proteção (vistoria/auto, encontro de contas, teto de vacância, anti-duplicação, quitação com reservas), mas **não dão “100%”** enquanto faltar o **Anexo II**, prova das **atualizações de renda**, harmonização do **prazo da caução**, e reforços de **assinaturas/exequibilidade**, prazos de **consumos** e higiene de **versões**.