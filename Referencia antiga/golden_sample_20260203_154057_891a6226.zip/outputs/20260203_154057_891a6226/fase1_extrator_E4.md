# Extrator E4: Extrator Completo
## Modelo: anthropic/claude-3-5-sonnet
## Chunks processados: 1

## FACTOS RELEVANTES

1. Trata-se de um contrato de arrendamento para fins habitacionais com prazo certo
2. O imóvel arrendado é a Fração Autónoma 2D, correspondente ao 2º DTO, Nº 137 do prédio na Rua Tomas da Anunciação, Lisboa
3. O contrato tem prazo inicial de 3 anos, com início em 15/01/2023 e término em 31/12/2025
4. Renova-se automaticamente por períodos iguais de 3 anos
5. A renda mensal estabelecida é de €1.100,00
6. Foi entregue caução de €1.100,00
7. No ato da assinatura foi pago €4.950,00 referente a 15 dias de janeiro/2023 e aos meses de fevereiro a maio/2023
8. O imóvel destina-se exclusivamente à habitação permanente dos arrendatários
9. Constitui casa de morada de família
10. É proibido sublocação, hospedagem, alojamento local ou cedência de uso

## CRONOLOGIA

- 15/01/2023: Início do contrato
- 01/03/2023: Data para pagamento do mês de junho/2023
- 31/12/2025: Término do contrato inicial

## PARTES E IDENTIFICAÇÃO

SENHORIO:
- Nome: Henrique Miguel Moura de Sena
- NIF: 269805672
- CC: 13965402 0ZY9 (válido até 03/08/2031)
- Morada: Avenida 25 de Abril, Nº 93 1º DTO A, Cascais

ARRENDATÁRIOS:
1. Nome: Gonçalo Filipe Côrte Joaquim Marques dos Santos
- NIF: 221544470
- CC: 12958206 9 ZV0 (válido até 13/08/2029)
- Estado civil: Casado em regime da comunhão de adquiridos

2. Nome: Filipa Gomes Joaquim Marques dos Santos
- NIF: 223841366
- CC: 12826409 8 ZW4 (válido até 13/08/2029)
- Estado civil: Casada em regime da comunhão de adquiridos

## VALORES MONETÁRIOS

1. Renda mensal: €1.100,00
2. Caução: €1.100,00
3. Pagamento inicial: €4.950,00
4. Indemnização por atraso: 20% das rendas em dívida

## REFERÊNCIAS LEGAIS

1. Artigo 1095º, nº 1, do Código Civil
2. Artigo 1097º, nº 1, alínea b) do Código Civil
3. Artigo 1098º, nº 3, alínea a) do Código Civil
4. Artigo 1077º, nº 2, do Código Civil
5. Regulamento (UE) 2016/679
6. Lei nº 58/2019 de 8 de agosto

## DADOS TÉCNICOS

- Fração: 2D, 2º DTO, Nº 137
- Matriz Predial: Artigo Nº 661
- Certificado Energético: SCE235939031
- IBAN: PT50 0036 0026 9910 0089 3877 1 (Montepio)

## OUTROS ELEMENTOS

1. Jurisdição: Tribunal judicial da comarca de Cascais
2. Proteção de dados: Cláusula Nona detalha obrigações RGPD
3. Inventário e foto reportagem do estado do imóvel anexos ao contrato