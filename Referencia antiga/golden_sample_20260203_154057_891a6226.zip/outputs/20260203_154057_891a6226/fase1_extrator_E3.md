# Extrator E3: Extrator Completo
## Modelo: openai/gpt-4o
## Chunks processados: 1

## FACTOS RELEVANTES
1. Henrique Miguel Moura de Sena é o senhorio e proprietário da Fração Autónoma 2D, correspondente ao 2º DTO, Nº 137 do prédio urbano na Rua Tomas da Anunciação, Lisboa.
2. Gonçalo Filipe Côrte Joaquim Marques dos Santos e Filipa Gomes Joaquim Marques dos Santos são os arrendatários.
3. O contrato de arrendamento é para fins habitacionais com prazo certo de 3 anos, iniciando em 15 de janeiro de 2023 e terminando em 31 de dezembro de 2025.
4. A renda mensal é de €1.100,00.
5. Os arrendatários pagaram uma caução de €1.100,00.
6. Os arrendatários entregaram €4.950,00 no ato da assinatura do contrato.
7. O apartamento destina-se exclusivamente à habitação permanente dos arrendatários.
8. Os arrendatários são responsáveis por todas as despesas de consumo e manutenção do imóvel.
9. O senhorio tem o direito de mostrar o imóvel nos dois meses anteriores ao término do contrato.
10. O contrato é regulado pela Lei Portuguesa e qualquer litígio será resolvido no tribunal judicial da comarca de Cascais.

## CRONOLOGIA
1. Início do contrato: 15 de janeiro de 2023.
2. Término do contrato: 31 de dezembro de 2025.
3. Validade do cartão de cidadão de Henrique Miguel Moura de Sena: até 03/08/2031.
4. Validade do cartão de cidadão de Gonçalo Filipe Côrte Joaquim Marques dos Santos e Filipa Gomes Joaquim Marques dos Santos: até 13/08/2029.

## PARTES E IDENTIFICAÇÃO
- **Senhorio:** Henrique Miguel Moura de Sena
  - NIF: 269805672
  - Morada: Avenida 25 de Abril, Nº 93 1º DTO A, Cascais
  - Cartão de cidadão: 13965402 0ZY9
- **Arrendatários:** 
  - Gonçalo Filipe Côrte Joaquim Marques dos Santos
    - NIF: 221544470
    - Cartão de cidadão: 12958206 9 ZV0
  - Filipa Gomes Joaquim Marques dos Santos
    - NIF: 223841366
    - Cartão de cidadão: 12826409 8 ZW4

## VALORES MONETÁRIOS
1. Renda mensal: €1.100,00
2. Caução: €1.100,00
3. Pagamento inicial: €4.950,00
4. Indemnização por falta de pagamento: 20% das rendas em dívida

## REFERÊNCIAS LEGAIS
1. Artigo 1095°, n° 1, do Código Civil
2. Alínea b) do número 1 do artigo 1097.° do Código Civil
3. Alínea a) do número 3 do artigo 1098.° do Código Civil
4. Artigo 1077°, n°2, do Código Civil
5. Regulamento (UE) 2016/679 do Parlamento Europeu e do Conselho de 27 de abril de 2016
6. Lei n.° 58/2019 de 8 de agosto

## PEDIDOS E PRETENSÕES
1. Os arrendatários devem pagar a renda mensalmente e manter o imóvel em bom estado.
2. O senhorio pode impedir a renovação automática do contrato com aviso prévio de 120 dias.
3. Os arrendatários podem impedir a renovação automática com aviso prévio de 90 dias.

## DOCUMENTOS REFERENCIADOS
1. Certificado de Desempenho Energético e da Qualidade do Ar Interior com o N° SCE235939031.
2. Lista de inventário e foto reportagem do estado do imóvel anexada ao contrato.

## DADOS TÉCNICOS E PARECERES
1. O imóvel é descrito na Conservatória do Registo Predial de Lisboa, inscrito na Matriz sob o Artigo N° 661.

## OUTROS ELEMENTOS
1. O contrato é feito em quadruplicado, destinando-se um a cada parte e um à Autoridade Tributária.
2. O senhorio é responsável pelas despesas das partes comuns do prédio.