# Extrator E2: Extrator Completo
## Modelo: google/gemini-3-flash-preview
## Chunks processados: 1

Com base no documento fornecido, segue a extração integral, exaustiva e **verbatim** de todos os elementos contidos no contrato de arrendamento:

## FACTOS RELEVANTES
1. Celebração de contrato de arrendamento para fins habitacionais com prazo certo.
2. O Senhorio é proprietário e legítimo possuidor da Fração Autónoma 2D (2º DTO, Nº 137) em Campo de Ourique.
3. O imóvel destina-se exclusivamente à habitação permanente dos Arrendatários e constitui casa de morada de família.
4. É proibido o comodato, sublocação, hospedagem, alojamento local ou qualquer outra forma de cedência de uso.
5. É proibido o exercício de qualquer atividade profissional ou indústria doméstica no imóvel.
6. Os Arrendatários não podem realizar obras ou benfeitorias sem autorização prévia e escrita (exceto reparações urgentes).
7. Obras autorizadas ficam a fazer parte do imóvel sem direito a indemnização ou retenção.
8. É proibido fazer furos em azulejos (cozinha/WC), tetos e caixilhos de janelas.
9. Os Arrendatários devem celebrar contratos de serviços (água, luz, gás, etc.) em seu próprio nome.
10. O Senhorio tem o direito de mostrar o imóvel nos dois meses anteriores ao término do contrato.
11. Foi realizada vistoria, inventário e foto reportagem do estado do imóvel.
12. O contrato foi feito em quadruplicado.

## CRONOLOGIA
*   **03/08/2031**: Data de validade do Cartão de Cidadão do Senhorio.
*   **13/08/2029**: Data de validade do Cartão de Cidadão de ambos os Arrendatários.
*   **15/01/2023**: Data de início do contrato e data da assinatura em Lisboa.
*   **31/12/2025**: Data de termo do prazo inicial do contrato.
*   **01/03/2023**: Data em que será pago o mês de junho de 2023 (e sucessivamente).
*   **Prazos de Comunicação**:
    *   **120 dias**: Antecedência mínima para o Senhorio impedir a renovação.
    *   **90 dias**: Antecedência mínima para os Arrendatários impedirem a renovação.
    *   **90 dias**: Antecedência para denúncia pelos Arrendatários (após decorrido 1/3 do prazo).
    *   **30 dias**: Antecedência mínima para comunicação de atualização de renda.
    *   **60 dias**: Prazo máximo para devolução da caução após o termo.
    *   **2 meses**: Período anterior ao término para visitas ao imóvel.

## PARTES E IDENTIFICAÇÃO
*   **Senhorio (Primeiro)**:
    *   Nome: Henrique Miguel Moura de Sena.
    *   NIF: 269805672.
    *   Estado Civil: Solteiro, maior.
    *   CC: 13965402 0ZY9.
    *   Morada: Avenida 25 de Abril, Nº 93 1º DTO A, Cascais.
*   **Arrendatários (Segundos)**:
    *   Nome: Gonçalo Filipe Côrte Joaquim Marques dos Santos.
    *   NIF: 221544470.
    *   Estado Civil: Casado em regime da comunhão de adquiridos, maior.
    *   CC: 12958206 9 ZV0.
    *   Nome: Filipa Gomes Joaquim Marques dos Santos.
    *   NIF: 223841366.
    *   Estado Civil: Casada em regime da comunhão de adquiridos, maior.
    *   CC: 12826409 8 ZW4.

## VALORES MONETÁRIOS
*   **€: 1.100,00 (Mil e cem euros)**: Valor da renda mensal.
*   **€: 4.950,00 (Quatro mil novecentos e cinquenta euros)**: Valor entregue no ato da assinatura (referente a 15 dias de janeiro + meses de fevereiro, março, abril e maio de 2023).
*   **€: 1.100,00 (Mil e cem euros)**: Valor da caução entregue.
*   **20 %**: Indemnização sobre rendas em dívida em caso de falta de pagamento pontual.
*   **Dobro do valor da renda**: Indemnização em caso de mora na restituição do imóvel após término.

## REFERÊNCIAS LEGAIS
*   **Artigo 1095°, n° 1, do Código Civil**: Celebração de contrato com prazo certo.
*   **Artigo 1097.°, número 1, alínea b) do Código Civil**: Oposição à renovação pelo senhorio.
*   **Artigo 1098.°, número 3, alínea a) do Código Civil**: Denúncia do contrato pelos arrendatários.
*   **Artigo 1077°, n° 2, do Código Civil**: Atualização anual da renda.
*   **Regulamento (UE) 2016/679 (RGPD)**: Proteção de dados pessoais.
*   **Lei n.° 58/2019 de 8 de agosto**: Proteção de dados pessoais.
*   **Lei Portuguesa**: Regulação do contrato.
*   **Comarca de Cascais**: Foro convencionado para litígios.

## PEDIDOS E PRETENSÕES
*   **Senhorio**: Pretende o pagamento pontual da renda, a conservação do imóvel e a desocupação findo o prazo.
*   **Arrendatários**: Pretendem o uso habitacional do imóvel e a devolução da caução no final, caso não haja danos.
*   **Cláusula de Domiciliação**: As partes convencionam os endereços do cabeçalho para efeitos de citação e notificações postais.

## DOCUMENTOS REFERENCIADOS
*   **Certificado de Desempenho Energético e da Qualidade do Ar Interior**: Nº SCE235939031.
*   **Caderneta Predial/Matriz**: Artigo Nº 661 (Freguesia de Campo de Ourique).
*   **IBAN para pagamento**: PT50 0036 0026 9910 0089 3877 1 (Caixa Económica Montepio Geral).
*   **Anexo**: Lista de inventário e foto reportagem do estado do imóvel.

## DADOS TÉCNICOS E PARECERES
*   **Identificação do Imóvel**: Fração Autónoma 2D, correspondente ao 2º DTO, Nº 137, Rua Tomas da Anunciação, Campo de Ourique, Lisboa (CP: 1350-325).
*   **Conservatória**: Descrito na Conservatória do Registo Predial de Lisboa.
*   **Prazo**: 3 anos, renovável por iguais períodos.

## OUTROS ELEMENTOS
*   **Responsabilidade por Danos**: Arrendatários respondem por danos causados por animais domésticos (incluindo desinfestação).
*   **Manutenção**: A cargo dos arrendatários (água, luz, esgotos, pavimentos, sanitários, pinturas, vidros, estores), exceto deterioração normal.
*   **Tratamento de Dados**: O Senhorio é o "Responsável pelo Tratamento" e os Arrendatários são os "Titulares dos Dados".
*   **Assinaturas**: O documento contém as assinaturas de Henrique Miguel Moura de Sena, Gonçalo Filipe Côrte Joaquim Marques dos Santos e Filipa Gomes Joaquim Marques dos Santos.