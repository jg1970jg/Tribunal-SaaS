# EXTRAÇÃO CONSOLIDADA (AGREGADOR: openai/gpt-5.2)

## 1. RESUMO ESTRUTURADO

### Factos Relevantes
- [E1,E2,E3,E4,E5] Contrato de arrendamento para fins habitacionais com prazo certo
- [E1,E2,E3,E4,E5] Imóvel: Fração Autónoma 2D (2º DTO), Nº 137, Rua Tomas da Anunciação, Lisboa
- [E1,E2,E3,E4,E5] Destino: habitação permanente; casa de morada de família
- [E1,E2,E3,E4,E5] Prazo inicial 3 anos; renovação automática por iguais períodos de 3 anos
- [E1,E2] Proibido comodato/sublocação/hospedagem/alojamento local/cedência de uso
- [E1,E2] Proibida atividade profissional ou indústria doméstica no imóvel
- [E1,E2] Obras/benfeitorias só com autorização escrita (exceto reparações urgentes)
- [E1,E2] Benfeitorias (mesmo autorizadas) integram o imóvel sem direito a indemnização/retenção
- [E1,E2] Proibido fazer furos (azulejos cozinha/WC, teto e caixilhos das janelas)
- [E1,E2,E3,E5] Arrendatários suportam consumos e encargos (água, luz, gás, telecom, etc.)
- [E1,E2] Arrendatários celebram em nome próprio contratos de fornecimento
- [E1,E2,E3,E4,E5] Senhorio pode mostrar o imóvel nos 2 meses anteriores ao termo (com aviso prévio)
- [E1,E2] Vistoria realizada; inventário e foto-reportagem anexos ao contrato
- [E1,E2,E3] Contrato em quadruplicado; um exemplar para a Autoridade Tributária
- [E1,E2,E3,E5] Foro/litígio: tribunal judicial da comarca de Cascais; renúncia a outro
- [E1] Pagamento por transferência/depósito; recibos enviados após pagamento
- [E1,E2,E4] Pagamento para IBAN PT50 0036 0026 9910 0089 3877 1 (Montepio)
- [E1] Banco: Caixa Económica Montepio Geral
- [E1,E2] Senhorio = Responsável pelo Tratamento; Arrendatários = Titulares dos Dados (RGPD/L58/2019)
- [E1] RGPD: obrigações detalhadas (minimização, segurança, subcontratantes, direitos, etc.)
- [E1,E5] Espaços comuns: Arrendatários mantêm livres; despesas de partes comuns por conta do Senhorio
- [E1,E2] Animais: Arrendatários indemnizam danos (inclui possível desinfestação)
- [E1] Comunicações/citações: domicílio convencionado nos endereços do cabeçalho

### Datas e Prazos
- [E1,E2,E3,E4,E5] 15/01/2023 - Início do contrato e assinatura (Lisboa)
- [E1,E2,E3,E4,E5] 31/12/2025 - Termo do prazo inicial
- [E1,E2,E4] 01/03/2023 - Paga-se o mês de junho/2023 (e sucessivamente)
- [E1] 1º dia útil de cada mês - Data de pagamento da renda (transferência/depósito)
- [E1,E2,E3,E4,E5] 120 dias - Antecedência do Senhorio para impedir renovação
- [E1,E2,E3,E5] 90 dias - Antecedência dos Arrendatários para impedir renovação
- [E1,E2,E3,E5] 1/3 do prazo - Após isto, Arrendatários podem denunciar
- [E1,E2,E3,E5] 90 dias - Aviso prévio de denúncia pelos Arrendatários (após 1/3)
- [E1,E2] 30 dias - Antecedência para comunicação de atualização de renda
- [E1,E2] 60 dias - Prazo máximo para devolução da caução após termo
- [E1,E2,E3,E5] 2 meses antes do termo - Período para mostrar o imóvel
- [E1,E2,E3,E4,E5] 03/08/2031 - Validade CC do Senhorio
- [E1,E2,E3,E4,E5] 13/08/2029 - Validade CC dos Arrendatários
- [E1,E2,E3,E4,E5] 27/04/2016 - Data do Regulamento (UE) 2016/679 (RGPD)
- [E1,E2,E3,E4,E5] 08/08/2019 - Data da Lei n.º 58/2019

### Partes Envolvidas
- [E1,E2,E3,E4,E5] Henrique Miguel Moura de Sena (NIF 269805672) - Senhorio/1º outorgante
- [E1,E2,E3,E4,E5] Gonçalo F. C. J. M. dos Santos (NIF 221544470) - Arrendatário/2º outorgante
- [E1,E2,E3,E4,E5] Filipa Gomes J. M. dos Santos (NIF 223841366) - Arrendatária/2ª outorgante
- [E1,E2,E3,E4,E5] Morada do Senhorio: Av. 25 de Abril, Nº 93, 1º DTO A, Cascais
- [E1,E2] Senhorio: solteiro
- [E1,E2,E4,E5] Arrendatários: casados em comunhão de adquiridos
- [E1,E2,E3,E4,E5] CC Senhorio: 13965402 0ZY9
- [E1,E2,E3,E4,E5] CC Gonçalo: 12958206 9 ZV0
- [E1,E2,E3,E4,E5] CC Filipa: 12826409 8 ZW4
- [E1,E2] Entidade emissora CC: República Portuguesa
- [E2] Senhorio e Arrendatários identificados como “maior(es)”

### Valores Monetários
- [E1,E2,E3,E4,E5] €1.100,00 - Renda mensal
- [E1,E2,E3,E4,E5] €4.950,00 - Quantia entregue na assinatura (15 dias jan + fev-mai 2023)
- [E1,E2,E3,E4,E5] €1.100,00 - Caução
- [E1,E2,E3,E4] 20% - Indemnização por mora/falta de pagamento pontual (sobre rendas em dívida)
- [E1,E2] Dobro da renda - Indemnização por não restituição; agravada em mora
- [E1,E5] Atualizações legais anuais - Renda dos anos subsequentes (coeficiente publicado anualmente)

### Referências Legais
- [E1,E2,E3,E4,E5] Art. 1095.º, n.º 1, Código Civil
- [E1,E2,E3,E4] Art. 1097.º, n.º 1, al. b), Código Civil
- [E1,E2,E3,E4,E5] Art. 1098.º, n.º 3, al. a), Código Civil
- [E1,E2,E3,E4,E5] Art. 1077.º, n.º 2, Código Civil
- [E1,E2,E3,E4,E5] Regulamento (UE) 2016/679, de 27/04/2016 (RGPD)
- [E1,E2,E3,E4,E5] Lei n.º 58/2019, de 08/08/2019
- [E1,E2,E3,E5] Lei Portuguesa - Regência do contrato

### Pedidos/Pretensões
- [E1,E2,E3,E5] Pagamento pontual da renda nos termos contratados
- [E1,E2,E3,E5] Oposição à renovação: Senhorio (120 dias) / Arrendatários (90 dias)
- [E1,E2,E3,E5] Denúncia pelos Arrendatários após 1/3 do prazo com 90 dias
- [E1,E2] Devolução da caução até 60 dias após termo (se aplicável)
- [E1,E2,E3,E5] Entrega do imóvel no termo; penalização por não restituição (dobro da renda em mora)
- [E1,E2] Domiciliação para comunicações/citação: endereços do cabeçalho

### Documentos Mencionados
- [E1,E2,E3,E4,E5] Certificado Energético SCE235939031
- [E1,E2,E3,E5] Lista de inventário (anexo)
- [E1,E2,E3,E5] Foto-reportagem do estado do imóvel (anexo)
- [E1,E2,E3,E4] IBAN de pagamento: PT50 0036 0026 9910 0089 3877 1
- [E1,E2,E3,E4,E5] Matriz/Artigo matricial: Nº 661
- [E1] Registo/Conservatória: Conservatória do Registo Predial de Lisboa
- [E1,E2,E3] Exemplares do contrato: quadruplicado (inclui exemplar para AT)

---

## 2. DIVERGÊNCIAS ENTRE EXTRATORES
- Facto: Art. 1097.º (oposição à renovação pelo senhorio)
  - E1: “alínea b) do número 1 do artigo 1097.º”
  - E2: “Artigo 1097.º, número 1, alínea b)”
  - E3: “alínea b) do número 1 do artigo 1097.º”
  - E4: “Artigo 1097º, nº 1, alínea b)”
  - E5: “Artigo 1097.º, alínea b)” (sem indicar “n.º 1”)

---

## 3. CONTROLO DE COBERTURA (OBRIGATÓRIO)

**[E1] encontrou exclusivamente:**
- banco “Caixa Económica Montepio Geral” → incorporado em: ##1/Factos, linha 16
- RGPD: obrigações detalhadas (a-i) → incorporado em: ##1/Factos, linha 18
- pagamento no 1º dia útil de cada mês → incorporado em: ##1/Datas e Prazos, linha 5
- recibos enviados após pagamento → incorporado em: ##1/Factos, linha 15
- entidade emissora CC “República Portuguesa” → incorporado em: ##1/Partes Envolvidas, linha 12

**[E2] encontrou exclusivamente:**
- “maior” na identificação das partes → incorporado em: ##1/Partes Envolvidas, linha 13

**[E3] encontrou exclusivamente:**
- (nenhum — todos os factos foram partilhados)

**Confirmação:** SIM

**ITENS NÃO INCORPORADOS**:
- (nenhum)