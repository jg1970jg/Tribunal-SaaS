# Extrator E1: Extrator Completo
## Modelo: anthropic/claude-opus-4.5
## Chunks processados: 1

# EXTRAÇÃO COMPLETA DO DOCUMENTO

## IDENTIFICAÇÃO DO DOCUMENTO

**Tipo:** Contrato de Arrendamento para Fins Habitacionais com Prazo Certo
**Ficheiro:** pdf pesquisavel contrato arrendamento goncalo santos.pdf
**Área do Direito:** Civil
**Total de páginas:** 5

---

## PARTES E IDENTIFICAÇÃO

### SENHORIO (PRIMEIRO OUTORGANTE)

| Campo | Informação |
|-------|------------|
| **Nome completo** | HENRIQUE MIGUEL MOURA DE SENA |
| **NIF** | 269805672 |
| **Estado civil** | Solteiro |
| **Cartão de Cidadão n°** | 13965402 0ZY9 |
| **Validade CC** | 03/08/2031 |
| **Entidade emissora** | República Portuguesa |
| **Morada** | Avenida 25 de Abril, N° 93 1o DTO A em Cascais |

### ARRENDATÁRIOS (SEGUNDOS OUTORGANTES)

#### Arrendatário 1:

| Campo | Informação |
|-------|------------|
| **Nome completo** | GONÇALO FILIPE CÔRTE JOAQUIM MARQUES DOS SANTOS |
| **NIF** | 221544470 |
| **Estado civil** | Casado em regime da comunhão de adquiridos |
| **Cartão de Cidadão n°** | 12958206 9 ZV0 |
| **Validade CC** | 13/08/2029 |
| **Entidade emissora** | República Portuguesa |

#### Arrendatário 2:

| Campo | Informação |
|-------|------------|
| **Nome completo** | FILIPA GOMES JOAQUIM MARQUES DOS SANTOS |
| **NIF** | 223841366 |
| **Estado civil** | Casada em regime da comunhão de adquiridos |
| **Cartão de Cidadão n°** | 12826409 8 ZW4 |
| **Validade CC** | 13/08/2029 |
| **Entidade emissora** | República Portuguesa |

---

## OBJETO DO CONTRATO - IMÓVEL

| Campo | Informação |
|-------|------------|
| **Descrição** | Fração Autónoma 2D |
| **Correspondente a** | 2o DTO, N° 137 |
| **Tipo de prédio** | Prédio urbano |
| **Localização** | Rua Tomas da Anunciação |
| **Freguesia** | Campo de Ourique |
| **Concelho** | Lisboa |
| **Código postal** | 1350-325 LISBOA |
| **Conservatória** | Conservatória do Registo Predial de Lisboa |
| **Artigo Matricial** | N° 661 |
| **Certificado Energético** | SCE235939031 |

---

## CRONOLOGIA E DATAS

| Data | Evento/Descrição |
|------|------------------|
| **15 de janeiro de 2023** | Início do contrato |
| **15 de janeiro de 2023** | Data de assinatura do contrato |
| **31 de dezembro de 2025** | Termo do prazo inicial do contrato |
| **01 de março de 2023** | Data de pagamento do mês de junho de 2023 |
| **03/08/2031** | Validade do CC do Senhorio |
| **13/08/2029** | Validade do CC dos Arrendatários |

---

## VALORES MONETÁRIOS

| Descrição | Valor |
|-----------|-------|
| **Renda mensal** | €: 1.100,00 (Mil e cem euros) |
| **Quantia entregue na assinatura** | €: 4.950,00 (Quatro mil novecentos e cinquenta euros) |
| **Caução** | €: 1.100,00 (Mil e cem euros) |
| **Indemnização por mora no pagamento** | 20 % das rendas em dívida |
| **Indemnização por não restituição (mora)** | Dobro do valor da renda |

### Decomposição da quantia de €4.950,00:
- 15 dias do mês de janeiro de 2023
- Mês de fevereiro de 2023
- Mês de março de 2023
- Mês de abril de 2023
- Mês de maio de 2023

---

## PRAZOS CONTRATUAIS E LEGAIS

| Prazo | Descrição |
|-------|-----------|
| **3 (três) anos** | Prazo certo do contrato |
| **3 (três) anos** | Período de renovação automática |
| **120 (cento e vinte) dias** | Antecedência mínima para o Senhorio impedir renovação automática |
| **90 (noventa) dias** | Antecedência mínima para os Arrendatários impedirem renovação automática |
| **90 (noventa) dias** | Antecedência mínima para denúncia pelos Arrendatários após 1/3 do prazo |
| **Um terço do prazo inicial** | Período após o qual os Arrendatários podem denunciar |
| **30 (trinta) dias** | Antecedência mínima para comunicação de atualização de renda |
| **60 (Sessenta) dias** | Prazo máximo para devolução da caução após termo do arrendamento |
| **Dois meses** | Período anterior ao término para mostrar o imóvel |

---

## REFERÊNCIAS LEGAIS

| Diploma/Artigo | Contexto |
|----------------|----------|
| **Artigo 1095°, n° 1, do Código Civil** | Celebração do contrato com prazo certo |
| **Alínea b) do número 1 do artigo 1097.° do Código Civil** | Impedimento de renovação automática pelo Senhorio |
| **Alínea a) do número 3 do artigo 1098.° do Código Civil** | Denúncia do contrato pelos Arrendatários |
| **Artigo 1077°, n°2, do Código Civil** | Atualizações legais anuais da renda |
| **Regulamento (UE) 2016/679 do Parlamento Europeu e do Conselho de 27 de abril de 2016** | Proteção de dados pessoais (RGPD) |
| **Lei n.° 58/2019 de 8 de agosto** | Lei de proteção de dados pessoais portuguesa |

---

## DADOS BANCÁRIOS

| Campo | Informação |
|-------|------------|
| **IBAN** | PT50 0036 0026 9910 0089 3877 1 |
| **Banco** | CAIXA ECONÓMICA MONTEPIO GERAL |
| **Forma de pagamento** | Transferência ou depósito bancário |
| **Data de pagamento** | Primeiro dia útil de cada mês |

---

## CLÁUSULAS CONTRATUAIS - CONTEÚDO VERBATIM

### CLÁUSULA PRIMEIRA (Objeto)

1- O Senhorio é proprietário e legítimo possuidor da Fração Autónoma 2D, correspondente ao 2o DTO, N° 137 do prédio urbano sito na Rua Tomas da Anunciação, freguesia de Campo de Ourique, concelho de Lisboa, código postal: 1350-325 LISBOA, descrito na Conservatória do Registo Predial de Lisboa, inscrito na Matriz sob o Artigo N° 661, Certificado de Desempenho Energético e da Qualidade do Ar Interior com o N° SCE235939031, sob os termos e cláusulas seguintes:

### CLÁUSULA SEGUNDA (Prazo e Renda)

1- O presente contrato é celebrado pelo prazo certo de 3 (três) anos, com início em 15 de janeiro de 2023 e termo em 31 de dezembro de 2025, renovando-se automaticamente por iguais períodos de 3 (três) anos, desde que não ocorra denúncia por qualquer das partes nos termos das cláusulas seguintes, sendo o mesmo celebrado nos termos e com efeitos previstos no artigo 1095°, n° 1, do Código Civil.

2- O Senhorio pode impedir a renovação automática do contrato mediante comunicação aos Arrendatários, com a antecedência mínima de 120 (cento e vinte) dias sem relação ao termo do prazo de duração inicial do contrato ou da sua renovação, conforme previsto na alínea b) do númerol do artigo 1097.° do Código Civil.

3- Os Arrendatários podem impedir a renovação automática do contrato mediante comunicação ao Senhorio, com a antecedência mínima de 90 (noventa) dias.

4- Decorrido um terço do prazo inicial do contrato ou da sua renovação, os Arrendatários podem denunciá-lo a todo o tempo, mediante comunicação ao Senhorio, expedida com a antecedência mínima de 90 (noventa) dias do termo pretendido do contrato, conforme previsto na alínea a) do número 3 do artigo 1098.° do Código Civil.

5- A renda mensal a pagar pelos Arrendatários ao Senhorio é de €: 1.100,00 (Mil e cem euros).

6- A renda dos anos subsequentes fica sujeita às atualizações legais anuais, nos termos do artigo 1077°, n°2, do Código Civil, mediante comunicação escrita do Senhorio aos Arrendatários, com a antecedência mínima de 30 (trinta) dias, onde conste o valor da nova renda de acordo com o coeficiente de atualização publicado anualmente.

### CLÁUSULA TERCEIRA (Pagamentos e Caução)

1- Os pagamentos seguintes serão feitos por transferência ou depósito bancário no primeiro dia útil ao Senhorio, através de depósito ou transferência para a conta bancária com o IBAN PT50 0036 0026 9910 0089 3877 1 CAIXA ECONÓMICA MONTEPIO GERAL, sendo que a 01 de março de 2023 pagará o mês de junho de 2023, e assim sucessivamente, após o que serão enviados os respetivos recibos.

2- Na falta, total e/ou parcial, do pagamento pontual da renda prevista na cláusula segunda, o Senhorio poderá exigir aos Arrendatários, além das rendas em atraso, uma indemnização igual a 20 % das rendas em dívida.

3- No ato da assinatura do presente contrato, os Arrendatários entregam ao Senhorio a quantia de €: 4.950,00 (Quatro mil novecentos e cinquenta euros), correspondentes a 15 dias do mês de janeiro de 2023 e aos meses de fevereiro, março, abril e maio de 2023, servindo o presente contrato de suficiente documento de quitação.

4- Os Arrendatários, já entregaram ao Senhorio a quantia de €: 1.100,00 (Mil e cem euros), a título de caução, para garantia do bom cumprimento do contrato, a qual se destina a provisionar a boa e pontual regularização das últimas despesas e eventuais prejuízos imputáveis aos Arrendatários, durante a vigência do presente contrato, importância que será devolvida por inteiro ou o seu remanescente, no prazo máximo de 60 (Sessenta) dias, após o termo do arrendamento.

### CLÁUSULA QUARTA (Uso e Obras)

1- O apartamento arrendado destina-se exclusivamente à habitação permanente dos Arrendatários, e constitui casa de morada de família, não sendo permitido o comodato, sublocação, hospedagem, alojamento local ou qualquer outra forma de cedência de uso, nem o exercício de qualquer atividade profissional ou indústria doméstica.

2- Os Arrendatários não podem sublocar ou ceder, no todo ou em parte, onerosa ou gratuitamente, o local arrendado, sem consentimento expresso e autorização escrita do Senhorio.

3- Os Arrendatários devem fazer um uso prudente do arrendado, sendo a seu cargo todas as obras de beneficiação e as de manutenção do bom estado de funcionamento das instalações de água, eletricidade, esgotos ou saneamento, pavimentos, equipamentos, sanitários, pinturas, vidros, estores do imóvel, que sirvam o arrendado, com exclusão das deteriorações resultantes de uma normal e prudente utilização.

4- Os Arrendatários só podem efetuar obras ou benfeitorias na habitação arrendada com autorização prévia e escrita do Senhorio, com exceção de reparações urgentes.

5- Todas e quaisquer obras e benfeitorias efetuadas pelos Arrendatários na habitação arrendada referente na Cláusula Primeira, mesmo que tenham sido autorizadas pelo Senhorio ficarão a fazer parte integrante da mesma, sem que os Arrendatários tenham qualquer direito indemnizatório ou de retenção.

6- As avarias, deteriorações, ou quebras verificadas no apartamento que sejam imputáveis aos Arrendatários, serão consertadas ou substituídas por estes, ficando desde já estabelecido que os Arrendatários não podem fazer furos, quer nos azulejos da cozinha, quer nos azulejos da casa de banho, bem como no teto e caixilhos das janelas.

### CLÁUSULA QUINTA (Encargos)

1- É da responsabilidade dos Arrendatários, liquidar as faturas/recibos e todos os encargos ao consumo de água, eletricidade, gás, telefone, televisão por cabo ou satélite e Internet, taxas ou licenças com tais serviços diretamente ligados, manutenção e limpeza da habitação arrendada, correspondentes ao período de vigência do presente contrato.

2- Os Arrendatários celebram, em seu próprio nome, os contratos de fornecimento referidos no número anterior, com os respetivos fornecedores, correndo por sua conta e risco todas as despesas com os respetivos contratos.

### CLÁUSULA SEXTA (Visitas e Indemnização por Não Restituição)

1- Os Arrendatários, reconhecem ao Senhorio, o direito de, por si ou por pessoa de sua confiança, com aviso prévio, mostrar o local arrendado, sem que os mesmos se possam opor, nos dois meses anteriores ao término do contrato.

2- Após o término do contrato, se o imóvel arrendado não for restituído, seja qual for o motivo, os Arrendatários ficam obrigados a pagar ao Senhorio, a título de indemnização, até ao momento da desocupação efetiva, a renda que for devida em cada mês em que se mantiver a ocupação, sendo essa indemnização elevada ao dobro do valor da renda, sempre que os Arrendatários se constituam em mora.

### CLÁUSULA SÉTIMA (Animais e Espaços Comuns)

1- Os Arrendatários, obrigam-se a indemnizar o Senhorio por quaisquer danos causados por algum animal doméstico que estes tenham no imóvel, incluindo uma possível desinfestação, quer durante a vigência do presente contrato, quer após a sua saída definitiva do imóvel.

2- Os Arrendatários, obrigam-se a manter os espaços comuns livres e desocupados de quaisquer objetos.

3- As despesas inerentes e necessárias à utilização das partes comuns do prédio, são por conta do Senhorio.

### CLÁUSULA OITAVA (Vistoria e Inventário)

1- O Senhorio ou seu representante, procedeu à vistoria do imóvel na presença dos Arrendatários, onde foi feita uma lista de todo o inventário da habitação, bem como foto reportagem do estado do imóvel (chão, paredes, janelas, portas, equipamentos e armários, sanitários e acessórios de casa de banho), assim como o seu estado de conservação, que se anexa ao presente contrato e fica a fazer parte integrante do mesmo.

### CLÁUSULA NONA (Proteção de Dados)

Para efeito de execução do presente contrato, o Senhorio atuará na qualidade de "Responsável pelo Tratamento" dos dados pessoais dos cocontratantes, Arrendatários - "Titular dos Dados", conforme definido no Regulamento (UE) 2016/679 do Parlamento Europeu e do Conselho de 27 de abril de 2016 e na Lei n.° 58/2019 de 8 de agosto.

O Senhorio obriga-se a cumprir o disposto na legislação aplicável em matéria de tratamento de dados pessoais, designadamente:

a) Tratar apenas os dados pessoais que se configurem adequados, pertinentes e limitados às finalidades determinadas, explícitas e legítimas inerentes à execução deste contrato de arrendamento, comprometendo-se a não os tratar posteriormente de forma distinta e incompatível com as finalidades definidas, salvo disposição legal ou consentimento expresso do titular dos dados;

b) Implementar todas as medidas técnicas e organizacionais adequadas à proteção dos dados pessoais contra qualquer forma de tratamento ilícito, nomeadamente destruição (acidental ou ilícita), perda ou dano acidental, alteração, uso indevido, difusão ou acesso não autorizado, bem como quaisquer outras formas de tratamento não autorizado;

c) Garantir que o acesso aos dados pessoais dos Arrendatários serão estritamente limitados aos colaboradores e subcontratantes, que necessitem de ter acesso aos mesmos para efeitos da execução do contrato de arrendamento;

d) Apagar ou destruir todos os dados pessoais que tenham sido conservados pelo Senhorio no termo do contrato de arrendamento, salvo quando disposições legais imponham a sua conservação;

e) Transferir os dados pessoais para fora do Espaço Económico Europeu, de acordo com as disposições aplicáveis em matéria de transferências internacionais de dados;

f) Implementar as medidas técnicas e organizativas adequadas ao fácil e célere exercício dos direitos previstos para os Arrendatários, nomeadamente os direitos à informação, acesso, retificação, oposição, limitação, portabilidade e esquecimento;

g) Prestar os esclarecimentos necessários sobre as disposições da presente cláusula, relativos ao tratamento de dados pessoais que efetue, designadamente quando apresentem um risco para os direitos e liberdades fundamentais dos titulares dos dados;

h) Adotar as medidas técnicas e organizativas adequadas e necessárias à proteção de dados, desde a conceção e por defeito, assegurando a conformidade com a legislação em vigor sobre esta matéria e minorando os riscos decorrentes deste tratamento;

i) Disponibilizar um ponto de contacto interno para auxiliar, em tempo útil, cada colaborador acerca das questões relacionadas com a proteção de dados pessoais.

O Senhorio compromete-se a assegurar que as entidades subcontratantes a que recorre, cumprem com o disposto na legislação aplicável em matéria de tratamento de dados pessoais sempre que procedam ao tratamento de dados pessoais dos seus colaboradores.

O Titular dos Dados obriga-se a comunicar ao Senhorio, qualquer situação que possa afetar o tratamento dos dados pessoais ou que, de algum modo, possa dar origem ao incumprimento das disposições legais em matéria de proteção de dados.

### CLÁUSULA DÉCIMA (Disposições Finais)

1- O presente Contrato é regulado pela Lei Portuguesa.

2- Todo e qualquer litígio, divergência, pedido ou reclamação que resulte da execução ou violação do presente contrato, ou com ele esteja relacionado, bem como as dúvidas que se suscitem relativamente à validade e eficácia de qualquer das suas cláusulas, serão resolvidos por recurso ao tribunal judicial da comarca de Cascais, com expressa renúncia a qualquer outro.

3- Os contratantes convencionam que se consideram domiciliados para efeitos de citação em caso de litígio nos locais indicados no cabeçalho do presente Contrato, para onde deverão ser também remetidas todas as comunicações postais relativas ao presente arrendamento, designadamente à sua cessação e atualização da renda.

4- Os contraentes obrigam-se a cumprir reciprocamente as obrigações assumidas no Contrato que é feito em quadruplicado, de igual valor, destinando-se um a cada um dos outorgantes e o último à Autoridade Tributária e que depois de lido e ratificado, por corresponder à real expressão das suas vontades, é abaixo-assinado.

---

## DOCUMENTOS REFERENCIADOS E ANEXOS

| Documento | Descrição |
|-----------|-----------|
| **Lista de inventário** | Lista de todo o inventário da habitação (anexo ao contrato) |
| **Foto reportagem** | Estado do imóvel (chão, paredes, janelas, portas, equipamentos e armários, sanitários e acessórios de casa de banho) e estado de conservação (anexo ao contrato) |
| **Certificado Energético** | Certificado de Desempenho Energético e da Qualidade do Ar Interior N° SCE235939031 |

---

## FORO COMPETENTE

| Campo | Informação |
|-------|------------|
| **Tribunal competente** | Tribunal judicial da comarca de Cascais |
| **Renúncia** | Expressa renúncia a qualquer outro tribunal |

---

## ASSINATURAS

**Local e Data:** Lisboa, 15 de janeiro de 2023

**Assinantes:**
1. O SENHORIO: HENRIQUE MIGUEL MOURA DE SENA
2. OS ARRENDATÁRIOS: 
   - GONÇALO FILIPE CÔRTE JOAQUIM MARQUES DOS SANTOS
   - FILIPA GOMES JOAQUIM MARQUES DOS SANTOS

**Número de exemplares:** Quadruplicado (um para cada outorgante e um para a Autoridade Tributária)

---

## OBRIGAÇÕES DOS ARRENDATÁRIOS (RESUMO)

1. Pagamento pontual da renda mensal de €1.100,00
2. Uso exclusivo para habitação permanente (casa de morada de família)
3. Proibição de sublocação, comodato, hospedagem, alojamento local
4. Proibição de atividade profissional ou indústria doméstica
5. Uso prudente do imóvel
6. Manutenção das instalações (água, eletricidade, esgotos, saneamento, pavimentos, equipamentos, sanitários, pinturas, vidros, estores)
7. Não fazer furos nos azulejos da cozinha e casa de banho, teto e caixilhos das janelas
8. Celebrar contratos de fornecimento em nome próprio
9. Liquidar faturas de água, eletricidade, gás, telefone, TV cabo/satélite, Internet
10. Permitir visitas ao imóvel nos dois meses anteriores ao término
11. Manter espaços comuns livres e desocupados
12. Indemnizar por danos causados por animais domésticos
13. Comunicar situações que afetem tratamento de dados pessoais

---

## OBRIGAÇÕES DO SENHORIO (RESUMO)

1. Ceder o gozo do imóvel para habitação
2. Enviar recibos de renda
3. Devolver caução no prazo de 60 dias após termo
4. Suportar despesas das partes comuns do prédio
5. Cumprir legislação de proteção de dados pessoais
6. Dar aviso prévio para mostrar o imóvel

---

## OUTROS ELEMENTOS

- **Regime de bens dos Arrendatários:** Comunhão de adquiridos
- **Finalidade do imóvel:** Habitação permanente / Casa de morada de família
- **Sistema de pagamento antecipado:** Pagamento em março de 2023 corresponde ao mês de junho de 2023 (3 meses de antecedência)
- **Direitos dos Arrendatários em matéria de dados:** Informação, acesso, retificação, oposição, limitação, portabilidade e esquecimento