# AUDITORIA CONSOLIDADA (CHEFE: openai/gpt-5.2)

## 1. AVALIAÇÃO DA COMPLETUDE
- [A1,A2,A3] Extração globalmente detalhada e útil para análise do arrendamento
- [A2] Estrutura/organização da extração é clara e bem categorizada (único - OBRIGATÓRIO manter)
- [A3] Omissões formais podem afetar validade/operacionalização (Licença de Utilização) (único - OBRIGATÓRIO manter)

## 2. INCONSISTÊNCIAS IDENTIFICADAS
### Críticas (por gravidade)
- [A2] ⚠️ CRÍTICO: Prazo “3 anos” não coincide com datas 15/01/2023–31/12/2025
- [A2] ⚠️ CRÍTICO: Cláusula de foro Cascais pode ser nula (competência exclusiva do local do imóvel)
- [A3] ⚠️ IMPORTANTE: Artigo matricial “661” ambíguo (falta identificação da fração)
- [A2] ⚠️ ATENÇÃO: Citação do Art. 1097.º CC inconsistente (uniformizar n.º 1, al. b))

## 3. INFORMAÇÃO EM FALTA
- [A3] Falta: Nº/data/entidade da Licença de Utilização (ou isenção por antiguidade)
- [A1,A2] Falta: Cláusula sobre seguro do imóvel (p.ex., multirriscos)
- [A2] Falta: Classe energética (certificado SCE citado sem classe A-F)
- [A2] Falta: Nº de descrição predial (CRP) completo do imóvel
- [A2] Falta: Indicação de fiador/garantias além da caução (se aplicável)
- [A2] Falta: Condições de atualização/regularização da caução (só há atualização da renda)
- [A1] Falta: Cláusula de mediação/arbitragem (há só foro)
- [A1] Falta: Regras claras de uso/manutenção de partes comuns (além de “manter livre”)
- [A2] Falta: Direito de preferência (Art. 1091.º CC) / eventual renúncia
- [A2] Falta: Regime de transmissão por morte (Arts. 1106.º-1113.º CC) (se pretendido explicitar)
- [A2] Falta: Cláusulas de resolução por incumprimento além da mora/penalização
- [A2] Falta: Referência a despejo/Balcão Nacional do Arrendamento (se pretendido)
- [A2] Falta: Repartição de obras de conservação (Art. 1074.º CC) (se não constar)
- [A2] Falta: Prazo legal de comunicação do contrato à AT (foi citado “exemplar”)
- [A2] Falta: Menção a registo/registabilidade do contrato (se aplicável)

## 4. RELEVÂNCIA JURÍDICA
- [A1,A2,A3] Elementos extraídos (partes, imóvel, renda, caução, prazos) são nucleares ao regime do arrendamento
- [A1,A2,A3] Cláusulas de sublocação, obras/benfeitorias, mora (20%) e RGPD têm impacto direto na execução
- [A2] Cláusula de foro pode ser ineficaz/nula em litígios ligados ao imóvel (risco processual)
- [A3] Pagamento inicial “adiantado/buffer” deve ser lido à luz da lei vigente em 15/01/2023 (*tempus regit actum*)

## 5. LEGISLAÇÃO PORTUGUESA APLICÁVEL
- [A1,A2,A3] Código Civil (arrendamento urbano) — enquadramento de prazo, renda, mora, direitos/deveres
- [A2] Art. 1097.º CC — oposição à renovação (uniformizar citação n.º 1, al. b))
- [A2] Art. 1041.º, n.º 1 CC — indemnização de 20% por mora
- [A2] Art. 1076.º CC — caução/garantias e quantias devidas no início (ver redação aplicável à data)
- [A2] Lei n.º 6/2006 (NRAU) — comunicações, regime especial e mecanismos (incl. BNA)
- [A2] DL n.º 294/2009 — certificado energético (obrigatoriedade/menções)
- [A3] DL n.º 160/2006, Art. 5.º — elementos obrigatórios no contrato (incl. licença/utilização)
- [A2] CPC, Art. 104.º — competência exclusiva ligada ao local do imóvel (foro convencionado em risco)
- [A3] Código do Imposto do Selo, Art. 60.º + Portaria n.º 98-A/2015 — comunicação/obrigações perante AT
- [A1] DL n.º 321-B/90 (RAU) — sugestão histórica (ver aplicabilidade atual) (sugestão única - verificar aplicabilidade)
- [A1] Código do Notariado — sugestão para formalização quando aplicável (sugestão única - verificar aplicabilidade)
- [A1] Regime do condomínio (CC, propriedade horizontal) — deveres/encargos se aplicável (sugestão única - verificar aplicabilidade)

## 6. RECOMENDAÇÕES PARA FASE 3
- [A1,A2,A3] Confirmar no original as cláusulas/menções em falta e corrigir a extração
- [A3] Extrair e validar Licença de Utilização (ou isenção) como requisito formal prioritário (único)
- [A2] Verificar e esclarecer “3 anos” vs datas efetivas; corrigir redação/alerta (único)
- [A2] Sinalizar risco de nulidade/ineficácia do foro de Cascais e ajustar estratégia processual (único)
- [A2] Completar identificação registral/matricial (CRP + fração) e classe energética (único)
- [A1,A2] Confirmar existência de cláusula de seguro e respetiva repartição de responsabilidade
- [A2] Confirmar fiador/garantias adicionais e regras sobre caução (único)
- [A2] Mapear cláusulas típicas ausentes (preferência, transmissão por morte, resolução, BNA) (único)
- [A3] Verificar se o IBAN indicado corresponde ao titular/credor contratual (único)
- [A2,A3] Confirmar obrigações e prazos de comunicação do contrato à AT e evidência de cumprimento

## 7. DIVERGÊNCIAS ENTRE AUDITORES
- Tema: Relevância da divergência na citação do Art. 1097.º CC
  - A1: considera inconsistência relevante para precisão jurídica
  - A2: considera inconsistência menor; recomenda uniformizar para n.º 1, al. b)
  - A3: considera juridicamente irrelevante (referência inequívoca)

## 8. CONTROLO DE COBERTURA (OBRIGATÓRIO)

**[A1] encontrou exclusivamente:**
- falta mediação/arbitragem → incorporado em: ##3/Informação em falta, linha 7
- falta regras partes comuns → incorporado em: ##3/Informação em falta, linha 8
- sugestão RAU/Notariado/condomínio → incorporado em: ##5/Legislação aplicável, linhas 10-12

**[A2] encontrou exclusivamente:**
- prazo “3 anos” não bate com datas → incorporado em: ##2/Inconsistências, linha 1
- foro Cascais possivelmente nulo → incorporado em: ##2/Inconsistências, linha 2
- falta classe energética → incorporado em: ##3/Informação em falta, linha 3
- falta nº descrição predial CRP → incorporado em: ##3/Informação em falta, linha 4
- falta fiador/garantias → incorporado em: ##3/Informação em falta, linha 5
- falta atualização da caução → incorporado em: ##3/Informação em falta, linha 6
- faltam cláusulas típicas (preferência, morte, resolução, BNA) → incorporado em: ##3, linhas 9-12
- falta obras conservação (1074.º) → incorporado em: ##3/Informação em falta, linha 13
- falta prazo AT / registo → incorporado em: ##3/Informação em falta, linhas 14-15

**[A3] encontrou exclusivamente:**
- falta Licença de Utilização → incorporado em: ##3/Informação em falta, linha 1
- artigo matricial sem fração → incorporado em: ##2/Inconsistências, linha 3
- validação legal do “buffer” por data (2023) → incorporado em: ##4/Relevância jurídica, linha 4
- CIS 60.º + Port. 98-A/2015 → incorporado em: ##5/Legislação aplicável, linha 9
- verificar titular do IBAN → incorporado em: ##6/Recomendações, linha 8

**Confirmação:** SIM

**ITENS NÃO INCORPORADOS**
- (nenhum)